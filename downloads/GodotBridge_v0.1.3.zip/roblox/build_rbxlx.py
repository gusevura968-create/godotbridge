from pathlib import Path
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
OUT = HERE / "GodotBridgeExperience.rbxlx"
CLIENT = (HERE / "StarterPlayerScripts" / "GodotBridge.client.lua").read_text(encoding="utf-8")
SERVER = (HERE / "ServerScriptService" / "GodotBridgeServer.server.lua").read_text(encoding="utf-8")

root = ET.Element("roblox", {"version": "4"})
ET.SubElement(root, "External").text = "null"
ET.SubElement(root, "External").text = "nil"
seq = 0

def add_item(parent, class_name, name, props=None):
    global seq
    seq += 1
    item = ET.SubElement(parent, "Item", {"class": class_name, "referent": f"RBX{seq}"})
    p = ET.SubElement(item, "Properties")
    ET.SubElement(p, "string", {"name": "Name"}).text = name
    ET.SubElement(p, "bool", {"name": "Archivable"}).text = "true"
    for tag, key, val in (props or []):
        el = ET.SubElement(p, tag, {"name": key})
        el.text = val
    return item

workspace = add_item(root, "Workspace", "Workspace", [("float", "Gravity", "196.2"), ("float", "FallenPartsDestroyHeight", "-500")])
replicated = add_item(root, "ReplicatedStorage", "ReplicatedStorage")
server_service = add_item(root, "ServerScriptService", "ServerScriptService")
server = add_item(server_service, "Script", "GodotBridgeServer", [
    ("bool", "Disabled", "false"),
    ("ProtectedString", "Source", SERVER),
])
starter_player = add_item(root, "StarterPlayer", "StarterPlayer")
starter_scripts = add_item(starter_player, "StarterPlayerScripts", "StarterPlayerScripts")
client = add_item(starter_scripts, "LocalScript", "GodotBridgeClient", [
    ("bool", "Disabled", "false"),
    ("ProtectedString", "Source", CLIENT),
])

ET.indent(root, space="  ")
OUT.write_text(ET.tostring(root, encoding="unicode", xml_declaration=True), encoding="utf-8")
print(OUT)
