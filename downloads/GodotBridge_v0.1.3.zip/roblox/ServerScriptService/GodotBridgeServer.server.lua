-- Server-owned game catalog and demo map.
-- Imported user code is never downloaded or executed by this script.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TeleportService = game:GetService("TeleportService")
local Workspace = game:GetService("Workspace")

-- Add published game entries here after publishing them as places inside this experience.
-- The server is the source of truth: clients cannot submit arbitrary PlaceIds.
local PUBLISHED_GAMES = {
    demo = {
        id = "demo",
        title = "GODOTBRIDGE DEMO",
        description = "Встроенная демонстрационная Roblox-карта.",
        importDate = "Встроенная демонстрация",
        status = "ДОСТУПНА",
        thumbnailAssetId = 0,
        isDemo = true,
    },
    -- Example entry (replace with a real published place ID and metadata):
    -- sample_game = {
    --     id = "sample_game",
    --     title = "My Imported Game",
    --     description = "Imported from a Godot project.",
    --     importDate = "2026-11-14",
    --     status = "ГОТОВА",
    --     thumbnailAssetId = 1234567890,
    --     placeId = 12345678901234,
    -- },
}

local playRemote = ReplicatedStorage:FindFirstChild("GodotBridgePlay")
if not playRemote then
    playRemote = Instance.new("RemoteEvent")
    playRemote.Name = "GodotBridgePlay"
    playRemote.Parent = ReplicatedStorage
end

local catalogRemote = ReplicatedStorage:FindFirstChild("GodotBridgeCatalog")
if not catalogRemote then
    catalogRemote = Instance.new("RemoteFunction")
    catalogRemote.Name = "GodotBridgeCatalog"
    catalogRemote.Parent = ReplicatedStorage
end

local function makePart(parent, name, size, position, color, material)
    local part = Instance.new("Part")
    part.Name = name
    part.Size = size
    part.Position = position
    part.Anchored = true
    part.Color = color
    part.Material = material or Enum.Material.SmoothPlastic
    part.TopSurface = Enum.SurfaceType.Smooth
    part.BottomSurface = Enum.SurfaceType.Smooth
    part.Parent = parent
    return part
end

local function ensureDemoWorld()
    local existing = Workspace:FindFirstChild("GodotBridge_Demo")
    if existing then
        return existing
    end

    local map = Instance.new("Model")
    map.Name = "GodotBridge_Demo"
    map.Parent = Workspace

    makePart(map, "DemoFloor", Vector3.new(100, 2, 100), Vector3.new(0, -1, 0), Color3.fromRGB(35, 61, 88), Enum.Material.Slate)
    makePart(map, "BluePlatform", Vector3.new(18, 2, 18), Vector3.new(0, 2, -18), Color3.fromRGB(47, 174, 229), Enum.Material.Neon)
    makePart(map, "TowerA", Vector3.new(8, 14, 8), Vector3.new(-22, 6, -18), Color3.fromRGB(68, 103, 150))
    makePart(map, "TowerB", Vector3.new(8, 20, 8), Vector3.new(22, 9, -18), Color3.fromRGB(64, 129, 174))
    makePart(map, "StepOne", Vector3.new(10, 2, 10), Vector3.new(0, 2, 8), Color3.fromRGB(44, 128, 185))
    makePart(map, "StepTwo", Vector3.new(10, 2, 10), Vector3.new(0, 5, 23), Color3.fromRGB(55, 157, 210))

    local spawn = Instance.new("SpawnLocation")
    spawn.Name = "GodotBridgeDemoSpawn"
    spawn.Size = Vector3.new(8, 1, 8)
    spawn.Position = Vector3.new(0, 1, 0)
    spawn.Anchored = true
    spawn.Neutral = true
    spawn.Transparency = 0.15
    spawn.Color = Color3.fromRGB(50, 190, 242)
    spawn.Parent = map

    local orb = Instance.new("Part")
    orb.Name = "DemoOrb"
    orb.Shape = Enum.PartType.Ball
    orb.Size = Vector3.new(3, 3, 3)
    orb.Position = Vector3.new(0, 5, -18)
    orb.Anchored = true
    orb.Material = Enum.Material.Neon
    orb.Color = Color3.fromRGB(80, 220, 255)
    orb.Parent = map

    local light = Instance.new("PointLight")
    light.Brightness = 1.5
    light.Range = 24
    light.Parent = orb

    return map
end

catalogRemote.OnServerInvoke = function(_player)
    local result = {}
    for _, entry in pairs(PUBLISHED_GAMES) do
        table.insert(result, {
            id = entry.id,
            title = entry.title,
            description = entry.description,
            importDate = entry.importDate,
            status = entry.status,
            thumbnailAssetId = entry.thumbnailAssetId or 0,
        })
    end
    table.sort(result, function(a, b)
        return a.title < b.title
    end)
    return result
end

playRemote.OnServerEvent:Connect(function(player, gameId)
    if typeof(gameId) ~= "string" or #gameId > 64 then
        return
    end
    local entry = PUBLISHED_GAMES[gameId]
    if not entry then
        warn("GodotBridge rejected an unknown game id from", player.UserId)
        return
    end

    if entry.isDemo then
        ensureDemoWorld()
        local character = player.Character
        if not character then
            character = player.CharacterAdded:Wait()
        end
        local spawnPart = Workspace:FindFirstChild("GodotBridgeDemoSpawn", true)
        if spawnPart and character then
            character:PivotTo(spawnPart.CFrame * CFrame.new(0, 5, 0))
        end
        return
    end

    if typeof(entry.placeId) == "number" and entry.placeId > 0 then
        local success, err = pcall(function()
            TeleportService:Teleport(entry.placeId, player)
        end)
        if not success then
            warn("GodotBridge could not teleport player:", err)
        end
    else
        warn("GodotBridge game is listed but has no published placeId:", gameId)
    end
end)

Players.PlayerAdded:Connect(function(_player)
    ensureDemoWorld()
end)

ensureDemoWorld()
