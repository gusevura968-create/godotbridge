# Roblox Experience source — GodotBridge v0.1.1

This folder contains the Roblox Studio scripts and generated seed place (`GodotBridgeExperience.rbxlx`) for the GodotBridge experience.

## What's changed in v0.1.1

- Refreshed the Roblox menu with a dark navy / cyan visual style, gradient panels, bordered cards, clearer typography, and responsive-width layout.
- Added an explicit **PC only** notice below the two main actions.
- The **ЗАГРУЗИТЬ ФАЙЛ .GODOT** screen now displays the direct GodotBridge Converter ZIP URL and a button that selects the URL text for copying.
- The import information page explains the desktop workflow and the need to open the resulting `.rbxmx` in Roblox Studio.

## Important platform limitation

A Roblox experience cannot browse the player's local files. Also, ordinary experience scripts cannot open arbitrary external websites in the player's browser: Roblox's `GuiService:OpenBrowserWindow()` is deprecated and restricted to RobloxScriptSecurity, and `BrowserService` is reserved for Roblox's own code. Therefore the import page **shows the direct URL in a selectable TextBox**. On PC, the player selects it, presses Ctrl+C, and opens it in a browser. The download button in the website itself remains a normal HTTPS download link.

Direct converter download:

`https://gusevura968-create.github.io/godotbridge/downloads/GodotBridge_v0.1.0.zip`

## Install/update in Roblox Studio

1. Open the existing GodotBridge experience in Roblox Studio.
2. In Explorer, open `StarterPlayer > StarterPlayerScripts`.
3. Replace the source of `GodotBridgeClient` with `StarterPlayerScripts/GodotBridge.client.lua` from this package.
4. The existing `ServerScriptService/GodotBridgeServer` script does not need to change for this UI update.
5. Test using **Play**. Check the main menu, the PC-only note, the import page, and URL selection.
6. Use **File > Publish to Roblox** to update the existing experience.

You can alternatively open `GodotBridgeExperience.rbxlx` in Studio as a separate seed place and inspect it before publishing. The `.rbxlx` was generated and XML-validated here, but it has not been opened or play-tested in Roblox Studio by this environment.
