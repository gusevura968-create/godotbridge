# GodotBridge Roblox UI v0.1.1

- Updated the main menu to a modern dark navy/cyan visual system with gradients, soft background glows, rounded panels and outlined buttons.
- Added a clear note under the main actions: Godot project conversion happens only on a Windows PC using the desktop Converter.
- Added a download section to the import page with the direct HTTPS link to the Converter ZIP.
- Added a button that selects the URL in a TextBox so PC players can copy it with Ctrl+C.
- Clarified that the Roblox client cannot read local project files.

The URL-selection flow is intentional. Normal Roblox experience scripts cannot launch arbitrary external websites; deprecated browser-opening calls are restricted to Roblox internal scripts.
