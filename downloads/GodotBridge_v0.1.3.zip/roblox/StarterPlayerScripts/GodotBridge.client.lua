-- GodotBridge Roblox Experience UI v0.1.1
-- The experience cannot read local files or open arbitrary external URLs from client scripts.
-- The import page therefore displays the official direct download URL for manual copying on PC.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")

local player = Players.LocalPlayer
local playRemote = ReplicatedStorage:WaitForChild("GodotBridgePlay")
local catalogRemote = ReplicatedStorage:WaitForChild("GodotBridgeCatalog")

local DOWNLOAD_URL = "https://gusevura968-create.github.io/godotbridge/downloads/GodotBridge_v0.1.0.zip"

local COLORS = {
    background = Color3.fromRGB(5, 16, 36),
    background2 = Color3.fromRGB(8, 39, 72),
    panel = Color3.fromRGB(10, 29, 57),
    panel2 = Color3.fromRGB(15, 47, 82),
    panel3 = Color3.fromRGB(20, 63, 104),
    accent = Color3.fromRGB(46, 207, 253),
    accent2 = Color3.fromRGB(26, 126, 245),
    text = Color3.fromRGB(245, 250, 255),
    muted = Color3.fromRGB(171, 201, 226),
    green = Color3.fromRGB(133, 235, 89),
    stroke = Color3.fromRGB(74, 172, 235),
}

local gui = Instance.new("ScreenGui")
gui.Name = "GodotBridgeUI"
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = true
gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
gui.Parent = player:WaitForChild("PlayerGui")

local function addCorner(parent, radius)
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, radius or 16)
    corner.Parent = parent
    return corner
end

local function addStroke(parent, color, transparency, thickness)
    local stroke = Instance.new("UIStroke")
    stroke.Color = color or COLORS.stroke
    stroke.Transparency = transparency == nil and 0.55 or transparency
    stroke.Thickness = thickness or 1
    stroke.Parent = parent
    return stroke
end

local function addGradient(parent, first, second, rotation)
    local gradient = Instance.new("UIGradient")
    gradient.Color = ColorSequence.new(first, second)
    gradient.Rotation = rotation or 90
    gradient.Parent = parent
    return gradient
end

local function makeLabel(parent, text, size, color, font)
    local label = Instance.new("TextLabel")
    label.BackgroundTransparency = 1
    label.Text = text
    label.TextColor3 = color or COLORS.text
    label.TextSize = size or 18
    label.Font = font or Enum.Font.Gotham
    label.TextWrapped = true
    label.TextXAlignment = Enum.TextXAlignment.Center
    label.TextYAlignment = Enum.TextYAlignment.Center
    label.Parent = parent
    return label
end

local function makeButton(parent, text, callback, primary, height)
    local button = Instance.new("TextButton")
    button.Name = "ActionButton"
    button.Size = UDim2.new(1, 0, 0, height or 58)
    button.BackgroundColor3 = primary and COLORS.accent or COLORS.panel3
    button.TextColor3 = COLORS.text
    button.Text = text
    button.Font = Enum.Font.GothamBold
    button.TextSize = 16
    button.TextWrapped = true
    button.AutoButtonColor = false
    button.Selectable = true
    button.Parent = parent
    addCorner(button, 15)
    addStroke(button, primary and Color3.fromRGB(150, 235, 255) or COLORS.stroke, primary and 0.2 or 0.55, 1)
    addGradient(button,
        primary and Color3.fromRGB(64, 222, 255) or Color3.fromRGB(23, 80, 133),
        primary and Color3.fromRGB(23, 132, 242) or Color3.fromRGB(13, 48, 88),
        0)

    button.MouseEnter:Connect(function()
        TweenService:Create(button, TweenInfo.new(0.14), {BackgroundTransparency = 0.06}):Play()
    end)
    button.MouseLeave:Connect(function()
        TweenService:Create(button, TweenInfo.new(0.14), {BackgroundTransparency = 0}):Play()
    end)
    button.Activated:Connect(callback)
    return button
end

local function clearPage()
    for _, child in ipairs(gui:GetChildren()) do
        child:Destroy()
    end
end

local function makeHeader(panel, kicker)
    local header = Instance.new("Frame")
    header.Name = "BrandHeader"
    header.BackgroundTransparency = 1
    header.Size = UDim2.new(1, 0, 0, 72)
    header.LayoutOrder = 1
    header.Parent = panel

    local mark = Instance.new("Frame")
    mark.Name = "BridgeMark"
    mark.Size = UDim2.fromOffset(58, 58)
    mark.Position = UDim2.new(0, 0, 0, 5)
    mark.BackgroundColor3 = COLORS.accent2
    mark.Parent = header
    addCorner(mark, 18)
    addStroke(mark, COLORS.accent, 0.15, 1.3)
    addGradient(mark, Color3.fromRGB(77, 226, 255), Color3.fromRGB(24, 103, 226), 45)
    local markText = makeLabel(mark, "GB", 22, Color3.fromRGB(255, 255, 255), Enum.Font.GothamBlack)
    markText.Size = UDim2.fromScale(1, 1)

    local brand = makeLabel(header, "GODOTBRIDGE", 25, COLORS.text, Enum.Font.GothamBlack)
    brand.Position = UDim2.new(0, 72, 0, 5)
    brand.Size = UDim2.new(1, -72, 0, 31)
    brand.TextXAlignment = Enum.TextXAlignment.Left

    local subtitle = makeLabel(header, kicker or "МОСТ МЕЖДУ GODOT И ROBLOX", 11, COLORS.accent, Enum.Font.GothamBold)
    subtitle.Position = UDim2.new(0, 73, 0, 37)
    subtitle.Size = UDim2.new(1, -73, 0, 21)
    subtitle.TextXAlignment = Enum.TextXAlignment.Left
    return header
end

local function makePage(pageHeight)
    clearPage()

    local root = Instance.new("Frame")
    root.Name = "Background"
    root.Size = UDim2.fromScale(1, 1)
    root.BackgroundColor3 = COLORS.background
    root.Parent = gui
    addGradient(root, COLORS.background, COLORS.background2, 35)

    -- Soft decorative lights behind the central panel.
    local glowA = Instance.new("Frame")
    glowA.Name = "BlueGlow"
    glowA.AnchorPoint = Vector2.new(0.5, 0.5)
    glowA.Position = UDim2.fromScale(0.18, 0.2)
    glowA.Size = UDim2.fromOffset(330, 330)
    glowA.BackgroundColor3 = COLORS.accent2
    glowA.BackgroundTransparency = 0.88
    glowA.Parent = root
    addCorner(glowA, 200)

    local glowB = Instance.new("Frame")
    glowB.Name = "CyanGlow"
    glowB.AnchorPoint = Vector2.new(0.5, 0.5)
    glowB.Position = UDim2.fromScale(0.84, 0.82)
    glowB.Size = UDim2.fromOffset(270, 270)
    glowB.BackgroundColor3 = COLORS.accent
    glowB.BackgroundTransparency = 0.91
    glowB.Parent = root
    addCorner(glowB, 200)

    local panel = Instance.new("Frame")
    panel.Name = "Content"
    panel.AnchorPoint = Vector2.new(0.5, 0.5)
    panel.Position = UDim2.fromScale(0.5, 0.5)
    panel.Size = UDim2.new(0.9, 0, 0, pageHeight or 470)
    panel.BackgroundColor3 = COLORS.panel
    panel.Parent = root
    addCorner(panel, 24)
    addStroke(panel, COLORS.stroke, 0.28, 1.4)
    addGradient(panel, Color3.fromRGB(16, 48, 82), COLORS.panel, 90)

    local sizeConstraint = Instance.new("UISizeConstraint")
    sizeConstraint.MinSize = Vector2.new(280, pageHeight or 470)
    sizeConstraint.MaxSize = Vector2.new(620, pageHeight or 470)
    sizeConstraint.Parent = panel

    local accentLine = Instance.new("Frame")
    accentLine.Name = "TopAccent"
    accentLine.Size = UDim2.new(1, -48, 0, 3)
    accentLine.Position = UDim2.new(0, 24, 0, 0)
    accentLine.BackgroundColor3 = COLORS.accent
    accentLine.BorderSizePixel = 0
    accentLine.Parent = panel
    addCorner(accentLine, 3)
    addGradient(accentLine, COLORS.accent, COLORS.accent2, 0)

    local padding = Instance.new("UIPadding")
    padding.PaddingTop = UDim.new(0, 25)
    padding.PaddingBottom = UDim.new(0, 24)
    padding.PaddingLeft = UDim.new(0, 30)
    padding.PaddingRight = UDim.new(0, 30)
    padding.Parent = panel

    local list = Instance.new("UIListLayout")
    list.HorizontalAlignment = Enum.HorizontalAlignment.Center
    list.SortOrder = Enum.SortOrder.LayoutOrder
    list.Padding = UDim.new(0, 8)
    list.Parent = panel

    return root, panel
end

local showMain

local function showImportInfo()
    local _, panel = makePage(610)
    makeHeader(panel, "ЗАГРУЗКА НАСТОЛЬНОГО КОНВЕРТЕРА")

    local title = makeLabel(panel, "ИМПОРТ GODOT-ПРОЕКТА", 19, COLORS.text, Enum.Font.GothamBold)
    title.Size = UDim2.new(1, 0, 0, 34)
    title.LayoutOrder = 2

    local explanation = makeLabel(panel,
        "Roblox-плейс не может напрямую открывать файлы на твоём устройстве. Скачай GodotBridge Converter на компьютер, а затем выбери ZIP-архив Godot-проекта в настольном приложении.",
        13, COLORS.muted, Enum.Font.Gotham)
    explanation.Size = UDim2.new(1, 0, 0, 76)
    explanation.LayoutOrder = 3
    explanation.TextYAlignment = Enum.TextYAlignment.Top

    local steps = makeLabel(panel,
        "1. Скачай ZIP по ссылке ниже.\n2. Распакуй архив и запусти Converter на Windows.\n3. Выбери ZIP проекта, в котором есть project.godot.\n4. Проверь отчёт и открой результат .rbxmx в Roblox Studio.",
        12, COLORS.text, Enum.Font.Gotham)
    steps.Size = UDim2.new(1, 0, 0, 92)
    steps.LayoutOrder = 4
    steps.TextXAlignment = Enum.TextXAlignment.Left
    steps.TextYAlignment = Enum.TextYAlignment.Center

    local linkTitle = makeLabel(panel, "ПРЯМАЯ ССЫЛКА НА GODOTBRIDGE CONVERTER", 11, COLORS.accent, Enum.Font.GothamBold)
    linkTitle.Size = UDim2.new(1, 0, 0, 22)
    linkTitle.LayoutOrder = 5
    linkTitle.TextXAlignment = Enum.TextXAlignment.Left

    local urlBox = Instance.new("TextBox")
    urlBox.Name = "ConverterDownloadUrl"
    urlBox.Size = UDim2.new(1, 0, 0, 46)
    urlBox.BackgroundColor3 = Color3.fromRGB(4, 19, 38)
    urlBox.TextColor3 = COLORS.text
    urlBox.PlaceholderColor3 = COLORS.muted
    urlBox.Text = DOWNLOAD_URL
    urlBox.PlaceholderText = "Ссылка на скачивание"
    urlBox.Font = Enum.Font.Code
    urlBox.TextSize = 10
    urlBox.TextXAlignment = Enum.TextXAlignment.Left
    urlBox.TextYAlignment = Enum.TextYAlignment.Center
    urlBox.ClearTextOnFocus = false
    urlBox.TextEditable = true
    urlBox.TextWrapped = false
    urlBox.MultiLine = false
    urlBox.LayoutOrder = 6
    urlBox.Parent = panel
    addCorner(urlBox, 10)
    addStroke(urlBox, COLORS.accent2, 0.35, 1)
    local urlPadding = Instance.new("UIPadding")
    urlPadding.PaddingLeft = UDim.new(0, 12)
    urlPadding.PaddingRight = UDim.new(0, 12)
    urlPadding.Parent = urlBox

    local copyHint = makeLabel(panel,
        "Нажми «ВЫДЕЛИТЬ ССЫЛКУ», затем Ctrl+C и открой адрес в браузере на ПК.",
        11, COLORS.muted, Enum.Font.Gotham)
    copyHint.Size = UDim2.new(1, 0, 0, 30)
    copyHint.LayoutOrder = 7

    local selectLink = makeButton(panel, "ВЫДЕЛИТЬ ССЫЛКУ ДЛЯ КОПИРОВАНИЯ", function()
        urlBox:CaptureFocus()
        urlBox.SelectionStart = 1
        urlBox.CursorPosition = #DOWNLOAD_URL + 1
        copyHint.Text = "Адрес выделен. Нажми Ctrl+C, затем вставь его в браузер на ПК."
        copyHint.TextColor3 = COLORS.green
    end, true, 48)
    selectLink.LayoutOrder = 8
    selectLink.TextSize = 13

    local back = makeButton(panel, "←  НАЗАД В ГЛАВНОЕ МЕНЮ", showMain, false, 46)
    back.LayoutOrder = 9
    back.TextSize = 13
end

local function addGameThumbnail(parent, entry)
    local thumbnailAssetId = tonumber(entry.thumbnailAssetId) or 0
    if thumbnailAssetId > 0 then
        local image = Instance.new("ImageLabel")
        image.Name = "GameThumbnail"
        image.Position = UDim2.new(0, 10, 0, 9)
        image.Size = UDim2.new(0, 100, 0, 106)
        image.BackgroundColor3 = COLORS.background
        image.Image = "rbxassetid://" .. tostring(thumbnailAssetId)
        image.ScaleType = Enum.ScaleType.Crop
        image.Parent = parent
        addCorner(image, 10)
        return
    end

    if entry.id == "demo" then
        local thumbnail = Instance.new("ViewportFrame")
        thumbnail.Name = "GameThumbnail"
        thumbnail.Position = UDim2.new(0, 10, 0, 9)
        thumbnail.Size = UDim2.new(0, 100, 0, 106)
        thumbnail.BackgroundColor3 = COLORS.background
        thumbnail.Ambient = Color3.fromRGB(155, 190, 220)
        thumbnail.LightColor = Color3.fromRGB(255, 255, 255)
        thumbnail.Parent = parent
        addCorner(thumbnail, 10)
        local world = Instance.new("WorldModel")
        world.Parent = thumbnail
        local floor = Instance.new("Part")
        floor.Anchored = true
        floor.Size = Vector3.new(7, 0.6, 7)
        floor.Position = Vector3.new(0, -1, 0)
        floor.Color = Color3.fromRGB(35, 61, 88)
        floor.Parent = world
        local orb = Instance.new("Part")
        orb.Anchored = true
        orb.Shape = Enum.PartType.Ball
        orb.Size = Vector3.new(2, 2, 2)
        orb.Position = Vector3.new(0, 0.5, 0)
        orb.Material = Enum.Material.Neon
        orb.Color = COLORS.accent
        orb.Parent = world
        local camera = Instance.new("Camera")
        camera.CFrame = CFrame.lookAt(Vector3.new(5, 4, 7), Vector3.new(0, 0, 0))
        camera.Parent = thumbnail
        thumbnail.CurrentCamera = camera
        return
    end

    local placeholder = Instance.new("Frame")
    placeholder.Name = "GameThumbnailPlaceholder"
    placeholder.Position = UDim2.new(0, 10, 0, 9)
    placeholder.Size = UDim2.new(0, 100, 0, 106)
    placeholder.BackgroundColor3 = COLORS.panel3
    placeholder.Parent = parent
    addCorner(placeholder, 10)
    local placeholderText = makeLabel(placeholder, "GB", 25, COLORS.accent, Enum.Font.GothamBlack)
    placeholderText.Size = UDim2.fromScale(1, 1)
end

local function showGames()
    local _, panel = makePage(560)
    makeHeader(panel, "ТВОЯ КОЛЛЕКЦИЯ ИМПОРТОВ")

    local pageTitle = makeLabel(panel, "ИГРЫ", 21, COLORS.text, Enum.Font.GothamBold)
    pageTitle.Size = UDim2.new(1, 0, 0, 35)
    pageTitle.LayoutOrder = 2

    local scroll = Instance.new("ScrollingFrame")
    scroll.Name = "GameLibrary"
    scroll.Size = UDim2.new(1, 0, 0, 325)
    scroll.BackgroundTransparency = 1
    scroll.BorderSizePixel = 0
    scroll.ScrollBarThickness = 4
    scroll.ScrollBarImageColor3 = COLORS.accent
    scroll.CanvasSize = UDim2.new(0, 0, 0, 0)
    scroll.AutomaticCanvasSize = Enum.AutomaticSize.Y
    scroll.LayoutOrder = 3
    scroll.Parent = panel
    local list = Instance.new("UIListLayout")
    list.SortOrder = Enum.SortOrder.LayoutOrder
    list.Padding = UDim.new(0, 10)
    list.Parent = scroll

    local success, games = pcall(function()
        return catalogRemote:InvokeServer()
    end)
    if not success then
        makeLabel(scroll, "Не удалось получить каталог игр. Попробуй открыть раздел ещё раз.", 13, COLORS.muted).Size = UDim2.new(1, 0, 0, 56)
    elseif #games == 0 then
        makeLabel(scroll, "Здесь пока нет импортированных игр.", 13, COLORS.muted).Size = UDim2.new(1, 0, 0, 56)
    else
        for index, entry in ipairs(games) do
            local card = Instance.new("Frame")
            card.Name = "GameCard_" .. tostring(entry.id)
            card.Size = UDim2.new(1, -8, 0, 124)
            card.BackgroundColor3 = COLORS.panel2
            card.LayoutOrder = index
            card.Parent = scroll
            addCorner(card, 14)
            addStroke(card, COLORS.stroke, 0.72, 1)

            addGameThumbnail(card, entry)

            local title = makeLabel(card, entry.title or "Untitled game", 15, COLORS.text, Enum.Font.GothamBold)
            title.Position = UDim2.new(0, 120, 0, 7)
            title.Size = UDim2.new(1, -130, 0, 24)
            title.TextXAlignment = Enum.TextXAlignment.Left

            local description = makeLabel(card, entry.description or "", 11, COLORS.muted)
            description.Position = UDim2.new(0, 120, 0, 31)
            description.Size = UDim2.new(1, -130, 0, 23)
            description.TextXAlignment = Enum.TextXAlignment.Left

            local metadata = makeLabel(card, "Дата: " .. tostring(entry.importDate or "—") .. "  •  Статус: " .. tostring(entry.status or "НЕИЗВЕСТНО"), 10, COLORS.muted)
            metadata.Position = UDim2.new(0, 120, 0, 55)
            metadata.Size = UDim2.new(1, -130, 0, 18)
            metadata.TextXAlignment = Enum.TextXAlignment.Left

            local play = makeButton(card, "ИГРАТЬ  →", function()
                playRemote:FireServer(entry.id)
                if entry.id == "demo" then
                    gui.Enabled = false
                end
            end, true, 35)
            play.Position = UDim2.new(0, 120, 0, 82)
            play.Size = UDim2.new(1, -130, 0, 34)
            play.TextSize = 12
        end
    end

    local back = makeButton(panel, "←  НАЗАД В ГЛАВНОЕ МЕНЮ", showMain, false, 46)
    back.LayoutOrder = 4
    back.TextSize = 13
end

showMain = function()
    local _, panel = makePage(470)
    makeHeader(panel, "МОСТ МЕЖДУ GODOT И ROBLOX")

    local welcome = makeLabel(panel, "ПЕРЕНОСИ СВОИ МИРЫ", 18, COLORS.text, Enum.Font.GothamBold)
    welcome.Size = UDim2.new(1, 0, 0, 36)
    welcome.LayoutOrder = 2

    local tagline = makeLabel(panel, "Выбери действие, чтобы продолжить", 12, COLORS.muted, Enum.Font.Gotham)
    tagline.Size = UDim2.new(1, 0, 0, 23)
    tagline.LayoutOrder = 3

    local importButton = makeButton(panel, "↓   ЗАГРУЗИТЬ ФАЙЛ .GODOT", showImportInfo, true, 62)
    importButton.LayoutOrder = 4
    importButton.TextSize = 16

    local gamesButton = makeButton(panel, "▦   ИГРЫ", showGames, false, 58)
    gamesButton.LayoutOrder = 5
    gamesButton.TextSize = 16

    local note = Instance.new("Frame")
    note.Name = "DesktopOnlyNotice"
    note.Size = UDim2.new(1, 0, 0, 70)
    note.BackgroundColor3 = Color3.fromRGB(5, 35, 59)
    note.LayoutOrder = 6
    note.Parent = panel
    addCorner(note, 13)
    addStroke(note, COLORS.accent, 0.55, 1)

    local noteTitle = makeLabel(note, "ВАЖНО  ·  ТОЛЬКО ПК", 11, COLORS.accent, Enum.Font.GothamBold)
    noteTitle.Position = UDim2.new(0, 12, 0, 7)
    noteTitle.Size = UDim2.new(1, -24, 0, 18)
    noteTitle.TextXAlignment = Enum.TextXAlignment.Left

    local noteBody = makeLabel(note,
        "Конвертирование выполняется на компьютере через GodotBridge Converter для Windows. В Roblox нельзя выбрать локальный файл проекта.",
        10, COLORS.muted, Enum.Font.Gotham)
    noteBody.Position = UDim2.new(0, 12, 0, 26)
    noteBody.Size = UDim2.new(1, -24, 0, 38)
    noteBody.TextXAlignment = Enum.TextXAlignment.Left

    local footer = makeLabel(panel, "GODOTBRIDGE  •  DESKTOP CONVERTER  •  v0.1.0", 9, Color3.fromRGB(114, 156, 190), Enum.Font.GothamBold)
    footer.Size = UDim2.new(1, 0, 0, 18)
    footer.LayoutOrder = 7
end

showMain()
