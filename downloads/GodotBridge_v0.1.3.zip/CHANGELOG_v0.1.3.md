# GodotBridge v0.1.3

## Installation, diagnostics and reliability

- Preserved the established Windows startup workflow: use the working right-click context-menu launch option for `run_converter.bat` / `run_converter.py`; the installation guide explicitly warns against the ordinary left double-click method observed to fail on the tested PC.
- Added a **ПРОВЕРКА СИСТЕМЫ** screen with Python/Tkinter versions, OS/architecture, required-file checks, output-folder write access, free disk space and log location.
- Added rotating per-user logs. Import failures and unexpected Tkinter callback errors now save detailed tracebacks while the user sees an actionable message.
- Added a guard against closing the app while conversion is running.
- Hardened the «Мои игры» screen against inaccessible folders and malformed JSON reports.
- Improved the Windows launcher preflight: it validates Python 3.10+ before selecting `py -3`, falls back to a suitable `python` command if the launcher points to an older interpreter, checks required program modules, and still verifies Tkinter.
- Added source-project preflight checks for `.tscn` scenes, file count, output-folder permissions and available disk space.
- Conversion output is created in a staging directory; generated RBXMX XML is validated before the finished game folder is atomically moved into `ConvertedGames`. Failed conversions clean up temporary output rather than leaving misleading partial folders.
- Failed individual GDScript translations and scene parses are reported as warnings instead of automatically aborting all other supported content. A conversion still fails when no scene can be produced.
- ZIP validation now rejects encrypted/unsupported archives, special-file entries, unsafe Windows filenames, case-insensitive duplicates, file/directory path conflicts and actual expanded-size overruns. It checks available space on the extraction drive before writing. ZIP extraction is staged and committed only after a successful read and project-root check.
- Made package GUI import lazy, so command-line conversion does not import Tkinter unnecessarily.
- Updated package metadata, README files and both copies of `ПОШАГОВАЯ УСТАНОВКА.txt`.

## Compatibility

- Python 3.10+ remains required.
- No third-party runtime dependencies were added.
- Existing project conversion semantics remain intentionally conservative: GDScript translation is still partial, and many Godot systems require manual Roblox adaptation.
