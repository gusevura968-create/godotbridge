extends Node3D

var phase: float = 0.0

func _process(delta: float) -> void:
    phase += delta
