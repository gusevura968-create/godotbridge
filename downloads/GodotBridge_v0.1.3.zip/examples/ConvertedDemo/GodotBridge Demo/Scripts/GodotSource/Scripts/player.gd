extends CharacterBody3D

@export var speed: float = 5.0

func _ready() -> void:
    print("GodotBridge demo ready")

func set_speed(value: float) -> void:
    speed = value

func _physics_process(delta: float) -> void:
    if not is_on_floor():
        velocity.y -= 9.8 * delta
    var input_dir := Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
    velocity.x = input_dir.x * speed
    velocity.z = input_dir.y * speed
    move_and_slide()
