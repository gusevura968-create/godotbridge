# GODOTBRIDGE IMPORT REPORT

**Project:** GodotBridge Demo
**Status:** PARTIAL
**Imported (UTC):** 2026-11-14T15:26:58+00:00

## Found

- scenes: 1
- scripts: 2
- textures: 2
- audio: 1
- model_files: 1

## Staged for Roblox Studio

- textures: 2
- audio: 1
- model_files: 1
- other_assets: 0

## Converted into RBXMX/Luau output

- scenes_to_rbxmx: 1
- scene_nodes_to_roblox_instances: 10
- luau_files_generated: 2
- gdscript_statements_translated: 9
- gdscript_statements_flagged: 8

## Warnings

- GDScript Scripts/orb.gd: строка 5: callback _process создан как метод ModuleScript; привязка к Roblox lifecycle не генерируется
- GDScript Scripts/player.gd: строка 5: callback _ready создан как метод ModuleScript; привязка к Roblox lifecycle не генерируется
- GDScript Scripts/player.gd: строка 11: callback _physics_process создан как метод ModuleScript; привязка к Roblox lifecycle не генерируется
- GDScript Scripts/player.gd: строка 12: условие использует неподдерживаемый Godot API 'is_on_floor('; ветка не переносится
- GDScript Scripts/player.gd: строка 14: вызов Godot API 'Input.' не имеет безопасного прямого аналога
- GDScript Scripts/player.gd: строка 15: свойство или вызов Godot API требует ручного аналога (velocity.x = input_dir.x * speed)
- GDScript Scripts/player.gd: строка 16: свойство или вызов Godot API требует ручного аналога (velocity.z = input_dir.y * speed)
- GDScript Scripts/player.gd: строка 17: вызов Godot API 'move_and_slide(' не имеет безопасного прямого аналога
- Сцена Scenes/Main.tscn: Floor: физика/сигналы StaticBody3D не перенесены автоматически; проверьте коллизии и игровую логику.
- Сцена Scenes/Main.tscn: Player: физика/сигналы CharacterBody3D не перенесены автоматически; проверьте коллизии и игровую логику.
- Сцена Scenes/Main.tscn: Camera3D: Camera создана как Instance; назначьте её Workspace.CurrentCamera скриптом в Roblox Studio.
- Сцена Scenes/Main.tscn: Sun: DirectionalLight3D не имеет прямого локального аналога; настройте Lighting.ClockTime/Environment вручную.
- Сцена Scenes/Main.tscn: Billboard: текстура res://Textures/orb.png экспортирована отдельно; её нужно загрузить в Roblox и назначить вручную.
- Сцена Scenes/Main.tscn: ImportedProp: исходная модель res://Models/test_prop.obj сохранена в Models/; в RBXMX пока оставлена Part-заглушка.
- Сцена Scenes/Main.tscn: Chime: Sound создан без SoundId; аудио нужно отдельно загрузить в Roblox и назначить.
- Ресурсы скопированы в выходную папку, но не загружены в Roblox Asset Manager; назначение asset ID выполняется вручную.
- Переводчик отметил 8 неподдерживаемых/неоднозначных строк GDScript; см. Scripts/Luau и отчёт.

## Errors

- Нет.

> RBXMX проверен как XML в рамках автоматических тестов. Файл не открывался в Roblox Studio в этой среде.
