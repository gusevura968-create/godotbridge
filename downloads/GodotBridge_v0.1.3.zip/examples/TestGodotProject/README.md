# GodotBridge Demo Godot project

Small Godot 4-style fixture used by automated converter tests. Open `project.godot` with Godot 4 to inspect it, or zip the contents of this folder and import that ZIP with GodotBridge Converter.

The project deliberately contains simple convertible geometry plus a `move_and_slide()` call that should be reported as unsupported rather than silently translated.
