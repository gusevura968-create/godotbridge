# GodotBridge v0.1.2

- Improved Windows `run_converter.bat` startup diagnostics.
- Checks that the project files are fully extracted.
- Detects the Python launcher or `python` command.
- Checks Python 3.10+ and Tkinter before starting the UI.
- Keeps the console open and explains what to send if an error occurs.
- No converter logic changes.
