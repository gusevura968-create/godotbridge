# GodotBridge v0.1.3 — Windows smoke-test checklist

The automated tests and CLI smoke test were run in a Linux development environment. Before treating the release as fully Windows-verified, perform these checks on the target Windows PC.

## Startup and installation

- [ ] Extract the complete ZIP to a normal folder (not the ZIP preview).
- [ ] Confirm Python 3.10+ and the `tcl/tk and IDLE` component are installed.
- [ ] Start `run_converter.bat` using the already-working right-click context-menu option with the file icon.
- [ ] Confirm the app opens without changing the user's established startup method.
- [ ] Open **ПРОВЕРКА СИСТЕМЫ** and verify that Python, Tkinter, program files, output-folder write access, free disk space and log path are shown.
- [ ] Confirm `run_converter.bat` reports a clear error if a required module is temporarily renamed (then restore the module).

## Import workflow

- [ ] Import `examples/TestGodotProject` packed as ZIP.
- [ ] Confirm a complete output folder is created, including `Reports/import_report.md`, `Reports/import_report.json` and `RobloxProject/ConvertedScene.rbxmx`.
- [ ] Import the same ZIP a second time and confirm the first result is not overwritten.
- [ ] Open **МОИ ИГРЫ** and confirm both results are listed.
- [ ] Confirm a deliberately invalid ZIP produces an understandable error and does not appear as a completed game.
- [ ] Confirm a project with no readable `.tscn` scene does not leave a partial result folder.

## Error log

- [ ] Trigger a known import error and confirm the message shows the per-user log path.
- [ ] Open the log and confirm it contains the timestamp and exception traceback.
- [ ] Confirm logs are stored outside the Godot project and outside the downloaded program folder.

## Roblox Studio

- [ ] Open `RobloxProject/ConvertedScene.rbxmx` in Roblox Studio.
- [ ] Inspect hierarchy, Part properties, and any warnings in the import report.
- [ ] Do not treat a successful RBXMX XML validation as proof that the scene is a playable equivalent of the original Godot game.
