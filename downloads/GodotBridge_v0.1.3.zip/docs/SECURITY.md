# Security model

- User ZIP content is treated as data. The converter never launches Godot, evaluates GDScript, invokes shell commands from a project, loads native libraries from the archive, or runs generated Luau.
- ZIP members are validated before extraction. The target temporary volume is checked for sufficient free space before extraction begins. Absolute paths, `..` traversal, backslash path tricks, drive/alternate-stream syntax, Windows-reserved names, trailing dots/spaces, symlinks and special files are rejected. Case-insensitive duplicates, file/directory path conflicts, encrypted or unsupported compression, excessive file counts, oversized members, declared and actual expanded-size overruns, and extreme compression ratios are rejected. Extraction uses a temporary sibling folder and is moved into place only after the archive and single project root have been validated.
- `.tscn` and `.gd` are parsed as text only. GDScript translation exceptions are contained to the affected script and surfaced in the report; no source script is executed.
- The Roblox server accepts only string identifiers that exist in its server-owned `PUBLISHED_GAMES` allowlist (the default entry is `demo`). It does not accept uploaded code, asset IDs or arbitrary place IDs from clients; place IDs are read only from the server-side table.
- `loadstring` is not used. Imported source is not dynamically executed.

The converter is not a malware scanner. Do not execute scripts or binaries from untrusted Godot projects after conversion. Keep Roblox asset upload and publication permissions under the project owner's control.

- Conversion results are built in a staging directory and promoted to `ConvertedGames` only after at least one RBXMX scene has been generated and each output RBXMX file parses as XML. Failed conversions clean their staging directory.
- Diagnostic logs are stored in the current user profile, not in the submitted Godot project or the public repository.
