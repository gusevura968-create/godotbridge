# Supported feature matrix — 0.1.0

The matrix describes what the current converter actually does, not what is planned.

| Godot input | Current handling | Result / caveat |
|---|---|---|
| `project.godot` | Reads application name and main scene metadata | No Godot engine startup |
| Text `.tscn` | Parses `[node]`, `[ext_resource]`, `[sub_resource]` sections and parent paths | Binary `.scn` is not supported |
| `Node`, `Node2D`, `Node3D` | Builds Roblox `Model` containers | Scene hierarchy is retained approximately |
| `StaticBody3D`, `RigidBody3D`, `CharacterBody3D`, `Area3D` | Builds Model containers and descendants | Physics, signals and gameplay are not translated |
| `MeshInstance3D` | Creates a Part approximation; copies external model files | GLB/GLTF/OBJ/FBX geometry is not embedded into the RBXMX |
| `Sprite2D` | Creates a Part approximation and stores source texture path as metadata | Upload texture and set asset ID manually |
| `CollisionShape3D` | Creates invisible Part with basic Box/Sphere/Capsule dimensions | Only approximate simple primitives |
| `Camera3D`, `Camera2D` | Writes Camera instance and CFrame | Must set `Workspace.CurrentCamera`; `Camera2D` projection is not preserved |
| `OmniLight3D`, `SpotLight3D` | Writes PointLight/SpotLight under invisible host Part | Approximate intensity/range |
| `DirectionalLight3D` | Writes metadata and a warning | Configure Roblox Lighting manually |
| PNG/JPG/JPEG/WebP/BMP/TGA | Copies files to `Textures/` | Upload to Roblox and assign asset IDs manually |
| WAV/OGG/MP3/FLAC | Copies files to `Audio/` | Upload to Roblox and set `SoundId` manually |
| GLB/GLTF/OBJ/FBX/DAE/BLEND | Copies files to `Models/` | Use Studio's model import workflow manually |
| GDScript declarations, functions, if/else, simple loops, arithmetic, print/return | Emits Luau module draft | Manual API adaptation and review required |
| `queue_free`, `get_node`, `get_tree`, `Input`, `move_and_slide`, signals, annotations such as `@onready` | Preserves TODO comments and warnings | No fabricated Luau equivalent |
| ZIP archives | Validates paths, symlinks, duplicates, file counts and uncompressed size | One project per archive; nested ZIPs are not recursively unpacked |

## Report semantics

- **Found** counts source files discovered in the Godot project.
- **Staged** counts resource files copied to the output tree. It does not mean those assets have been uploaded to Roblox.
- **Converted** counts emitted RBXMX scene files, approximate Roblox Instances, translated Luau statements and generated Luau files.
- **PARTIAL** means that warnings were emitted; this is expected for projects using unsupported features.
