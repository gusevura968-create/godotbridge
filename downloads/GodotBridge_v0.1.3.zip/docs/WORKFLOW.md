# Recommended import workflow

1. In Godot, close the editor or export a clean project copy. Include `project.godot`, `.tscn`, `.gd`, textures, audio and external models.
2. ZIP the project folder so that `project.godot` is inside the archive. Do not include only the `project.godot` file.
3. Run GodotBridge Converter and import the ZIP.
4. Read `Reports/import_report.md`. Resolve all warnings before treating the output as usable.
5. Open `RobloxProject/ConvertedScene.rbxmx` in Roblox Studio. Inspect the Explorer hierarchy, sizes, orientation, pivots and collision.
6. Import model files from `Models/` with Studio's asset/model import tools. Upload textures/audio and replace the `GodotBridge_*` source-path metadata with proper Roblox asset IDs.
7. Review each Luau file. Port Godot API calls and gameplay behavior explicitly; do not blindly paste generated TODOs into live scripts.
8. Add required Roblox Scripts/ModuleScripts and connect them to the imported hierarchy.
9. Test in Studio's local server/client modes, then publish the place yourself.
10. After publishing an adapted place inside the same Roblox experience/universe, add its title, date, status, thumbnail asset ID and PlaceId to the server-side `PUBLISHED_GAMES` allowlist. The included server script validates IDs against this table; test teleporting in a published environment.
