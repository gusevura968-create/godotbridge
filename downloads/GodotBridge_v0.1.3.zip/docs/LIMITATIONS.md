# Known limitations

1. Godot and Roblox have different scene graphs, renderers, physics engines, input systems, animation models, UI frameworks, scripting APIs and asset pipelines. Arbitrary game equivalence is not achievable by renaming functions.
2. Only text `.tscn` files are parsed in this version. Binary `.scn`, imported Godot cache internals, packed scenes and complex resources are not reconstructed.
3. Meshes from GLB/GLTF/OBJ/FBX/DAE/BLEND are staged as source assets. The RBXMX uses block/primitive approximations instead of embedding arbitrary mesh geometry.
4. Texture and audio files are copied, not uploaded. Asset moderation, ownership, permissions and asset IDs must be handled in Roblox Studio/Creator Dashboard.
5. The GDScript translator is a syntactic subset. Generated Luau is an untrusted draft and must be reviewed. It is not automatically inserted or run by the converter.
6. Physics bodies, character controllers, signals, navigation, animation trees, shaders, particle systems, multiplayer logic, autoloads, resources, custom editors, and Godot UI need manual equivalents.
7. Coordinate transforms are approximate for complex nested transforms, 2D/3D combinations, pivots, bones, animation tracks and nonuniform scale.
8. Camera instances need a Roblox-side camera controller. Directional lighting is represented as a report item rather than a direct instance mapping.
9. The Roblox experience library is supplied by a server-side allowlist with one built-in demo. Additional published places can be added manually to the allowlist, but the desktop converter does not publish places, upload assets, synchronize a Roblox account or maintain a DataStore catalog. Entries must be places inside the same Roblox experience/universe; teleport behavior needs a published-environment test.
10. The `.rbxlx` seed file has been XML-validated in this environment but not opened or published in Roblox Studio. Always inspect it in Studio before use.

These limitations are deliberately visible in the generated report. A successful file conversion is not a claim that the whole game is playable.
