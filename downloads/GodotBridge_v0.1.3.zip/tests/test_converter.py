from __future__ import annotations

import sys
import tempfile
import unittest
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONVERTER = ROOT / "converter"
sys.path.insert(0, str(CONVERTER))

from godotbridge.archive import ArchiveValidationError, safe_extract_zip
from godotbridge.convert import GodotBridgeConverter
from godotbridge.parser import parse_tscn
from godotbridge.scripts import translate_gdscript

FIXTURE = ROOT / "examples" / "TestGodotProject"


class ArchiveTests(unittest.TestCase):
    def test_extract_valid_project_zip(self):
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            archive = temp_path / "project.zip"
            with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as zf:
                for source in FIXTURE.rglob("*"):
                    if source.is_file():
                        zf.write(source, source.relative_to(FIXTURE).as_posix())
            project_root = safe_extract_zip(archive, temp_path / "unpacked")
            self.assertTrue((project_root / "project.godot").is_file())

    def test_reject_path_traversal(self):
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            archive = temp_path / "bad.zip"
            with zipfile.ZipFile(archive, "w") as zf:
                zf.writestr("../escape.txt", "no")
            with self.assertRaises(ArchiveValidationError):
                safe_extract_zip(archive, temp_path / "out")

    def test_reject_non_zip(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "not.zip"
            path.write_text("no", encoding="utf-8")
            with self.assertRaises(ArchiveValidationError):
                safe_extract_zip(path, Path(temp) / "out")

    def test_reject_zip_without_project_file(self):
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            archive = temp_path / "incomplete.zip"
            with zipfile.ZipFile(archive, "w") as zf:
                zf.writestr("README.txt", "not a Godot project")
            with self.assertRaisesRegex(ArchiveValidationError, "project.godot"):
                safe_extract_zip(archive, temp_path / "out")


class ParserTests(unittest.TestCase):
    def test_tscn_hierarchy_and_subresources(self):
        doc = parse_tscn(FIXTURE / "Scenes" / "Main.tscn")
        self.assertEqual(doc.root.name, "Main")
        self.assertEqual(len(doc.nodes), 11)
        self.assertEqual(doc.warnings, [])
        self.assertIn("BoxMesh_floor", doc.sub_resources)
        floor = next(node for node in doc.nodes if node.name == "Floor")
        self.assertEqual([child.name for child in floor.children], ["FloorMesh", "FloorCollision"])

    def test_packed_scene_instance_is_retained(self):
        import tempfile
        source = (
            '[gd_scene load_steps=2 format=3]\n'
            '[ext_resource type="PackedScene" path="res://Scenes/Child.tscn" id="1_child"]\n'
            '[node name="Root" type="Node3D"]\n'
            '[node name="Child" parent="." instance=ExtResource("1_child")]\n'
        )
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "root.tscn"
            path.write_text(source, encoding="utf-8")
            doc = parse_tscn(path)
            self.assertEqual(doc.root.children[0].type, "PackedSceneInstance")
            self.assertIn("instance", doc.root.children[0].properties)


class ScriptTests(unittest.TestCase):
    def test_supported_subset_and_unsupported_api_warning(self):
        result = translate_gdscript(FIXTURE / "Scripts" / "player.gd")
        self.assertIn("function script:_ready()", result.output_text)
        self.assertIn("script.speed = 5.0", result.output_text)
        self.assertTrue(any("move_and_slide" in warning for warning in result.unsupported))
        self.assertIn("TODO", result.output_text)

    def test_if_and_range_translation(self):
        source = "func sample(n: int):\n    if n > 0:\n        for i in range(n):\n            print(i)\n    else:\n        print(0)\n"
        result = translate_gdscript(Path("sample.gd"), source)
        self.assertIn("if n > 0 then", result.output_text)
        self.assertIn("for i = 0, (n) - 1 do", result.output_text)
        self.assertGreaterEqual(result.output_text.count("end"), 3)

    def test_unsupported_condition_does_not_emit_live_branch_body(self):
        source = (
            "func sample():\n"
            "    if Input.is_action_pressed(\"jump\"):\n"
            "        print(\"would be unsafe to guess\")\n"
            "    else:\n"
            "        print(\"also guarded by unsupported condition\")\n"
            "    print(\"after branch\")\n"
        )
        result = translate_gdscript(Path("sample.gd"), source)
        self.assertTrue(any("Input." in warning for warning in result.unsupported))
        self.assertIn("print(\"after branch\")", result.output_text)
        live_lines = [line.strip() for line in result.output_text.splitlines() if not line.lstrip().startswith("--")]
        self.assertNotIn("print(\"would be unsafe to guess\")", live_lines)
        self.assertNotIn("print(\"also guarded by unsupported condition\")", live_lines)


class ConversionTests(unittest.TestCase):
    def test_reject_project_without_scenes(self):
        with tempfile.TemporaryDirectory() as temp:
            project = Path(temp) / "project"
            project.mkdir()
            (project / "project.godot").write_text('[application]\nconfig/name="No Scene"\n', encoding="utf-8")
            with self.assertRaisesRegex(ValueError, r"\.tscn"):
                GodotBridgeConverter(Path(temp) / "out").convert_project(project)

    def test_end_to_end_generates_rbxmx_and_report(self):
        with tempfile.TemporaryDirectory() as temp:
            output = GodotBridgeConverter(Path(temp) / "out").convert_project(FIXTURE)
            rbxmx = output / "Scenes" / "Roblox" / "Scenes" / "Main.rbxmx"
            self.assertTrue(rbxmx.is_file())
            root = ET.parse(rbxmx).getroot()
            self.assertEqual(root.tag, "roblox")
            classes = [item.attrib.get("class") for item in root.iter("Item")]
            self.assertIn("Part", classes)
            self.assertIn("Camera", classes)
            report = (output / "Reports" / "import_report.json").read_text(encoding="utf-8")
            self.assertIn('"status": "PARTIAL"', report)
            self.assertIn('"textures": 2', report)
            self.assertIn('"audio": 1', report)
            self.assertIn('"model_files": 1', report)
            luau = output / "Scripts" / "Luau" / "Scripts" / "player.luau"
            self.assertTrue(luau.is_file())
            self.assertIn("move_and_slide", luau.read_text(encoding="utf-8"))
            place = ROOT / "roblox" / "GodotBridgeExperience.rbxlx"
            place_xml = ET.parse(place).getroot()
            self.assertEqual(place_xml.tag, "roblox")


class ArchiveHardeningTests(unittest.TestCase):
    def test_reject_case_insensitive_duplicate_paths(self):
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            archive = temp_path / "duplicate.zip"
            with zipfile.ZipFile(archive, "w") as zf:
                zf.writestr("Assets/Tree.png", b"one")
                zf.writestr("assets/tree.PNG", b"two")
            with self.assertRaisesRegex(ArchiveValidationError, "Повторяющийся путь"):
                safe_extract_zip(archive, temp_path / "out")
            self.assertFalse((temp_path / "out").exists())

    def test_reject_windows_reserved_device_names(self):
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            archive = temp_path / "reserved.zip"
            with zipfile.ZipFile(archive, "w") as zf:
                zf.writestr("CON.txt", "not allowed")
            with self.assertRaisesRegex(ArchiveValidationError, "Зарезервированное имя"):
                safe_extract_zip(archive, temp_path / "out")

    def test_reject_when_extraction_disk_is_too_full(self):
        from collections import namedtuple
        from unittest.mock import patch
        usage = namedtuple("Usage", "total used free")(1000, 990, 10)
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            archive = temp_path / "small.zip"
            with zipfile.ZipFile(archive, "w") as zf:
                zf.writestr("project.godot", "[application]")
            with patch("godotbridge.archive.shutil.disk_usage", return_value=usage):
                with self.assertRaisesRegex(ArchiveValidationError, "Недостаточно места для распаковки"):
                    safe_extract_zip(archive, temp_path / "out")
            self.assertFalse((temp_path / "out").exists())

    def test_reject_backslash_paths(self):
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            archive = temp_path / "backslash.zip"
            with zipfile.ZipFile(archive, "w") as zf:
                zf.writestr(r"folder\\..\\escape.txt", "bad")
            with self.assertRaisesRegex(ArchiveValidationError, "обратной косой чертой"):
                safe_extract_zip(archive, temp_path / "out")

    def test_reject_file_used_as_parent_folder(self):
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            archive = temp_path / "conflict.zip"
            with zipfile.ZipFile(archive, "w") as zf:
                zf.writestr("Assets", "file")
                zf.writestr("Assets/Tree.png", "child")
            with self.assertRaisesRegex(ArchiveValidationError, "используется как папка"):
                safe_extract_zip(archive, temp_path / "out")

    def test_reject_encrypted_archive_flag(self):
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            archive = temp_path / "encrypted.zip"
            with zipfile.ZipFile(archive, "w") as zf:
                zf.writestr("project.godot", "[application]")
            # Set the general-purpose encrypted bit in the local and central headers.
            payload = bytearray(archive.read_bytes())
            local = payload.find(b"PK\x03\x04")
            central = payload.find(b"PK\x01\x02")
            payload[local + 6] |= 0x01
            payload[central + 8] |= 0x01
            archive.write_bytes(payload)
            with self.assertRaisesRegex(ArchiveValidationError, "паролем"):
                safe_extract_zip(archive, temp_path / "out")


class ReliabilityTests(unittest.TestCase):
    def test_lazy_package_import_and_version(self):
        import godotbridge
        self.assertEqual(godotbridge.__version__, "0.1.3")
        self.assertTrue(callable(godotbridge.run_gui))

    def test_failed_conversion_does_not_leave_partial_output(self):
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            project = temp_path / "NoScenes"
            project.mkdir()
            (project / "project.godot").write_text('[application]\nconfig/name="No Scenes"\n', encoding="utf-8")
            (project / "broken.tscn").write_text("not a scene", encoding="utf-8")
            output = temp_path / "ConvertedGames"
            with self.assertRaisesRegex(ValueError, "Ни одну сцену не удалось преобразовать"):
                GodotBridgeConverter(output).convert_project(project)
            if output.exists():
                self.assertEqual(list(output.iterdir()), [])

    def test_second_conversion_uses_new_folder_without_overwriting_first(self):
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "out"
            converter = GodotBridgeConverter(output)
            first = converter.convert_project(FIXTURE)
            first_report = first / "Reports" / "import_report.json"
            first_content = first_report.read_text(encoding="utf-8")
            second = converter.convert_project(FIXTURE)
            self.assertNotEqual(first, second)
            self.assertTrue(first_report.is_file())
            self.assertEqual(first_report.read_text(encoding="utf-8"), first_content)
            self.assertTrue((second / "Reports" / "import_report.json").is_file())


    def test_system_check_reports_version_python_and_output_access(self):
        from godotbridge.diagnostics import build_diagnostic_report
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "results"
            report = build_diagnostic_report(output)
            self.assertIn("GodotBridge: v0.1.3", report)
            self.assertIn("Python:", report)
            self.assertIn("Tkinter:", report)
            self.assertIn("доступна для записи", report)
            self.assertTrue(output.is_dir())

    def test_cli_version_does_not_require_desktop_window(self):
        import subprocess
        env = dict(__import__("os").environ)
        env["PYTHONPATH"] = str(CONVERTER)
        result = subprocess.run(
            [sys.executable, "-m", "godotbridge.cli", "--version"],
            cwd=CONVERTER,
            env=env,
            capture_output=True,
            text=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("GodotBridge 0.1.3", result.stdout)

    def test_output_path_inside_source_project_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            project = root / "project"
            import shutil as _shutil
            _shutil.copytree(FIXTURE, project)
            with self.assertRaisesRegex(ValueError, "не должна находиться внутри"):
                GodotBridgeConverter(project / "ConvertedGames").convert_project(project)

    def test_report_contains_converter_version(self):
        with tempfile.TemporaryDirectory() as temp:
            output = GodotBridgeConverter(Path(temp) / "out").convert_project(FIXTURE)
            report = (output / "Reports" / "import_report.json").read_text(encoding="utf-8")
            self.assertIn('"converter_version": "0.1.3"', report)
            markdown = (output / "Reports" / "import_report.md").read_text(encoding="utf-8")
            self.assertIn("**Converter version:** 0.1.3", markdown)

    def test_corrupted_project_report_is_handled_without_crash(self):
        from godotbridge.gui import GodotBridgeApp
        with tempfile.TemporaryDirectory() as temp:
            report = Path(temp) / "import_report.json"
            report.write_text("{ broken json", encoding="utf-8")
            status = GodotBridgeApp._read_game_status(report)
            self.assertIn("отчёт не прочитан", status)



if __name__ == "__main__":
    unittest.main(verbosity=2)
