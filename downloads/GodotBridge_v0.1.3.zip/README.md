# GODOTBRIDGE 0.1.3

**Godot → Roblox conversion starter project.** This repository contains a Windows desktop converter, Roblox Experience source and seed place file, a small Godot fixture, automated tests, and a sample conversion.

> Compatibility note: there is no general-purpose lossless Godot-to-Roblox translator. This version performs real static `.tscn` parsing, creates Roblox XML model files (`.rbxmx`) for a conservative set of nodes, stages resources, and translates a small GDScript subset to review-required Luau. It does not claim that arbitrary Godot gameplay becomes a playable Roblox game without manual work.

## Пошаговая установка

Подробная русская инструкция находится в `ПОШАГОВАЯ УСТАНОВКА.txt` в корне папки GodotBridge и рядом с `run_converter.bat` в папке `converter`. В ней описаны установка Python/Tkinter, запуск, подготовка ZIP, результаты, диагностика и особенности импорта в Roblox Studio.

## Quick start

### Windows desktop app

1. Extract the complete ZIP.
2. Install Python 3.10+ from python.org and include the `tcl/tk and IDLE` option.
3. Open the `converter` folder. Use the right-click context-menu launch option with the file icon for `run_converter.bat` (or the same verified context-menu method for `run_converter.py`). On the tested PC, ordinary left double-click caused the known startup error; keep using the working right-click method.
4. Use **ПРОВЕРКА СИСТЕМЫ** in the main menu to inspect the Python/Tkinter installation, required files, output-folder access and free disk space. Full error details are saved in the per-user log file shown there.
5. Select a ZIP containing one complete Godot project. The archive must contain `project.godot`, `.tscn` scenes, and any scripts/resources.
6. Open the generated `Reports/import_report.md`, then inspect `RobloxProject/ConvertedScene.rbxmx` in Roblox Studio.

To build a standalone Windows executable, run `converter/build_windows.bat` on Windows. The build script uses PyInstaller. A Windows `.exe` is not included because this build environment is Linux.

### Roblox Experience

- `roblox/GodotBridgeExperience.rbxlx` is a generated seed place file. Open it in Roblox Studio and check it before publishing.
- The editable source scripts are in `roblox/StarterPlayerScripts/` and `roblox/ServerScriptService/`.
- Manual install steps are in `roblox/README.md`.

The experience main screen contains two actions: **ЗАГРУЗИТЬ ФАЙЛ .GODOT** (shows truthful instructions to use the desktop converter) and **ИГРЫ** (loads a server-owned game catalog with date/status/thumbnail fields and a playable demo map). Published games can be added manually to the server allowlist after they are published as places within the same Roblox experience. The local ZIP is not uploaded from Roblox because a Roblox experience cannot read arbitrary files from the player's computer.

## Architecture

```text
GodotBridge/
├── converter/                 # Python 3 desktop app + CLI
│   └── godotbridge/
│       ├── archive.py         # ZIP safety and extraction
│       ├── parser.py          # project.godot + .tscn text parser
│       ├── scripts.py         # conservative GDScript → Luau subset
│       ├── convert.py         # scene/resource/RBXMX/report generation
│       ├── diagnostics.py     # environment check and rotating error logs
│       └── gui.py             # Tkinter desktop UI
├── roblox/                    # Roblox Experience scripts + seed .rbxlx
├── examples/TestGodotProject/ # Godot test fixture
├── examples/ConvertedDemo/    # converter output from the fixture
├── tests/                     # automated tests
└── docs/                      # support matrix, security and workflow
```

## Automated tests

From the repository root:

```powershell
py -3 -m unittest discover -s tests -v
```

Tests cover safe and transactional ZIP extraction, Windows-specific ZIP path validation, `.tscn` hierarchy/subresource parsing, a small GDScript subset, `.rbxmx` XML output, conversion cleanup, non-overwriting output folders, malformed reports, and package version/import behavior. Test results from the development environment are included in `docs/TEST_RESULTS.txt`.

## Output layout

Each converted project includes:

```text
<ConvertedProject>/
├── ConvertedGame/manifest.json
├── Assets/
├── Models/
├── Textures/
├── Audio/
├── Scripts/
│   ├── GodotSource/
│   └── Luau/
├── Scenes/
│   ├── GodotSource/
│   └── Roblox/
├── Reports/import_report.md
├── Reports/import_report.json
├── RobloxProject/ConvertedScene.rbxmx
└── README.txt
```

See `docs/SUPPORTED_FEATURES.md` and `docs/LIMITATIONS.md` before using the converter for a real game.


## Roblox Experience UI v0.1.1

The Roblox place now has a refreshed navy/cyan menu, a PC-only conversion notice, and an import page with a selectable direct download URL. See `roblox/README.md` for update steps and the platform limitation around external browser links.


## Startup troubleshooting

If `run_converter.bat` reports an error and asks you to press a key, it is closing after a failed startup. Read the error shown immediately above the prompt. The launcher checks Python 3.10+, Tkinter, and the required program files. Keep using the tested right-click context-menu method for BAT/PY startup; ordinary left double-click is not the recommended method on the tested PC. The in-app system check and rotating log file help diagnose later issues. Do not run it from the ZIP preview: extract the entire archive first.

## GodotBridge v0.1.3

This release focuses on installation diagnostics and reliability rather than changing the user's established startup method. It adds a system-check screen, rotating error logs, improved ZIP validation, disk/output-folder preflight checks, safer result staging, XML validation before publishing a conversion result, and defensive handling of damaged reports. See `CHANGELOG_v0.1.3.md`.


## Windows release smoke test

The Linux automated test results do not verify the Windows context-menu launcher or Roblox Studio. Use [`docs/WINDOWS_RELEASE_CHECKLIST.md`](docs/WINDOWS_RELEASE_CHECKLIST.md) for the final manual check on Windows.
