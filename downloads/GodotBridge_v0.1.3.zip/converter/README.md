# GodotBridge Converter

GodotBridge v0.1.3 — Windows desktop converter, Python 3.10+; runtime dependencies: Python standard library only (Tkinter is included with the standard Windows Python installer when the Tcl/Tk option is selected).

## Run on Windows

1. Extract the complete GodotBridge ZIP (do not run it from inside the ZIP preview).
2. Install Python 3.10+ from python.org and include the `tcl/tk and IDLE` option.
3. Open the `converter` folder. Use the right-click context-menu launch option with the file icon for `run_converter.bat` (or the same verified context-menu method for `run_converter.py`). On the tested PC, ordinary left double-click caused the known startup error; keep using the working right-click method.
4. Use **ПРОВЕРКА СИСТЕМЫ** in the main menu to inspect Python/Tkinter, required files, output-folder access and free disk space. Full error details are saved in the per-user log file shown there.
5. Choose a ZIP containing one complete Godot project. The ZIP must include `project.godot`, `.tscn` scenes and any required resources.

For CLI use (without the desktop interface):

```powershell
cd converter
py -3 -m godotbridge.cli path\to\godot-project.zip --output path\to\ConvertedGames
```

## Build a Windows executable

Run `build_windows.bat` from a Windows machine with Python installed. It installs PyInstaller and creates `dist\GodotBridgeConverter.exe`. This repository includes the build recipe; a Windows executable is not prebuilt in this Linux environment.

## Security

The converter does not run Godot, GDScript, shell scripts, imported binaries or generated Luau. ZIP extraction rejects traversal paths, symlinks, duplicate paths and excessive archive sizes. The parser treats project files as data.


## Troubleshooting startup

- If the launcher says Python was not found, install Python 3.10 or newer from https://www.python.org/downloads/windows/.
- In the installer, include **tcl/tk and IDLE** so the Tkinter desktop interface is available.
- Extract the whole ZIP before launching; `run_converter.py` and the `godotbridge` folder must remain beside `run_converter.bat`.
- If the window still fails, run `run_converter.bat` again and send a screenshot of the full console error.

## v0.1.3 reliability improvements

- Added an in-app system check for Python, Tkinter, required program files, output-folder write access and free disk space.
- Added rotating per-user diagnostic logs and clearer error messages. Unexpected UI/import exceptions are logged with tracebacks.
- Conversion now writes into a temporary staging directory and only publishes a result after generated RBXMX files pass XML validation. Failed imports do not leave a partial game in the output list.
- Improved ZIP validation: rejects encrypted archives, unsupported compression, Windows-reserved filenames, special files, file/directory path conflicts and actual expanded-size overruns. Extraction is staged and moved into place only after successful validation.
- Made the package import lazy so CLI use does not require Tkinter.
- Added safeguards for damaged reports and inaccessible output folders in the «Мои игры» screen.
