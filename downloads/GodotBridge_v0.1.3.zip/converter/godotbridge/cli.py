from __future__ import annotations

import argparse
from pathlib import Path

from . import __version__
from .convert import GodotBridgeConverter
from .diagnostics import configure_logging, format_user_error, get_log_path


def main() -> int:
    parser = argparse.ArgumentParser(
        description="GodotBridge — конвертер Godot ZIP-проектов в Roblox-совместимые файлы"
    )
    parser.add_argument("archive", type=Path, help="ZIP-архив полного Godot-проекта")
    parser.add_argument(
        "--output",
        type=Path,
        default=Path.home() / "GodotBridge" / "ConvertedGames",
        help="Папка результатов",
    )
    parser.add_argument("--version", action="version", version=f"GodotBridge {__version__}")
    args = parser.parse_args()
    logger = configure_logging()

    if not args.archive.is_file():
        parser.error(f"ZIP-файл не найден: {args.archive}")

    def progress(value: float, message: str):
        print(f"[{value * 100:5.1f}%] {message}", flush=True)

    try:
        result = GodotBridgeConverter(args.output).convert_archive(args.archive, progress)
    except Exception as exc:
        logger.exception("Ошибка CLI-конвертации для %s", args.archive)
        print(f"\nОШИБКА: {format_user_error(exc)}")
        return 2

    print(f"\nГотово: {result}")
    print(f"Отчёт: {result / 'Reports' / 'import_report.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
