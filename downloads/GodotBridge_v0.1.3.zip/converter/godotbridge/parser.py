from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class GodotNode:
    name: str
    type: str
    parent: str = "."
    properties: dict[str, str] = field(default_factory=dict)
    children: list["GodotNode"] = field(default_factory=list)
    line: int = 0


@dataclass
class SceneDocument:
    path: Path
    nodes: list[GodotNode]
    root: GodotNode
    ext_resources: dict[str, dict[str, str]]
    sub_resources: dict[str, dict[str, Any]]
    warnings: list[str] = field(default_factory=list)


_HEADER_ATTR = re.compile(r'([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(?:"([^"]*)"|([^\s]+))')
_SECTION = re.compile(r'^\s*\[([^\]]+)\]\s*$')
_PROPERTY = re.compile(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$')


def _attrs(text: str) -> dict[str, str]:
    return {m.group(1): (m.group(2) if m.group(2) is not None else m.group(3)) for m in _HEADER_ATTR.finditer(text)}


def parse_vector(value: str, dimensions: int = 3, default: tuple[float, ...] | None = None) -> tuple[float, ...]:
    default = default or (0.0,) * dimensions
    match = re.search(r"Vector[23]\s*\((.*?)\)", value)
    if not match:
        return default
    try:
        nums = [float(x.strip()) for x in match.group(1).split(",") if x.strip()]
        if len(nums) < dimensions:
            nums += list(default[len(nums):])
        return tuple(nums[:dimensions])
    except ValueError:
        return default


def parse_color(value: str) -> tuple[float, float, float, float] | None:
    match = re.search(r"Color\s*\((.*?)\)", value)
    if not match:
        return None
    try:
        vals = [float(x.strip()) for x in match.group(1).split(",") if x.strip()]
        if len(vals) == 3:
            vals.append(1.0)
        if len(vals) >= 4:
            return tuple(max(0.0, min(1.0, v)) for v in vals[:4])  # type: ignore[return-value]
    except ValueError:
        pass
    return None


def resolve_resource(value: str, resources: dict[str, dict[str, str]]) -> dict[str, str] | None:
    match = re.search(r'ExtResource\s*\(\s*["\']?([^"\')]+)', value)
    if match:
        return resources.get(match.group(1).strip())
    return None


def resolve_subresource(value: str, resources: dict[str, dict[str, Any]]) -> dict[str, Any] | None:
    match = re.search(r'SubResource\s*\(\s*["\']?([^"\')]+)', value)
    if match:
        return resources.get(match.group(1).strip())
    return None


def parse_tscn(path: Path) -> SceneDocument:
    """Parse the text sections of a .tscn file without loading it in Godot."""
    path = Path(path)
    try:
        lines = path.read_text(encoding="utf-8-sig", errors="replace").splitlines()
    except OSError as exc:
        raise ValueError(f"Не удалось прочитать сцену {path.name}: {exc}") from exc

    ext_resources: dict[str, dict[str, str]] = {}
    sub_resources: dict[str, dict[str, Any]] = {}
    node_sections: list[tuple[dict[str, str], dict[str, str], int]] = []
    current_kind: str | None = None
    current_attrs: dict[str, str] = {}
    current_properties: dict[str, str] = {}
    current_line = 0

    def flush() -> None:
        nonlocal current_kind, current_attrs, current_properties, current_line
        if current_kind == "ext_resource":
            rid = current_attrs.get("id")
            if rid:
                ext_resources[rid] = dict(current_attrs)
        elif current_kind == "sub_resource":
            rid = current_attrs.get("id")
            if rid:
                sub_resources[rid] = {"type": current_attrs.get("type", "Resource"), **current_properties}
        elif current_kind == "node":
            node_sections.append((dict(current_attrs), dict(current_properties), current_line))
        current_kind = None
        current_attrs = {}
        current_properties = {}

    for number, line in enumerate(lines, start=1):
        stripped = line.strip()
        if not stripped or stripped.startswith(";") or stripped.startswith("#"):
            continue
        section = _SECTION.match(line)
        if section:
            flush()
            header = section.group(1)
            kind = header.split(None, 1)[0]
            current_kind = kind if kind in {"node", "ext_resource", "sub_resource"} else "other"
            current_attrs = _attrs(header[len(kind):])
            current_line = number
            continue
        if current_kind in {"node", "ext_resource", "sub_resource"}:
            prop = _PROPERTY.match(line)
            if prop:
                current_properties[prop.group(1)] = prop.group(2)
    flush()

    nodes: list[GodotNode] = []
    parse_warnings: list[str] = []
    for attrs, props, line_no in node_sections:
        node_type = attrs.get("type")
        if not node_type and attrs.get("instance"):
            node_type = "PackedSceneInstance"
        if not node_type:
            parse_warnings.append(f"Строка {line_no}: узел без type/instance пропущен.")
            continue
        node_properties = dict(props)
        if attrs.get("instance"):
            node_properties["instance"] = attrs["instance"]
        nodes.append(GodotNode(
            name=attrs.get("name", f"Node_{line_no}"),
            type=node_type,
            parent=attrs.get("parent", "."),
            properties=node_properties,
            line=line_no,
        ))

    if not nodes:
        raise ValueError(f"В сцене {path.name} не найдено ни одного [node].")

    # In Godot .tscn syntax, parent="." means a direct child of the first scene node;
    # the first [node] section itself is the scene root.
    root = nodes[0]
    by_path: dict[str, GodotNode] = {root.name: root}
    warnings: list[str] = list(parse_warnings)
    for node in nodes[1:]:
        key = node.name if node.parent == "." else f"{node.parent}/{node.name}"
        parent = root if node.parent == "." else by_path.get(node.parent)
        if parent is None:
            warnings.append(f"Строка {node.line}: не найден родительский узел {node.parent!r}; узел {node.name} прикреплён к корню.")
            parent = root
        parent.children.append(node)
        by_path[key] = node
    return SceneDocument(path, nodes, root, ext_resources, sub_resources, warnings)


def read_project_config(path: Path) -> dict[str, str]:
    """Read the small subset of project.godot metadata needed by the converter."""
    values: dict[str, str] = {}
    section = ""
    for raw in Path(path).read_text(encoding="utf-8-sig", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith(";") or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1].strip()
            continue
        if section == "application" and "=" in line:
            key, value = line.split("=", 1)
            values[key.strip()] = value.strip().strip('"')
    return values
