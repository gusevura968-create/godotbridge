from __future__ import annotations

import json
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from .convert import GodotBridgeConverter
from .diagnostics import (
    APP_VERSION,
    build_diagnostic_report,
    configure_logging,
    format_user_error,
    get_log_path,
)


BG = "#0A1020"
PANEL = "#111B30"
PANEL_2 = "#17243D"
TEXT = "#F2F7FF"
MUTED = "#9DAFC8"
ACCENT = "#35BDF2"
ACCENT_HOVER = "#62D0F7"


class GodotBridgeApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.logger = configure_logging()
        self.root.title(f"GodotBridge Converter v{APP_VERSION}")
        self.root.geometry("900x680")
        self.root.minsize(760, 580)
        self.root.configure(bg=BG)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.report_callback_exception = self._report_tk_exception

        self.output_dir = Path.home() / "GodotBridge" / "ConvertedGames"
        self.converter = GodotBridgeConverter(self.output_dir)
        self.events: queue.Queue = queue.Queue()
        self.is_busy = False
        self._build_style()
        self.show_home()
        self.root.after(100, self._poll_events)

    def _report_tk_exception(self, exc_type, exc_value, exc_traceback):
        self.logger.error(
            "Необработанная ошибка интерфейса Tkinter",
            exc_info=(exc_type, exc_value, exc_traceback),
        )
        try:
            messagebox.showerror(
                "Ошибка интерфейса",
                f"Произошла ошибка интерфейса.\n\n{exc_value}\n\nПолный журнал: {get_log_path()}",
                parent=self.root,
            )
        except tk.TclError:
            pass

    def _on_close(self):
        if self.is_busy:
            messagebox.showwarning(
                "Импорт выполняется",
                "Сейчас идёт конвертация проекта. Дождитесь её завершения, прежде чем закрывать GodotBridge.",
                parent=self.root,
            )
            return
        self.root.destroy()

    def _build_style(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure(
            "GB.Horizontal.TProgressbar",
            troughcolor=PANEL_2,
            background=ACCENT,
            bordercolor=PANEL_2,
            lightcolor=ACCENT,
            darkcolor=ACCENT,
        )

    def _clear(self):
        for child in self.root.winfo_children():
            child.destroy()

    def _label(self, parent, text, size=12, color=TEXT, weight="normal"):
        return tk.Label(
            parent,
            text=text,
            bg=parent.cget("bg"),
            fg=color,
            font=("Segoe UI", size, weight),
            justify="center",
            wraplength=680,
        )

    def _button(self, parent, text, command, primary=True, width=34):
        color = ACCENT if primary else PANEL_2
        hover = ACCENT_HOVER if primary else "#233653"
        fg = "#06111E" if primary else TEXT
        button = tk.Button(
            parent,
            text=text,
            command=command,
            width=width,
            height=2,
            bg=color,
            fg=fg,
            activebackground=hover,
            activeforeground=fg,
            relief="flat",
            bd=0,
            cursor="hand2",
            font=("Segoe UI", 10, "bold"),
            disabledforeground="#70829A",
        )
        button.bind("<Enter>", lambda _e: button.configure(bg=hover) if str(button["state"]) != "disabled" else None)
        button.bind("<Leave>", lambda _e: button.configure(bg=color if primary else PANEL_2) if str(button["state"]) != "disabled" else None)
        return button

    def _header(self, subtitle: str):
        top = tk.Frame(self.root, bg=BG)
        top.pack(fill="x", padx=42, pady=(25, 10))
        self._label(top, "GODOTBRIDGE", 27, TEXT, "bold").pack()
        self._label(top, subtitle, 10, MUTED).pack(pady=(6, 0))

    def show_home(self):
        self._clear()
        self._header("CONVERTER • GODOT → ROBLOX")
        panel = tk.Frame(self.root, bg=PANEL, padx=40, pady=30)
        panel.pack(expand=True, padx=70, pady=22, fill="both")
        self._label(
            panel,
            "Импортируйте ZIP полного Godot-проекта и получите Roblox-совместимые файлы.",
            13,
            TEXT,
        ).pack(pady=(4, 22))
        self._button(panel, "ЗАГРУЗИТЬ ПРОЕКТ GODOT (.ZIP)", self.choose_project, True, 36).pack(pady=8)
        self._button(panel, "МОИ ИГРЫ", self.show_games, False, 36).pack(pady=8)
        self._button(panel, "ПРОВЕРКА СИСТЕМЫ", self.show_diagnostics, False, 36).pack(pady=8)
        self._label(
            panel,
            "Нужен ZIP, внутри которого находится project.godot, сцены .tscn, скрипты и ресурсы.",
            10,
            MUTED,
        ).pack(pady=(18, 2))
        footer = tk.Frame(self.root, bg=BG)
        footer.pack(fill="x", padx=35, pady=(0, 16))
        self._label(footer, f"Папка результатов: {self.output_dir}", 9, MUTED).pack()
        self._label(footer, f"Версия {APP_VERSION} • Журнал ошибок: {get_log_path()}", 8, MUTED).pack(pady=(4, 0))

    def show_diagnostics(self):
        try:
            report = build_diagnostic_report(self.output_dir)
            messagebox.showinfo("Проверка системы GodotBridge", report, parent=self.root)
        except Exception as exc:
            self.logger.exception("Не удалось сформировать диагностику")
            messagebox.showerror("Ошибка диагностики", format_user_error(exc), parent=self.root)

    def choose_project(self):
        if self.is_busy:
            return
        path = filedialog.askopenfilename(
            title="Выберите ZIP Godot-проекта",
            filetypes=[("Godot project archive", "*.zip"), ("All files", "*.*")],
        )
        if path:
            self.start_import(Path(path))

    def start_import(self, archive: Path):
        if not archive.is_file():
            messagebox.showerror("Файл не найден", f"Выбранный ZIP не найден:\n{archive}", parent=self.root)
            return

        self._clear()
        self._header("ИМПОРТ ПРОЕКТА")
        panel = tk.Frame(self.root, bg=PANEL, padx=34, pady=30)
        panel.pack(expand=True, fill="both", padx=70, pady=28)
        self._label(panel, archive.name, 13, TEXT, "bold").pack(pady=(0, 8))
        self.status_label = self._label(panel, "Подготовка…", 11, MUTED)
        self.status_label.pack(pady=14)
        self.progress = ttk.Progressbar(panel, style="GB.Horizontal.TProgressbar", mode="determinate", maximum=100)
        self.progress.pack(fill="x", padx=25, pady=16)
        self.result_label = self._label(
            panel,
            "Архив будет проверен до распаковки. GDScript не запускается.",
            10,
            MUTED,
        )
        self.result_label.pack(pady=12)
        self.home_button = self._button(panel, "НАЗАД В МЕНЮ", self.show_home, False)
        self.home_button.pack(pady=(18, 0))
        self.home_button.configure(state="disabled")
        self.is_busy = True

        def worker():
            try:
                output = self.converter.convert_archive(
                    archive,
                    lambda value, message: self.events.put(("progress", value, message)),
                )
                self.events.put(("done", str(output)))
            except Exception as exc:
                self.logger.exception("Импорт завершился ошибкой для архива %s", archive)
                self.events.put(("error", format_user_error(exc)))

        threading.Thread(target=worker, name="GodotBridgeImport", daemon=True).start()

    def _poll_events(self):
        try:
            while True:
                event = self.events.get_nowait()
                if event[0] == "progress":
                    _, value, message = event
                    if hasattr(self, "progress") and self.progress.winfo_exists():
                        self.progress["value"] = max(0, min(100, value * 100))
                        self.status_label.configure(text=message)
                elif event[0] == "done":
                    self.is_busy = False
                    output = Path(event[1])
                    self.progress["value"] = 100
                    self.status_label.configure(text="Импорт завершён")
                    self.result_label.configure(
                        text=f"Результат создан:\n{output}\n\nОткройте Reports/import_report.md для деталей."
                    )
                    self.home_button.configure(state="normal")
                    messagebox.showinfo("GodotBridge", f"Импорт завершён.\n\n{output}", parent=self.root)
                elif event[0] == "error":
                    self.is_busy = False
                    self.status_label.configure(text="Импорт остановлен")
                    self.result_label.configure(text=event[1])
                    self.home_button.configure(state="normal")
                    messagebox.showerror("Ошибка импорта", event[1], parent=self.root)
        except queue.Empty:
            pass
        except tk.TclError:
            return

        try:
            if self.root.winfo_exists():
                self.root.after(100, self._poll_events)
        except tk.TclError:
            pass

    @staticmethod
    def _read_game_status(report_path: Path) -> str:
        if not report_path.is_file():
            return "Результат найден • отчёт отсутствует"
        try:
            data = json.loads(report_path.read_text(encoding="utf-8"))
            if not isinstance(data, dict):
                raise ValueError("корневой элемент отчёта должен быть объектом JSON")
            converted = data.get("converted", {})
            if not isinstance(converted, dict):
                converted = {}
            imported = data.get("imported_at_utc", "")
            if isinstance(imported, str) and imported:
                imported = imported.replace("T", " ").replace("+00:00", " UTC")
            return (
                f"Импорт: {imported or 'дата неизвестна'} • "
                f"{data.get('status', 'UNKNOWN')} • "
                f"сцен: {converted.get('scenes_to_rbxmx', 0)}"
            )
        except (OSError, UnicodeError, json.JSONDecodeError, ValueError, TypeError) as exc:
            return f"Результат найден • отчёт не прочитан ({exc})"

    def show_games(self):
        self._clear()
        self._header("МОИ ИГРЫ")
        panel = tk.Frame(self.root, bg=PANEL, padx=26, pady=24)
        panel.pack(expand=True, fill="both", padx=55, pady=25)
        try:
            if self.output_dir.exists() and not self.output_dir.is_dir():
                raise NotADirectoryError(f"Путь результатов существует, но это не папка: {self.output_dir}")
            items = sorted(
                (
                    p for p in self.output_dir.iterdir()
                    if p.is_dir() and not p.name.startswith(".godotbridge_staging_")
                ),
                key=lambda p: p.stat().st_mtime,
                reverse=True,
            ) if self.output_dir.exists() else []
        except OSError as exc:
            self.logger.exception("Не удалось прочитать папку результатов")
            self._label(panel, f"Не удалось открыть папку результатов:\n{exc}\n\nЖурнал: {get_log_path()}", 11, MUTED).pack(expand=True)
            self._button(self.root, "НАЗАД В МЕНЮ", self.show_home, False, 24).pack(pady=(0, 22))
            return

        if not items:
            self._label(panel, "Здесь пока нет импортированных игр.", 13, MUTED).pack(expand=True)
        else:
            canvas = tk.Canvas(panel, bg=PANEL, highlightthickness=0)
            scrollbar = ttk.Scrollbar(panel, orient="vertical", command=canvas.yview)
            inner = tk.Frame(canvas, bg=PANEL)
            inner.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
            canvas.create_window((0, 0), window=inner, anchor="nw")
            canvas.configure(yscrollcommand=scrollbar.set)
            canvas.pack(side="left", fill="both", expand=True)
            scrollbar.pack(side="right", fill="y")
            for item in items:
                card = tk.Frame(inner, bg=PANEL_2, padx=16, pady=13)
                card.pack(fill="x", pady=7, padx=6)
                report_path = item / "Reports" / "import_report.json"
                status = self._read_game_status(report_path)
                title = tk.Label(card, text=item.name, bg=PANEL_2, fg=TEXT, font=("Segoe UI", 12, "bold"), anchor="w")
                title.pack(fill="x")
                tk.Label(card, text=status, bg=PANEL_2, fg=MUTED, font=("Segoe UI", 9), anchor="w").pack(fill="x", pady=(4, 8))
                row = tk.Frame(card, bg=PANEL_2)
                row.pack(fill="x")
                tk.Button(
                    row,
                    text="ОТКРЫТЬ ПАПКУ",
                    command=lambda p=item: self.open_folder(p),
                    bg=ACCENT,
                    fg="#06111E",
                    relief="flat",
                    padx=14,
                    pady=6,
                    cursor="hand2",
                ).pack(side="left")
                tk.Button(
                    row,
                    text="ОТЧЁТ",
                    command=lambda p=report_path: self.open_file(p),
                    bg="#263954",
                    fg=TEXT,
                    relief="flat",
                    padx=14,
                    pady=6,
                    cursor="hand2",
                ).pack(side="left", padx=8)
        self._button(self.root, "НАЗАД В МЕНЮ", self.show_home, False, 24).pack(pady=(0, 22))

    @staticmethod
    def open_folder(path: Path):
        try:
            if os.name == "nt":
                os.startfile(str(path))  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except Exception as exc:
            configure_logging().exception("Не удалось открыть папку результата %s", path)
            messagebox.showerror("Не удалось открыть папку", f"{exc}\n\nЖурнал: {get_log_path()}")

    @staticmethod
    def open_file(path: Path):
        if not path.exists():
            messagebox.showwarning("Нет отчёта", "Файл отчёта не найден.")
            return
        try:
            if os.name == "nt":
                os.startfile(str(path))  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
        except Exception as exc:
            configure_logging().exception("Не удалось открыть отчёт %s", path)
            messagebox.showerror("Не удалось открыть отчёт", f"{exc}\n\nЖурнал: {get_log_path()}")


def run_gui():
    root = tk.Tk()
    GodotBridgeApp(root)
    root.mainloop()
