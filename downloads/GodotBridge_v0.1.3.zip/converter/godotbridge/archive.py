from __future__ import annotations

import os
import shutil
import stat
import tempfile
import zipfile
import zlib
from pathlib import Path, PurePosixPath


class ArchiveValidationError(ValueError):
    """Raised when an input archive is invalid or unsafe to extract."""


MAX_FILES = 50_000
MAX_TOTAL_UNCOMPRESSED = 1_000_000_000  # 1 GB
MAX_SINGLE_FILE = 250_000_000           # 250 MB
MAX_COMPRESSION_RATIO = 1_000
CHUNK_SIZE = 1024 * 1024
SUPPORTED_COMPRESSION = {
    zipfile.ZIP_STORED,
    zipfile.ZIP_DEFLATED,
    zipfile.ZIP_BZIP2,
    zipfile.ZIP_LZMA,
}
WINDOWS_RESERVED_NAMES = {
    "CON", "PRN", "AUX", "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
}


def _validated_member_name(info: zipfile.ZipInfo) -> tuple[PurePosixPath, bool, str]:
    """Return a safe POSIX path, directory flag and Windows-safe comparison key."""
    raw_name = info.filename
    if not raw_name or "\x00" in raw_name:
        raise ArchiveValidationError("В ZIP найден файл с пустым или некорректным именем.")
    if "\\" in raw_name:
        raise ArchiveValidationError(
            f"В ZIP найден путь с обратной косой чертой: {raw_name!r}. Пересоздайте архив стандартным ZIP-архиватором."
        )
    if raw_name.startswith("/") or raw_name.startswith("//"):
        raise ArchiveValidationError(f"Абсолютный путь в ZIP запрещён: {raw_name!r}")

    mode = (info.external_attr >> 16) & 0xFFFF
    file_type = stat.S_IFMT(mode)
    is_directory = info.is_dir() or stat.S_ISDIR(mode)
    if stat.S_ISLNK(mode):
        raise ArchiveValidationError(f"Символические ссылки в ZIP запрещены: {raw_name!r}")
    if file_type not in (0, stat.S_IFREG, stat.S_IFDIR):
        raise ArchiveValidationError(f"Специальные файлы в ZIP запрещены: {raw_name!r}")

    name = raw_name[:-1] if is_directory and raw_name.endswith("/") else raw_name
    parts = name.split("/")
    if not parts or any(part in ("", ".", "..") for part in parts):
        raise ArchiveValidationError(f"Небезопасный путь внутри ZIP: {raw_name!r}")

    for part in parts:
        if any(ord(char) < 32 for char in part) or any(char in '<>:"|?*' for char in part):
            raise ArchiveValidationError(f"Имя файла недопустимо для Windows: {raw_name!r}")
        if part.endswith((" ", ".")):
            raise ArchiveValidationError(f"Имя с точкой или пробелом в конце запрещено: {raw_name!r}")
        device_name = part.split(".", 1)[0].upper()
        if device_name in WINDOWS_RESERVED_NAMES:
            raise ArchiveValidationError(f"Зарезервированное имя Windows в ZIP запрещено: {raw_name!r}")

    pure = PurePosixPath(*parts)
    normalized = "/".join(part.casefold() for part in parts)
    return pure, is_directory, normalized


def safe_extract_zip(archive_path: Path, destination: Path) -> Path:
    """Safely extract one Godot ZIP into a fresh destination directory.

    The archive is validated before extraction. Extraction occurs in a temporary
    sibling directory and is moved into place only after the whole archive has
    been read successfully. Returns the directory containing project.godot.
    No extracted file is executed.
    """
    archive_path = Path(archive_path).expanduser()
    destination = Path(destination).expanduser().absolute()
    if not archive_path.is_file():
        raise ArchiveValidationError(f"ZIP-файл не найден: {archive_path}")
    if not zipfile.is_zipfile(archive_path):
        raise ArchiveValidationError("Файл не является корректным ZIP-архивом.")

    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.is_symlink():
        raise ArchiveValidationError("Папка распаковки не должна быть символической ссылкой.")
    if destination.exists():
        if not destination.is_dir() or any(destination.iterdir()):
            raise ArchiveValidationError("Папка распаковки уже существует и не пуста. Выберите новую временную папку.")

    staging = Path(tempfile.mkdtemp(prefix=f".{destination.name}.extract-", dir=destination.parent))
    try:
        seen: dict[str, bool] = {}
        file_paths: set[str] = set()
        members: list[tuple[zipfile.ZipInfo, PurePosixPath, bool, str]] = []
        declared_total = 0

        try:
            with zipfile.ZipFile(archive_path, "r") as zf:
                infos = zf.infolist()
                if not infos:
                    raise ArchiveValidationError("ZIP-архив пуст.")
                if len(infos) > MAX_FILES:
                    raise ArchiveValidationError(f"В архиве слишком много элементов (лимит: {MAX_FILES}).")

                for info in infos:
                    if info.flag_bits & 0x1:
                        raise ArchiveValidationError("Защищённые паролем ZIP-архивы не поддерживаются.")
                    if info.compress_type not in SUPPORTED_COMPRESSION:
                        raise ArchiveValidationError(f"Неизвестный метод сжатия у файла {info.filename!r}.")

                    relative, is_directory, normalized = _validated_member_name(info)
                    if normalized in seen:
                        raise ArchiveValidationError(f"Повторяющийся путь в ZIP (без учёта регистра): {info.filename!r}")
                    seen[normalized] = is_directory
                    if not is_directory:
                        file_paths.add(normalized)
                        if info.file_size < 0 or info.file_size > MAX_SINGLE_FILE:
                            raise ArchiveValidationError(f"Файл слишком большой: {info.filename!r}")
                        declared_total += info.file_size
                        if declared_total > MAX_TOTAL_UNCOMPRESSED:
                            raise ArchiveValidationError("Распакованный архив превышает лимит 1 ГБ.")
                        if info.file_size > 1_000_000:
                            compressed = max(info.compress_size, 1)
                            if info.file_size / compressed > MAX_COMPRESSION_RATIO:
                                raise ArchiveValidationError(f"Подозрительная степень сжатия: {info.filename!r}")
                    members.append((info, relative, is_directory, normalized))

                # Check the temporary extraction volume before writing even the first file.
                required_temp_space = declared_total + 32 * 1024 * 1024
                free_temp_space = shutil.disk_usage(destination.parent).free
                if free_temp_space < required_temp_space:
                    required_gb = required_temp_space / (1024 ** 3)
                    free_gb = free_temp_space / (1024 ** 3)
                    raise ArchiveValidationError(
                        f"Недостаточно места для распаковки ZIP. Нужно примерно {required_gb:.2f} ГБ, "
                        f"доступно {free_gb:.2f} ГБ. Выберите диск со свободным местом."
                    )

                # A regular file cannot also be used as a parent directory.
                for _info, relative, _is_directory, normalized in members:
                    parent = relative.parent
                    while parent.parts:
                        if "/".join(part.casefold() for part in parent.parts) in file_paths:
                            raise ArchiveValidationError(
                                f"Структура ZIP конфликтует: файл используется как папка ({relative.as_posix()!r})."
                            )
                        parent = parent.parent

                actual_total = 0
                for info, relative, is_directory, _normalized in members:
                    target = staging.joinpath(*relative.parts)
                    if is_directory:
                        target.mkdir(parents=True, exist_ok=True)
                        continue
                    target.parent.mkdir(parents=True, exist_ok=True)
                    written = 0
                    try:
                        with zf.open(info, "r") as source, target.open("xb") as output:
                            while True:
                                chunk = source.read(CHUNK_SIZE)
                                if not chunk:
                                    break
                                written += len(chunk)
                                actual_total += len(chunk)
                                if written > MAX_SINGLE_FILE:
                                    raise ArchiveValidationError(f"Файл превышает лимит при распаковке: {info.filename!r}")
                                if actual_total > MAX_TOTAL_UNCOMPRESSED:
                                    raise ArchiveValidationError("Фактический размер распаковки превышает лимит 1 ГБ.")
                                output.write(chunk)
                    except (zipfile.BadZipFile, RuntimeError, NotImplementedError, EOFError, zlib.error) as exc:
                        raise ArchiveValidationError(f"Не удалось распаковать {info.filename!r}: {exc}") from exc
                    if written != info.file_size:
                        raise ArchiveValidationError(
                            f"Размер файла {info.filename!r} не совпадает с данными ZIP. Архив повреждён."
                        )

        except ArchiveValidationError:
            raise
        except (zipfile.BadZipFile, OSError, RuntimeError, NotImplementedError, EOFError, zlib.error) as exc:
            raise ArchiveValidationError(f"Не удалось безопасно прочитать ZIP: {exc}") from exc

        projects = [p for p in staging.rglob("project.godot") if p.is_file() and not p.is_symlink()]
        if not projects:
            raise ArchiveValidationError("В ZIP не найден project.godot. Нужен полный Godot-проект.")
        if len(projects) > 1:
            shown = ", ".join(str(p.relative_to(staging)) for p in projects[:4])
            suffix = " …" if len(projects) > 4 else ""
            raise ArchiveValidationError(
                f"В архиве найдено несколько файлов project.godot ({shown}{suffix}). Упакуйте один проект в ZIP."
            )

        project_relative = projects[0].parent.relative_to(staging)
        if destination.exists():
            destination.rmdir()  # It was verified to be empty above.
        os.replace(staging, destination)
        return destination / project_relative
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        raise
