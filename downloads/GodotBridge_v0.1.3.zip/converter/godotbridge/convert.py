from __future__ import annotations

import json
import math
import os
import re
import shutil
import tempfile
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Callable

from .archive import safe_extract_zip
from .parser import (
    GodotNode, SceneDocument, parse_color, parse_tscn, parse_vector,
    read_project_config, resolve_resource, resolve_subresource,
)
from .scripts import TranslationResult, translate_gdscript

ProgressCallback = Callable[[float, str], None]

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tga"}
AUDIO_EXTS = {".wav", ".ogg", ".mp3", ".flac"}
MODEL_EXTS = {".glb", ".gltf", ".obj", ".fbx", ".dae", ".blend"}


@dataclass
class ImportReport:
    converter_version: str
    project: str
    source: str
    imported_at_utc: str
    status: str
    found: dict[str, int]
    staged: dict[str, int]
    converted: dict[str, int]
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)


@dataclass
class Transform:
    position: tuple[float, float, float] = (0.0, 0.0, 0.0)
    rotation: tuple[tuple[float, float, float], ...] = ((1, 0, 0), (0, 1, 0), (0, 0, 1))
    scale: tuple[float, float, float] = (1.0, 1.0, 1.0)


def _mat_mul(a, b):
    return tuple(tuple(sum(a[i][k] * b[k][j] for k in range(3)) for j in range(3)) for i in range(3))


def _mat_vec(a, v):
    return tuple(sum(a[i][j] * v[j] for j in range(3)) for i in range(3))


def _rotation_matrix(euler_degrees: tuple[float, float, float]):
    x, y, z = (math.radians(v) for v in euler_degrees)
    cx, sx, cy, sy, cz, sz = math.cos(x), math.sin(x), math.cos(y), math.sin(y), math.cos(z), math.sin(z)
    rx = ((1, 0, 0), (0, cx, -sx), (0, sx, cx))
    ry = ((cy, 0, sy), (0, 1, 0), (-sy, 0, cy))
    rz = ((cz, -sz, 0), (sz, cz, 0), (0, 0, 1))
    return _mat_mul(_mat_mul(rz, ry), rx)


def _compose(parent: Transform, node: GodotNode) -> Transform:
    is_2d = node.type in {"Node2D", "Sprite2D", "Camera2D", "CollisionShape2D", "Area2D", "StaticBody2D", "CharacterBody2D", "RigidBody2D"}
    raw_pos = node.properties.get("position", "")
    if "Vector2" in raw_pos or is_2d:
        px, py = parse_vector(raw_pos, 2, (0.0, 0.0))
        local_pos = (px, -py, 0.0)
    else:
        local_pos = parse_vector(raw_pos, 3, (0.0, 0.0, 0.0))
    raw_scale = node.properties.get("scale", "")
    if "Vector2" in raw_scale or is_2d:
        sx, sy = parse_vector(raw_scale, 2, (1.0, 1.0))
        local_scale = (sx, sy, 1.0)
    else:
        local_scale = parse_vector(raw_scale, 3, (1.0, 1.0, 1.0))
    if "rotation_degrees" in node.properties:
        if is_2d:
            try:
                rz = -float(node.properties["rotation_degrees"])
            except ValueError:
                rz = -parse_vector(node.properties["rotation_degrees"], 1, (0.0,))[0]
            local_rot = (0.0, 0.0, rz)
        else:
            local_rot = parse_vector(node.properties["rotation_degrees"], 3, (0.0, 0.0, 0.0))
    elif "rotation" in node.properties:
        if is_2d:
            try:
                rz = -math.degrees(float(node.properties["rotation"]))
            except ValueError:
                rz = -math.degrees(parse_vector(node.properties["rotation"], 1, (0.0,))[0])
            local_rot = (0.0, 0.0, rz)
        else:
            local_rot = tuple(math.degrees(v) for v in parse_vector(node.properties["rotation"], 3, (0.0, 0.0, 0.0)))
    else:
        local_rot = (0.0, 0.0, 0.0)
    scaled_pos = tuple(local_pos[i] * parent.scale[i] for i in range(3))
    rotated_pos = _mat_vec(parent.rotation, scaled_pos)
    world_pos = tuple(parent.position[i] + rotated_pos[i] for i in range(3))
    world_rot = _mat_mul(parent.rotation, _rotation_matrix(local_rot))
    world_scale = tuple(parent.scale[i] * local_scale[i] for i in range(3))
    return Transform(world_pos, world_rot, world_scale)


def _safe_name(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9 _.-]+", "_", value).strip(" .")
    return (value or "GodotNode")[:100]


def _xml_prop(parent: ET.Element, tag: str, name: str, value: str) -> None:
    el = ET.SubElement(parent, tag, {"name": name})
    el.text = value


def _float_prop(parent: ET.Element, name: str, value: float) -> None:
    el = ET.SubElement(parent, "float", {"name": name})
    el.text = f"{float(value):.6g}"


def _bool_prop(parent: ET.Element, name: str, value: bool) -> None:
    el = ET.SubElement(parent, "bool", {"name": name})
    el.text = "true" if value else "false"


def _vector_prop(parent: ET.Element, tag: str, name: str, value: tuple[float, float, float]) -> None:
    el = ET.SubElement(parent, tag, {"name": name})
    for axis, number in zip(("X", "Y", "Z"), value):
        child = ET.SubElement(el, axis)
        child.text = f"{float(number):.6g}"


def _color_prop(parent: ET.Element, name: str, value: tuple[float, float, float]) -> None:
    el = ET.SubElement(parent, "Color3", {"name": name})
    for axis, number in zip(("R", "G", "B"), value):
        child = ET.SubElement(el, axis)
        child.text = f"{max(0.0, min(1.0, float(number))):.6g}"


def _cframe_prop(parent: ET.Element, transform: Transform) -> None:
    el = ET.SubElement(parent, "CoordinateFrame", {"name": "CFrame"})
    for axis, number in zip(("X", "Y", "Z"), transform.position):
        child = ET.SubElement(el, axis)
        child.text = f"{float(number):.6g}"
    for r in range(3):
        for c in range(3):
            child = ET.SubElement(el, f"R{r}{c}")
            child.text = f"{float(transform.rotation[r][c]):.8g}"


class RbxmxWriter:
    def __init__(self):
        self._next = 0

    def instance(self, parent: ET.Element, class_name: str, name: str, props: list[tuple] | None = None) -> ET.Element:
        self._next += 1
        item = ET.SubElement(parent, "Item", {"class": class_name, "referent": f"RBX{self._next}"})
        properties = ET.SubElement(item, "Properties")
        _xml_prop(properties, "string", "Name", name)
        _bool_prop(properties, "Archivable", True)
        for prop in props or []:
            kind = prop[0]
            if kind == "string":
                _xml_prop(properties, "string", prop[1], str(prop[2]))
            elif kind == "bool":
                _bool_prop(properties, prop[1], bool(prop[2]))
            elif kind == "float":
                _float_prop(properties, prop[1], float(prop[2]))
            elif kind == "token":
                el = ET.SubElement(properties, "token", {"name": prop[1]})
                el.text = str(int(prop[2]))
            elif kind == "vector3":
                _vector_prop(properties, "Vector3", prop[1], prop[2])
            elif kind == "color3":
                _color_prop(properties, prop[1], prop[2])
            elif kind == "cframe":
                _cframe_prop(properties, prop[2])
        return item

    def write_model(self, name: str, children: list[ET.Element]) -> str:
        root = ET.Element("roblox", {"version": "4"})
        model = self.instance(root, "Model", name)
        for child in children:
            model.append(child)
        return ET.tostring(root, encoding="unicode", xml_declaration=True)


def _part_shape_token(node: GodotNode, doc: SceneDocument) -> int:
    mesh = resolve_subresource(node.properties.get("mesh", ""), doc.sub_resources)
    shape = resolve_subresource(node.properties.get("shape", ""), doc.sub_resources)
    resource_type = (mesh or shape or {}).get("type", "")
    if resource_type in {"SphereMesh", "SphereShape3D", "CircleShape2D"}:
        return 0  # Roblox Enum.PartType.Ball
    if resource_type in {"CylinderMesh", "CylinderShape3D"}:
        return 2  # Roblox Enum.PartType.Cylinder
    return 1  # Roblox Enum.PartType.Block


def _mesh_size(node: GodotNode, doc: SceneDocument) -> tuple[float, float, float]:
    mesh = resolve_subresource(node.properties.get("mesh", ""), doc.sub_resources)
    if mesh:
        kind = mesh.get("type", "")
        if kind in {"BoxMesh", "PlaneMesh"} and "size" in mesh:
            if "Vector2" in mesh["size"]:
                x, y = parse_vector(mesh["size"], 2, (1.0, 1.0))
                return (x, y, 0.2 if kind == "PlaneMesh" else 1.0)
            return parse_vector(mesh["size"], 3, (1.0, 1.0, 1.0))
        if kind == "SphereMesh":
            radius = float(mesh.get("radius", "0.5"))
            return (radius * 2, radius * 2, radius * 2)
        if kind in {"CylinderMesh", "CapsuleMesh"}:
            radius = float(mesh.get("radius", "0.5"))
            height = float(mesh.get("height", "2.0"))
            return (radius * 2, height, radius * 2)
    shape = resolve_subresource(node.properties.get("shape", ""), doc.sub_resources)
    if shape:
        kind = shape.get("type", "")
        if kind in {"BoxShape3D", "BoxShape2D"} and "size" in shape:
            if "Vector2" in shape["size"]:
                x, y = parse_vector(shape["size"], 2, (1.0, 1.0))
                return (x, y, 0.2)
            return parse_vector(shape["size"], 3, (1.0, 1.0, 1.0))
        if kind in {"SphereShape3D", "CircleShape2D"}:
            radius = float(shape.get("radius", "0.5"))
            depth = radius * 2 if kind == "SphereShape3D" else 0.2
            return (radius * 2, radius * 2, depth)
        if kind in {"CapsuleShape3D", "CylinderShape3D", "CapsuleShape2D"}:
            radius = float(shape.get("radius", "0.5"))
            height = float(shape.get("height", "2.0"))
            return (radius * 2, height, radius * 2)
    if node.type == "Sprite2D":
        return (1.0, 1.0, 0.15)
    return (1.0, 1.0, 1.0)


def _node_color(node: GodotNode, doc: SceneDocument) -> tuple[float, float, float]:
    for key in ("modulate", "self_modulate", "color", "light_color"):
        parsed = parse_color(node.properties.get(key, ""))
        if parsed:
            return parsed[:3]
    material_value = node.properties.get("surface_material_override/0", "")
    material = resolve_subresource(material_value, doc.sub_resources)
    if material and "albedo_color" in material:
        parsed = parse_color(material["albedo_color"])
        if parsed:
            return parsed[:3]
    return (0.35, 0.68, 0.95)


def _resource_note(node: GodotNode, doc: SceneDocument, key: str) -> str | None:
    resource = resolve_resource(node.properties.get(key, ""), doc.ext_resources)
    if resource:
        return resource.get("path")
    return None


def _material_texture_source(node: GodotNode, doc: SceneDocument) -> str | None:
    material = resolve_subresource(node.properties.get("surface_material_override/0", ""), doc.sub_resources)
    if not material:
        return None
    resource = resolve_resource(material.get("albedo_texture", ""), doc.ext_resources)
    return resource.get("path") if resource else None


def _build_node(
    node: GodotNode,
    doc: SceneDocument,
    parent_xml: ET.Element,
    writer: RbxmxWriter,
    parent_transform: Transform,
    counters: Counter,
    warnings: list[str],
    project_root: Path,
) -> None:
    transform = _compose(parent_transform, node)
    name = _safe_name(node.name)
    typ = node.type
    part_classes = {"MeshInstance3D", "Sprite2D", "CollisionShape3D", "CollisionShape2D"}
    model_classes = {
        "Node", "Node2D", "Node3D", "StaticBody3D", "RigidBody3D", "CharacterBody3D",
        "Area3D", "StaticBody2D", "RigidBody2D", "CharacterBody2D", "Area2D", "CanvasLayer", "Control", "PackedSceneInstance",
    }

    if typ in part_classes:
        size = _mesh_size(node, doc)
        scaled_size = tuple(max(0.05, abs(size[i] * transform.scale[i])) for i in range(3))
        is_collision = typ.startswith("Collision")
        visible = node.properties.get("visible", "true").lower() != "false"
        alpha = 1.0
        color_with_alpha = None
        for key in ("modulate", "self_modulate"):
            color_with_alpha = parse_color(node.properties.get(key, ""))
            if color_with_alpha:
                alpha = color_with_alpha[3]
                break
        transparency = 1.0 if is_collision or not visible else 1.0 - alpha
        props = [
            ("bool", "Anchored", True),
            ("token", "Shape", _part_shape_token(node, doc)),
            ("bool", "CanCollide", is_collision),
            ("float", "Transparency", transparency),
            ("cframe", "CFrame", transform),
            ("vector3", "Size", scaled_size),
            ("color3", "Color", _node_color(node, doc)),
        ]
        part = writer.instance(parent_xml, "Part", name, props)
        if typ in {"MeshInstance3D", "CollisionShape3D", "CollisionShape2D"}:
            shape_resource = resolve_subresource(node.properties.get("mesh", node.properties.get("shape", "")), doc.sub_resources)
            if shape_resource and shape_resource.get("type", "") in {"CapsuleMesh", "CapsuleShape3D", "CapsuleShape2D"}:
                warnings.append(f"{node.name}: Capsule представлен приближённым блоком; форма капсулы не сохраняется.")
        if typ == "Sprite2D":
            texture_path = _resource_note(node, doc, "texture")
            if texture_path:
                writer.instance(part, "StringValue", "GodotBridge_TextureSource", [("string", "Value", texture_path)])
                warnings.append(f"{node.name}: текстура {texture_path} экспортирована отдельно; её нужно загрузить в Roblox и назначить вручную.")
            counters["objects"] += 1
        elif typ == "MeshInstance3D":
            mesh_path = _resource_note(node, doc, "mesh")
            mesh_resource = resolve_subresource(node.properties.get("mesh", ""), doc.sub_resources)
            texture_path = _material_texture_source(node, doc)
            if mesh_path:
                writer.instance(part, "StringValue", "GodotBridge_SourceMesh", [("string", "Value", mesh_path)])
                warnings.append(f"{node.name}: исходная модель {mesh_path} сохранена в Models/; в RBXMX пока оставлена Part-заглушка.")
            elif not mesh_resource or mesh_resource.get("type", "") not in {"BoxMesh", "SphereMesh", "CylinderMesh", "PlaneMesh"}:
                warnings.append(f"{node.name}: MeshInstance3D представлен приближённым Part; исходная геометрия не распознана.")
            if texture_path:
                writer.instance(part, "StringValue", "GodotBridge_TextureSource", [("string", "Value", texture_path)])
                warnings.append(f"{node.name}: текстура материала {texture_path} экспортирована отдельно; загрузите её в Roblox и назначьте вручную.")
            counters["objects"] += 1
        elif is_collision:
            counters["objects"] += 1
        return

    if typ in {"Camera3D", "Camera2D"}:
        writer.instance(parent_xml, "Camera", name, [
            ("cframe", "CFrame", transform),
            ("float", "FieldOfView", float(node.properties.get("fov", "75"))),
        ])
        counters["objects"] += 1
        if typ == "Camera2D":
            warnings.append(f"{node.name}: Camera2D преобразована в перспективную Camera; 2D-проекция Godot не сохраняется.")
        warnings.append(f"{node.name}: Camera создана как Instance; назначьте её Workspace.CurrentCamera скриптом в Roblox Studio.")
        return

    if typ in {"OmniLight3D", "SpotLight3D"}:
        host = writer.instance(parent_xml, "Part", name + "_LightHost", [
            ("bool", "Anchored", True), ("bool", "CanCollide", False), ("float", "Transparency", 1.0),
            ("vector3", "Size", (0.2, 0.2, 0.2)), ("cframe", "CFrame", transform),
        ])
        light_type = "PointLight" if typ == "OmniLight3D" else "SpotLight"
        color = _node_color(node, doc)
        energy = float(node.properties.get("light_energy", "1.0"))
        light_props = [
            ("float", "Brightness", max(0.0, energy)),
            ("float", "Range", max(0.1, float(node.properties.get("omni_range", "16")))),
            ("color3", "Color", color),
            ("bool", "Enabled", node.properties.get("visible", "true").lower() != "false"),
        ]
        if typ == "SpotLight3D":
            light_props.append(("float", "Angle", max(0.0, min(180.0, float(node.properties.get("spot_angle", "45"))))))
        writer.instance(host, light_type, name, light_props)
        counters["objects"] += 1
        return

    if typ == "DirectionalLight3D":
        warnings.append(f"{node.name}: DirectionalLight3D не имеет прямого локального аналога; настройте Lighting.ClockTime/Environment вручную.")
        writer.instance(parent_xml, "StringValue", name + "_GodotLightInfo", [("string", "Value", "DirectionalLight3D; manual Lighting setup required")])
        return

    if typ.startswith("AudioStreamPlayer"):
        stream_path = _resource_note(node, doc, "stream")
        volume_db = float(node.properties.get("volume_db", "0"))
        linear_volume = max(0.0, min(10.0, 10 ** (volume_db / 20.0)))
        host = writer.instance(parent_xml, "Part", name + "_AudioHost", [
            ("bool", "Anchored", True), ("bool", "CanCollide", False), ("float", "Transparency", 1.0),
            ("vector3", "Size", (0.2, 0.2, 0.2)), ("cframe", "CFrame", transform),
        ])
        sound = writer.instance(host, "Sound", name, [
            ("float", "Volume", linear_volume),
            ("bool", "Looped", node.properties.get("loop", "false").lower() == "true"),
        ])
        if stream_path:
            writer.instance(sound, "StringValue", "GodotBridge_AudioSource", [("string", "Value", stream_path)])
        warnings.append(f"{node.name}: Sound создан без SoundId; аудио нужно отдельно загрузить в Roblox и назначить.")
        counters["objects"] += 1
        return

    supported_container = typ in model_classes
    model = writer.instance(parent_xml, "Model", name)
    if supported_container:
        counters["objects"] += 1
        if typ in {"CharacterBody3D", "RigidBody3D", "StaticBody3D", "Area3D", "CharacterBody2D", "RigidBody2D", "StaticBody2D", "Area2D"}:
            warnings.append(f"{node.name}: физика/сигналы {typ} не перенесены автоматически; проверьте коллизии и игровую логику.")
        if typ in {"CanvasLayer", "Control"}:
            warnings.append(f"{node.name}: интерфейсный узел {typ} сохранён только как контейнер; создайте эквивалент ScreenGui/GuiObject вручную.")
    else:
        warnings.append(f"{node.name}: узел типа {typ} сохранён как пустой Model-контейнер; поведение не перенесено.")
    if "script" in node.properties:
        res = resolve_resource(node.properties["script"], doc.ext_resources)
        if res and res.get("path"):
            writer.instance(model, "StringValue", "GodotBridge_AttachedScript", [("string", "Value", res["path"])])
    if typ == "PackedSceneInstance":
        res = resolve_resource(node.properties.get("instance", ""), doc.ext_resources)
        if res and res.get("path"):
            writer.instance(model, "StringValue", "GodotBridge_InstancedScene", [("string", "Value", res["path"])])
            warnings.append(f"{node.name}: вложенная PackedScene {res['path']} помечена метаданными, но не развёрнута рекурсивно.")
    for child in node.children:
        _build_node(child, doc, model, writer, transform, counters, warnings, project_root)


def _write_rbxmx(doc: SceneDocument, project_root: Path, out_path: Path, counters: Counter, warnings: list[str]) -> None:
    writer = RbxmxWriter()
    root_xml = ET.Element("roblox", {"version": "4"})
    model = writer.instance(root_xml, "Model", _safe_name(doc.root.name or doc.path.stem))
    identity = Transform()
    _build_node(doc.root, doc, model, writer, identity, counters, warnings, project_root)
    # If the parsed root had additional children they are already present below the converted root.
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(ET.tostring(root_xml, encoding="unicode", xml_declaration=True), encoding="utf-8")


def _copy_resources(project_root: Path, output_root: Path) -> tuple[dict[str, int], dict[str, list[str]]]:
    counts = Counter()
    manifest: dict[str, list[str]] = {"models": [], "textures": [], "audio": [], "other": []}
    for source in project_root.rglob("*"):
        if not source.is_file() or source.is_symlink():
            continue
        if any(part.casefold() == ".godot" for part in source.relative_to(project_root).parts):
            continue
        ext = source.suffix.lower()
        rel = source.relative_to(project_root)
        if ext in {".godot", ".tscn", ".gd", ".import", ".uid", ".md", ".txt"}:
            continue
        if ext in MODEL_EXTS:
            category, folder, key = "models", "Models", "models"
        elif ext in IMAGE_EXTS:
            category, folder, key = "textures", "Textures", "textures"
        elif ext in AUDIO_EXTS:
            category, folder, key = "audio", "Audio", "audio"
        else:
            category, folder, key = "other", "Assets", "other"
        rel_out = Path(*rel.parts[1:]) if rel.parts and rel.parts[0].casefold() == folder.casefold() else rel
        target = output_root / folder / rel_out
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        manifest[category].append(str((Path(folder) / rel_out).as_posix()))
        counts[key] += 1
    return dict(counts), manifest


def _write_report(report: ImportReport, report_dir: Path) -> None:
    report_dir.mkdir(parents=True, exist_ok=True)
    (report_dir / "import_report.json").write_text(json.dumps(asdict(report), ensure_ascii=False, indent=2), encoding="utf-8")
    lines = [
        "# GODOTBRIDGE IMPORT REPORT", "", f"**Converter version:** {report.converter_version}",
        f"**Project:** {report.project}", f"**Status:** {report.status}",
        f"**Imported (UTC):** {report.imported_at_utc}", "",
        "## Found", "",
    ]
    for key, value in report.found.items():
        lines.append(f"- {key}: {value}")
    lines += ["", "## Staged for Roblox Studio", ""]
    for key, value in report.staged.items():
        lines.append(f"- {key}: {value}")
    lines += ["", "## Converted into RBXMX/Luau output", ""]
    for key, value in report.converted.items():
        lines.append(f"- {key}: {value}")
    lines += ["", "## Warnings", ""]
    lines.extend([f"- {w}" for w in report.warnings] or ["- Нет."])
    lines += ["", "## Errors", ""]
    lines.extend([f"- {e}" for e in report.errors] or ["- Нет."])
    lines += ["", "> RBXMX проверен как XML в рамках автоматических тестов. Файл не открывался в Roblox Studio в этой среде.", ""]
    (report_dir / "import_report.md").write_text("\n".join(lines), encoding="utf-8")


class GodotBridgeConverter:
    def __init__(self, output_directory: Path | None = None):
        self.output_directory = Path(
            output_directory or (Path.home() / "GodotBridge" / "ConvertedGames")
        ).expanduser()

    @staticmethod
    def _unique_output_path(output_directory: Path, project_name: str) -> Path:
        preferred = output_directory / project_name
        if not preferred.exists():
            return preferred
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        candidate = output_directory / f"{project_name}_{stamp}"
        counter = 2
        while candidate.exists():
            candidate = output_directory / f"{project_name}_{stamp}_{counter:02d}"
            counter += 1
        return candidate

    @staticmethod
    def _project_files(project_root: Path) -> list[Path]:
        files: list[Path] = []
        for path in project_root.rglob("*"):
            try:
                relative = path.relative_to(project_root)
                if any(part.casefold() == ".godot" for part in relative.parts):
                    continue
                if path.is_symlink() or not path.is_file():
                    continue
                files.append(path)
            except OSError as exc:
                raise ValueError(f"Не удалось проверить файл проекта {path.name!r}: {exc}") from exc
        if len(files) > 50_000:
            raise ValueError("В проекте слишком много файлов (лимит GodotBridge: 50 000). Удалите временные и лишние файлы и повторите импорт.")
        return sorted(files, key=lambda item: item.as_posix().casefold())

    def convert_archive(self, archive_path: Path, progress: ProgressCallback | None = None) -> Path:
        def tick(value: float, message: str):
            if progress:
                progress(value, message)

        archive_path = Path(archive_path).expanduser()
        tick(0.02, "Проверка ZIP-архива…")
        with tempfile.TemporaryDirectory(prefix="godotbridge_") as temp:
            project_root = safe_extract_zip(archive_path, Path(temp) / "source")
            tick(0.10, "ZIP безопасно распакован. Анализ Godot-проекта…")
            return self.convert_project(
                project_root,
                progress,
                initial_progress=0.10,
                source_label=archive_path.name,
            )

    def convert_project(
        self,
        project_root: Path,
        progress: ProgressCallback | None = None,
        initial_progress: float = 0.0,
        source_label: str | None = None,
    ) -> Path:
        project_root = Path(project_root).expanduser().resolve()
        if not project_root.is_dir():
            raise ValueError(f"Папка Godot-проекта не найдена: {project_root}")
        project_file = project_root / "project.godot"
        if not project_file.is_file() or project_file.is_symlink():
            raise ValueError("В выбранной папке нет обычного файла project.godot.")

        def tick(local: float, message: str):
            if progress:
                progress(max(0.0, min(1.0, initial_progress + (1.0 - initial_progress) * local)), message)

        try:
            config = read_project_config(project_file)
        except (OSError, UnicodeError) as exc:
            raise ValueError(f"Не удалось прочитать project.godot: {exc}") from exc
        raw_title = config.get("config/name", project_root.name)
        project_name = _safe_name(raw_title.strip('"'))

        tick(0.14, "Проверка структуры проекта и свободного места…")
        project_files = self._project_files(project_root)
        scenes = sorted(p for p in project_files if p.suffix.lower() == ".tscn")
        gd_scripts = sorted(p for p in project_files if p.suffix.lower() == ".gd")
        images = [p for p in project_files if p.suffix.lower() in IMAGE_EXTS]
        audio = [p for p in project_files if p.suffix.lower() in AUDIO_EXTS]
        models = [p for p in project_files if p.suffix.lower() in MODEL_EXTS]
        found = {
            "scenes": len(scenes),
            "scripts": len(gd_scripts),
            "textures": len(images),
            "audio": len(audio),
            "model_files": len(models),
        }
        if not scenes:
            raise ValueError(
                "Не найдено ни одной .tscn-сцены. Сейчас GodotBridge поддерживает текстовые сцены .tscn; .scn и другие бинарные сцены не конвертируются."
            )

        output_directory = self.output_directory.resolve()
        try:
            if output_directory == project_root or project_root in output_directory.parents:
                raise ValueError("Папка результатов не должна находиться внутри исходного Godot-проекта.")
            output_directory.mkdir(parents=True, exist_ok=True)
            if not output_directory.is_dir():
                raise NotADirectoryError(f"Путь результатов не является папкой: {output_directory}")
            estimated_input_size = sum(path.stat().st_size for path in project_files)
            required_space = max(64 * 1024 * 1024, int(estimated_input_size * 1.5))
            free_space = shutil.disk_usage(output_directory).free
            if free_space < required_space:
                required_gb = required_space / (1024 ** 3)
                free_gb = free_space / (1024 ** 3)
                raise OSError(
                    f"Недостаточно свободного места для результата. Нужно примерно {required_gb:.2f} ГБ, доступно {free_gb:.2f} ГБ. Освободите место или выберите другой диск."
                )
        except ValueError:
            raise
        except OSError as exc:
            raise OSError(f"Не удалось подготовить папку результатов {output_directory}: {exc}") from exc

        # Build into a private staging directory. A failed import is removed instead
        # of leaving a misleading half-created game in "Мои игры".
        staging_parent = Path(tempfile.mkdtemp(prefix=".godotbridge_staging_", dir=output_directory))
        output_root = staging_parent / project_name
        try:
            for folder in (
                "ConvertedGame", "Assets", "Models", "Textures", "Audio",
                "Scripts/Luau", "Scripts/GodotSource", "Scenes/GodotSource",
                "Scenes/Roblox", "Reports", "RobloxProject",
            ):
                (output_root / folder).mkdir(parents=True, exist_ok=True)

            tick(0.18, "Поиск сцен, скриптов и ресурсов…")

            # Preserve source scenes and scripts for traceability.
            for source in scenes:
                target = output_root / "Scenes/GodotSource" / source.relative_to(project_root)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
            for source in gd_scripts:
                target = output_root / "Scripts/GodotSource" / source.relative_to(project_root)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)

            tick(0.25, "Копирование текстур, моделей и аудио…")
            staged_counts, resource_manifest = _copy_resources(project_root, output_root)
            staged = {
                "textures": staged_counts.get("textures", 0),
                "audio": staged_counts.get("audio", 0),
                "model_files": staged_counts.get("models", 0),
                "other_assets": staged_counts.get("other", 0),
            }

            warnings: list[str] = []
            script_supported = 0
            script_unsupported = 0
            translated_scripts = 0
            for index, source in enumerate(gd_scripts, start=1):
                tick(
                    0.27 + 0.18 * index / max(1, len(gd_scripts)),
                    f"Анализ GDScript: {source.name} ({index}/{len(gd_scripts)})…",
                )
                target = output_root / "Scripts/Luau" / source.relative_to(project_root).with_suffix(".luau")
                target.parent.mkdir(parents=True, exist_ok=True)
                try:
                    result: TranslationResult = translate_gdscript(source)
                    target.write_text(result.output_text, encoding="utf-8")
                    translated_scripts += 1
                    script_supported += result.supported_statements
                    script_unsupported += len(result.unsupported)
                    warnings.extend(
                        f"GDScript {source.relative_to(project_root)}: {item}"
                        for item in result.unsupported
                    )
                except Exception as exc:
                    # One malformed/unsupported script must not discard scenes and assets.
                    target.write_text(
                        "-- GodotBridge could not translate this GDScript file.\n"
                        f"-- Error: {type(exc).__name__}: {exc}\n"
                        "-- Review the original file in Scripts/GodotSource/.\n",
                        encoding="utf-8",
                    )
                    warnings.append(
                        f"GDScript {source.relative_to(project_root)} не переведён: {type(exc).__name__}: {exc}"
                    )
                    translated_scripts += 1

            converted_scene_count = 0
            converted_objects = Counter()
            scene_failures: list[str] = []
            for index, source in enumerate(scenes, start=1):
                tick(
                    0.48 + 0.45 * index / max(1, len(scenes)),
                    f"Преобразование сцены: {source.name} ({index}/{len(scenes)})…",
                )
                try:
                    doc = parse_tscn(source)
                    warnings.extend(
                        f"Сцена {source.relative_to(project_root)}: {warning}"
                        for warning in doc.warnings
                    )
                    dest = output_root / "Scenes/Roblox" / source.relative_to(project_root).with_suffix(".rbxmx")
                    counters = Counter()
                    scene_warnings: list[str] = []
                    _write_rbxmx(doc, project_root, dest, counters, scene_warnings)
                    warnings.extend(
                        f"Сцена {source.relative_to(project_root)}: {warning}"
                        for warning in scene_warnings
                    )
                    converted_scene_count += 1
                    converted_objects.update(counters)
                except Exception as exc:
                    reason = f"Сцена {source.relative_to(project_root)} не преобразована: {type(exc).__name__}: {exc}"
                    warnings.append(reason)
                    scene_failures.append(reason)

            if converted_scene_count == 0:
                details = "\n".join(scene_failures[:5])
                if len(scene_failures) > 5:
                    details += f"\n… и ещё {len(scene_failures) - 5} ошибок."
                raise ValueError(
                    "Ни одну сцену не удалось преобразовать. Проверьте синтаксис .tscn и журнал ошибок.\n" + details
                )

            # A single-scene convenience copy for opening/importing from Studio.
            main_scene_raw = config.get("run/main_scene", "").replace("\\", "/")
            if main_scene_raw.startswith("res://"):
                main_scene_raw = main_scene_raw[6:]
            main_scene_parts = PurePosixPath(main_scene_raw).parts if main_scene_raw else ()
            main_scene_is_safe = (
                bool(main_scene_parts)
                and not PurePosixPath(main_scene_raw).is_absolute()
                and ".." not in main_scene_parts
                and ":" not in main_scene_parts[0]
            )
            preferred_rbxmx = (
                output_root / "Scenes/Roblox" / Path(*main_scene_parts).with_suffix(".rbxmx")
                if main_scene_is_safe else None
            )
            first_rbxmx = (
                preferred_rbxmx
                if preferred_rbxmx and preferred_rbxmx.is_file()
                else next(iter(sorted((output_root / "Scenes/Roblox").rglob("*.rbxmx"))), None)
            )
            if first_rbxmx:
                shutil.copy2(first_rbxmx, output_root / "RobloxProject" / "ConvertedScene.rbxmx")

            manifest = {
                "format_version": "0.1",
                "converter_version": "0.1.3",
                "project": project_name,
                "source_project": source_label or str(project_root),
                "main_scene": config.get("run/main_scene", ""),
                "resources": resource_manifest,
                "generated": {
                    "roblox_scenes": [
                        str(path.relative_to(output_root))
                        for path in (output_root / "Scenes/Roblox").rglob("*.rbxmx")
                    ],
                    "luau_scripts": [
                        str(path.relative_to(output_root))
                        for path in (output_root / "Scripts/Luau").rglob("*.luau")
                    ],
                },
                "notes": [
                    "Модели GLB/GLTF/OBJ/FBX сохранены как отдельные файлы и не встроены в геометрию RBXMX.",
                    "Текстуры и аудио требуют загрузки в Roblox и назначения полученных asset ID.",
                    "Luau-файлы требуют ручной проверки и адаптации к API Roblox.",
                ],
            }
            (output_root / "ConvertedGame/manifest.json").write_text(
                json.dumps(manifest, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )

            converted = {
                "scenes_to_rbxmx": converted_scene_count,
                "scene_nodes_to_roblox_instances": int(converted_objects.get("objects", 0)),
                "luau_files_generated": translated_scripts,
                "gdscript_statements_translated": script_supported,
                "gdscript_statements_flagged": script_unsupported,
            }
            if staged.get("textures") or staged.get("audio") or staged.get("model_files"):
                warnings.append(
                    "Ресурсы скопированы в выходную папку, но не загружены в Roblox Asset Manager; назначение asset ID выполняется вручную."
                )
            if script_unsupported:
                warnings.append(
                    f"Переводчик отметил {script_unsupported} неподдерживаемых/неоднозначных строк GDScript; см. Scripts/Luau и отчёт."
                )
            if scene_failures:
                warnings.append(
                    f"Не удалось преобразовать {len(scene_failures)} из {len(scenes)} сцен; успешно создано: {converted_scene_count}."
                )
            status = "SUCCESS" if not warnings else "PARTIAL"
            report = ImportReport(
                converter_version="0.1.3",
                project=project_name,
                source=source_label or str(project_root),
                imported_at_utc=datetime.now(timezone.utc).isoformat(timespec="seconds"),
                status=status,
                found=found,
                staged=staged,
                converted=converted,
                warnings=warnings,
            )
            _write_report(report, output_root / "Reports")
            self._write_readme(output_root, project_name)

            tick(0.98, "Проверка файлов результата…")
            generated_scenes = list((output_root / "Scenes/Roblox").rglob("*.rbxmx"))
            if not generated_scenes:
                raise ValueError("Конвертация не создала ни одного RBXMX-файла; результат не будет сохранён.")
            for generated in generated_scenes:
                try:
                    ET.parse(generated)
                except ET.ParseError as exc:
                    raise ValueError(f"Создан повреждённый RBXMX-файл {generated.name}: {exc}") from exc

            final_output = self._unique_output_path(output_directory, project_name)
            os.replace(output_root, final_output)
            tick(1.0, "Импорт завершён. Файлы проверены и сохранены.")
            return final_output
        finally:
            shutil.rmtree(staging_parent, ignore_errors=True)

    @staticmethod
    def _write_readme(output_root: Path, project_name: str) -> None:
        text = f"""GODOTBRIDGE — {project_name}
========================================

БЫСТРЫЙ СТАРТ
1. Откройте Roblox Studio и создайте/откройте свой place.
2. В Explorer выберите Workspace, затем используйте File > Insert from File…
   (или импортируйте ConvertedScene.rbxmx через доступный в вашей версии Studio способ).
3. Выберите RobloxProject/ConvertedScene.rbxmx.
4. Проверьте масштаб, ориентацию, коллизии и иерархию.
5. Загрузите файлы из Textures/, Audio/ и Models/ в Roblox Studio/Creator Dashboard.
6. Замените пометки GodotBridge_* на реальные asset ID.
7. Luau находится в Scripts/Luau/. Это черновой перевод: проверьте API и подключите
   ModuleScript/Script вручную. Исходные .gd сохранены в Scripts/GodotSource/.

ЧТО РЕАЛЬНО СДЕЛАНО
- Текстовые .tscn разобраны без запуска Godot и без исполнения пользовательского кода.
- Поддерживаемые узлы сцены сериализованы в RBXMX как Model/Part/Camera/Light/Sound.
- Простые размеры Box/Sphere/Capsule и базовые трансформации сохранены приближённо.
- Внешние ресурсы скопированы в соответствующие папки.
- Для .gd создан Luau-файл с TODO и предупреждениями для неподдерживаемых строк.

ОГРАНИЧЕНИЯ
- Произвольный GDScript не может быть автоматически и безопасно преобразован в эквивалентную игру Roblox.
- GLB/GLTF/OBJ/FBX сохраняются отдельно; их геометрия не встраивается в RBXMX.
- Текстуры/аудио надо загрузить в Roblox и указать выданные asset ID.
- Физика, навигация, анимации, UI, сигналы, шейдеры и игровые механики требуют ручной адаптации.
- Этот результат не проверен запуском в Roblox Studio в текущей среде.

Смотрите Reports/import_report.md и Reports/import_report.json.
"""
        (output_root / "README.txt").write_text(text, encoding="utf-8")
