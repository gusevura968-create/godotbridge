from __future__ import annotations

import traceback


def main() -> int:
    logger = None
    try:
        from godotbridge.diagnostics import configure_logging, get_log_path

        logger = configure_logging()
        from godotbridge.gui import run_gui

        run_gui()
        return 0
    except Exception as exc:
        if logger is not None:
            logger.exception("Не удалось запустить интерфейс GodotBridge")
        else:
            traceback.print_exc()
        try:
            from godotbridge.diagnostics import get_log_path
            log_location = str(get_log_path())
        except Exception:
            log_location = "Журнал недоступен: проверьте установку GodotBridge и Python."
        print("Не удалось запустить GodotBridge.")
        print(f"Причина: {exc}")
        print(f"Подробный журнал: {log_location}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
