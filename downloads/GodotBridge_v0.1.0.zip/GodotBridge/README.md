# GODOTBRIDGE 0.1.0

**Godot → Roblox conversion starter project.** This repository contains a Windows desktop converter, Roblox Experience source and seed place file, a small Godot fixture, automated tests, and a sample conversion.

> Compatibility note: there is no general-purpose lossless Godot-to-Roblox translator. This version performs real static `.tscn` parsing, creates Roblox XML model files (`.rbxmx`) for a conservative set of nodes, stages resources, and translates a small GDScript subset to review-required Luau. It does not claim that arbitrary Godot gameplay becomes a playable Roblox game without manual work.

## Quick start

### Windows desktop app

1. Install Python 3.10+ from python.org and include the Tcl/Tk option.
2. Open `converter` in PowerShell.
3. Run `py -3 run_converter.py`.
4. Select a ZIP containing one complete Godot project. The archive must contain `project.godot`, `.tscn` scenes, and any scripts/resources.
5. Open the generated `Reports/import_report.md`, then inspect `RobloxProject/ConvertedScene.rbxmx` in Roblox Studio.

To build a standalone Windows executable, run `converter/build_windows.bat` on Windows. The build script uses PyInstaller. A Windows `.exe` is not included because this build environment is Linux.

### Roblox Experience

- `roblox/GodotBridgeExperience.rbxlx` is a generated seed place file. Open it in Roblox Studio and check it before publishing.
- The editable source scripts are in `roblox/StarterPlayerScripts/` and `roblox/ServerScriptService/`.
- Manual install steps are in `roblox/README.md`.

The experience main screen contains two actions: **ЗАГРУЗИТЬ ФАЙЛ .GODOT** (shows truthful instructions to use the desktop converter) and **ИГРЫ** (loads a server-owned game catalog with date/status/thumbnail fields and a playable demo map). Published games can be added manually to the server allowlist after they are published as places within the same Roblox experience. The local ZIP is not uploaded from Roblox because a Roblox experience cannot read arbitrary files from the player's computer.

## Architecture

```text
GodotBridge/
├── converter/                 # Python 3 desktop app + CLI
│   └── godotbridge/
│       ├── archive.py         # ZIP safety and extraction
│       ├── parser.py          # project.godot + .tscn text parser
│       ├── scripts.py         # conservative GDScript → Luau subset
│       ├── convert.py         # scene/resource/RBXMX/report generation
│       └── gui.py             # Tkinter desktop UI
├── roblox/                    # Roblox Experience scripts + seed .rbxlx
├── examples/TestGodotProject/ # Godot test fixture
├── examples/ConvertedDemo/    # converter output from the fixture
├── tests/                     # automated tests
└── docs/                      # support matrix, security and workflow
```

## Automated tests

From the repository root:

```powershell
py -3 -m unittest discover -s tests -v
```

Tests cover safe ZIP extraction, ZIP path traversal rejection, `.tscn` hierarchy/subresource parsing, a small GDScript subset, `.rbxmx` XML output, and report generation. Test results from the development environment are included in `docs/TEST_RESULTS.txt`.

## Output layout

Each converted project includes:

```text
<ConvertedProject>/
├── ConvertedGame/manifest.json
├── Assets/
├── Models/
├── Textures/
├── Audio/
├── Scripts/
│   ├── GodotSource/
│   └── Luau/
├── Scenes/
│   ├── GodotSource/
│   └── Roblox/
├── Reports/import_report.md
├── Reports/import_report.json
├── RobloxProject/ConvertedScene.rbxmx
└── README.txt
```

See `docs/SUPPORTED_FEATURES.md` and `docs/LIMITATIONS.md` before using the converter for a real game.
