@echo off
setlocal
cd /d %~dp0
py -3 run_converter.py
if errorlevel 1 pause
endlocal
