# GodotBridge Converter

Windows desktop converter, Python 3.10+; runtime dependencies: Python standard library only (Tkinter is included with the standard Windows Python installer when the Tcl/Tk option is selected).

## Run

```powershell
cd converter
py -3 run_converter.py
```

Choose a ZIP containing one Godot project (`project.godot`, `.tscn`, `.gd`, and resources). For CLI use:

```powershell
py -3 -m godotbridge.cli path\to\godot-project.zip --output path\to\ConvertedGames
```

## Build a Windows executable

Run `build_windows.bat` from a Windows machine with Python installed. It installs PyInstaller and creates `dist\GodotBridgeConverter.exe`. This repository includes the build recipe; a Windows executable is not prebuilt in this Linux environment.

## Security

The converter does not run Godot, GDScript, shell scripts, imported binaries or generated Luau. ZIP extraction rejects traversal paths, symlinks, duplicate paths and excessive archive sizes. The parser treats project files as data.
