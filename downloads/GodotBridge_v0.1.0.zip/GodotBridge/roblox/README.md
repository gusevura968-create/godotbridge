# Roblox Experience source

This folder contains the Roblox Studio scripts and generated seed place (`GodotBridgeExperience.rbxlx`) for the GodotBridge experience. The seed place is XML-validated but must be opened and checked in Roblox Studio before publishing.

- `StarterPlayerScripts/GodotBridge.client.lua` creates the two-button main menu, an honest desktop-import information page, and the demo library card.
- `ServerScriptService/GodotBridgeServer.server.lua` creates a server-owned demo map, returns the catalog, and launches only IDs present in the server-side `PUBLISHED_GAMES` allowlist.

## Install manually

1. Open a new Baseplate in Roblox Studio.
2. Create a `LocalScript` under `StarterPlayer > StarterPlayerScripts` and paste `GodotBridge.client.lua`.
3. Create a `Script` under `ServerScriptService` and paste `GodotBridgeServer.server.lua`.
4. Press Play. The server creates the demo world and the client shows the GodotBridge UI.
5. Publish the place from Studio.

The desktop Converter cannot publish assets or places to a Roblox account. Roblox Experience does not have permission to read a user's local ZIP file. Imported models must be inserted and published in Roblox Studio. The initial server allowlist launches the built-in demo; manually configured published places can be added using the instructions below.

## Add an imported game to the library

1. Convert the Godot project and review the generated assets/scripts.
2. Insert the converted model into a Roblox Studio place, finish manual asset upload and gameplay adaptation, then publish that place inside the same Roblox experience/universe.
3. Edit the `PUBLISHED_GAMES` table near the top of `ServerScriptService/GodotBridgeServer.server.lua`. Add a unique string key, matching `id`, title, description, a truthful import date/status, `thumbnailAssetId`, and the published `placeId`.
4. Rebuild/open the `.rbxlx` or paste the updated server script in Studio and publish the experience.

The client requests display metadata from a server `RemoteFunction`. The server accepts only IDs in its own allowlist and performs the teleport; clients cannot supply arbitrary place IDs. Cross-experience publishing, automatic upload, DataStore catalog synchronization and moderation are not included. Teleport behavior must be tested in a published Roblox environment.
