-- GodotBridge Roblox Experience UI
-- Main menu intentionally contains only two actions. Local files are handled by the desktop Converter.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local player = Players.LocalPlayer
local playRemote = ReplicatedStorage:WaitForChild("GodotBridgePlay")
local catalogRemote = ReplicatedStorage:WaitForChild("GodotBridgeCatalog")

local gui = Instance.new("ScreenGui")
gui.Name = "GodotBridgeUI"
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = true
gui.Parent = player:WaitForChild("PlayerGui")

local COLORS = {
    background = Color3.fromRGB(8, 14, 27),
    panel = Color3.fromRGB(17, 28, 48),
    panel2 = Color3.fromRGB(25, 42, 67),
    text = Color3.fromRGB(241, 247, 255),
    muted = Color3.fromRGB(159, 179, 204),
    accent = Color3.fromRGB(50, 190, 242),
}

local function clearPage()
    for _, child in ipairs(gui:GetChildren()) do
        child:Destroy()
    end
end

local function makeLabel(parent, text, size, color, font)
    local label = Instance.new("TextLabel")
    label.BackgroundTransparency = 1
    label.Text = text
    label.TextColor3 = color or COLORS.text
    label.TextSize = size or 18
    label.Font = font or Enum.Font.Gotham
    label.TextWrapped = true
    label.Parent = parent
    return label
end

local function makeButton(parent, text, callback, primary)
    local button = Instance.new("TextButton")
    button.Name = "ActionButton"
    button.Size = UDim2.new(1, 0, 0, 58)
    button.BackgroundColor3 = primary and COLORS.accent or COLORS.panel2
    button.TextColor3 = primary and Color3.fromRGB(5, 15, 26) or COLORS.text
    button.Text = text
    button.Font = Enum.Font.GothamBold
    button.TextSize = 17
    button.AutoButtonColor = true
    button.Parent = parent
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 12)
    corner.Parent = button
    button.Activated:Connect(callback)
    return button
end

local function makePage()
    clearPage()
    local root = Instance.new("Frame")
    root.Name = "Background"
    root.Size = UDim2.fromScale(1, 1)
    root.BackgroundColor3 = COLORS.background
    root.Parent = gui

    local panel = Instance.new("Frame")
    panel.Name = "Content"
    panel.AnchorPoint = Vector2.new(0.5, 0.5)
    panel.Position = UDim2.fromScale(0.5, 0.5)
    panel.Size = UDim2.new(0, 520, 0, 430)
    panel.BackgroundColor3 = COLORS.panel
    panel.Parent = root
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 18)
    corner.Parent = panel
    local padding = Instance.new("UIPadding")
    padding.PaddingTop = UDim.new(0, 30)
    padding.PaddingBottom = UDim.new(0, 26)
    padding.PaddingLeft = UDim.new(0, 36)
    padding.PaddingRight = UDim.new(0, 36)
    padding.Parent = panel

    local list = Instance.new("UIListLayout")
    list.HorizontalAlignment = Enum.HorizontalAlignment.Center
    list.SortOrder = Enum.SortOrder.LayoutOrder
    list.Padding = UDim.new(0, 16)
    list.Parent = panel
    return root, panel
end

local showMain
local function showImportInfo()
    local _, panel = makePage()
    makeLabel(panel, "ИМПОРТ GODOT-ПРОЕКТА", 24, COLORS.text, Enum.Font.GothamBold).Size = UDim2.new(1, 0, 0, 44)
    makeLabel(panel,
        "Roblox Experience не может открыть ZIP с вашего компьютера.\n\n" ..
        "1. Скачайте и запустите GodotBridge Converter для Windows.\n" ..
        "2. Выберите ZIP полного проекта с project.godot, .tscn, .gd и ресурсами.\n" ..
        "3. Проверьте отчёт и откройте полученный .rbxmx в Roblox Studio.\n" ..
        "4. Загрузите текстуры/аудио и опубликуйте place вручную.",
        15, COLORS.muted).Size = UDim2.new(1, 0, 0, 220)
    makeButton(panel, "НАЗАД", showMain, false)
end

local function addGameThumbnail(parent, entry)
    local thumbnailAssetId = tonumber(entry.thumbnailAssetId) or 0
    if thumbnailAssetId > 0 then
        local image = Instance.new("ImageLabel")
        image.Name = "GameThumbnail"
        image.Position = UDim2.new(0, 10, 0, 9)
        image.Size = UDim2.new(0, 100, 0, 106)
        image.BackgroundColor3 = COLORS.background
        image.Image = "rbxassetid://" .. tostring(thumbnailAssetId)
        image.ScaleType = Enum.ScaleType.Crop
        image.Parent = parent
        local corner = Instance.new("UICorner")
        corner.CornerRadius = UDim.new(0, 8)
        corner.Parent = image
        return
    end

    if entry.id == "demo" then
        local thumbnail = Instance.new("ViewportFrame")
        thumbnail.Name = "GameThumbnail"
        thumbnail.Position = UDim2.new(0, 10, 0, 9)
        thumbnail.Size = UDim2.new(0, 100, 0, 106)
        thumbnail.BackgroundColor3 = COLORS.background
        thumbnail.Ambient = Color3.fromRGB(155, 190, 220)
        thumbnail.LightColor = Color3.fromRGB(255, 255, 255)
        thumbnail.Parent = parent
        local world = Instance.new("WorldModel")
        world.Parent = thumbnail
        local floor = Instance.new("Part")
        floor.Anchored = true
        floor.Size = Vector3.new(7, 0.6, 7)
        floor.Position = Vector3.new(0, -1, 0)
        floor.Color = Color3.fromRGB(35, 61, 88)
        floor.Parent = world
        local orb = Instance.new("Part")
        orb.Anchored = true
        orb.Shape = Enum.PartType.Ball
        orb.Size = Vector3.new(2, 2, 2)
        orb.Position = Vector3.new(0, 0.5, 0)
        orb.Material = Enum.Material.Neon
        orb.Color = COLORS.accent
        orb.Parent = world
        local camera = Instance.new("Camera")
        camera.CFrame = CFrame.lookAt(Vector3.new(5, 4, 7), Vector3.new(0, 0, 0))
        camera.Parent = thumbnail
        thumbnail.CurrentCamera = camera
        return
    end

    local placeholder = Instance.new("Frame")
    placeholder.Name = "GameThumbnailPlaceholder"
    placeholder.Position = UDim2.new(0, 10, 0, 9)
    placeholder.Size = UDim2.new(0, 100, 0, 106)
    placeholder.BackgroundColor3 = COLORS.background
    placeholder.Parent = parent
    makeLabel(placeholder, "GB", 25, COLORS.accent, Enum.Font.GothamBlack).Size = UDim2.fromScale(1, 1)
end

local function showGames()
    local _, panel = makePage()
    local pageTitle = makeLabel(panel, "ИГРЫ", 25, COLORS.text, Enum.Font.GothamBold)
    pageTitle.Size = UDim2.new(1, 0, 0, 42)
    pageTitle.LayoutOrder = 1

    local scroll = Instance.new("ScrollingFrame")
    scroll.Name = "GameLibrary"
    scroll.Size = UDim2.new(1, 0, 0, 220)
    scroll.BackgroundTransparency = 1
    scroll.BorderSizePixel = 0
    scroll.ScrollBarThickness = 5
    scroll.CanvasSize = UDim2.new(0, 0, 0, 0)
    scroll.AutomaticCanvasSize = Enum.AutomaticSize.Y
    scroll.LayoutOrder = 2
    scroll.Parent = panel
    local list = Instance.new("UIListLayout")
    list.SortOrder = Enum.SortOrder.LayoutOrder
    list.Padding = UDim.new(0, 9)
    list.Parent = scroll

    local success, games = pcall(function()
        return catalogRemote:InvokeServer()
    end)
    if not success then
        makeLabel(scroll, "Не удалось получить каталог игр. Попробуйте открыть раздел ещё раз.", 13, COLORS.muted).Size = UDim2.new(1, 0, 0, 56)
    elseif #games == 0 then
        makeLabel(scroll, "Здесь пока нет импортированных игр.", 13, COLORS.muted).Size = UDim2.new(1, 0, 0, 56)
    else
        for index, entry in ipairs(games) do
            local card = Instance.new("Frame")
            card.Name = "GameCard_" .. tostring(entry.id)
            card.Size = UDim2.new(1, -8, 0, 124)
            card.BackgroundColor3 = COLORS.panel2
            card.LayoutOrder = index
            card.Parent = scroll
            local cardCorner = Instance.new("UICorner")
            cardCorner.CornerRadius = UDim.new(0, 10)
            cardCorner.Parent = card

            addGameThumbnail(card, entry)

            local title = makeLabel(card, entry.title or "Untitled game", 15, COLORS.text, Enum.Font.GothamBold)
            title.Position = UDim2.new(0, 120, 0, 7)
            title.Size = UDim2.new(1, -130, 0, 24)
            title.TextXAlignment = Enum.TextXAlignment.Left

            local description = makeLabel(card, entry.description or "", 11, COLORS.muted)
            description.Position = UDim2.new(0, 120, 0, 31)
            description.Size = UDim2.new(1, -130, 0, 23)
            description.TextXAlignment = Enum.TextXAlignment.Left

            local metadata = makeLabel(card, "Дата: " .. tostring(entry.importDate or "—") .. "  •  Статус: " .. tostring(entry.status or "НЕИЗВЕСТНО"), 10, COLORS.muted)
            metadata.Position = UDim2.new(0, 120, 0, 55)
            metadata.Size = UDim2.new(1, -130, 0, 18)
            metadata.TextXAlignment = Enum.TextXAlignment.Left

            local play = makeButton(card, "ИГРАТЬ", function()
                playRemote:FireServer(entry.id)
                if entry.id == "demo" then
                    gui.Enabled = false
                end
            end, true)
            play.Position = UDim2.new(0, 120, 0, 80)
            play.Size = UDim2.new(1, -130, 0, 35)
            play.TextSize = 13
        end
    end

    local back = makeButton(panel, "НАЗАД", showMain, false)
    back.LayoutOrder = 3
    back.Size = UDim2.new(1, 0, 0, 48)
end

showMain = function()
    local _, panel = makePage()
    makeLabel(panel, "GODOTBRIDGE", 34, COLORS.text, Enum.Font.GothamBlack).Size = UDim2.new(1, 0, 0, 70)
    makeLabel(panel, "GODOT → ROBLOX", 12, COLORS.muted, Enum.Font.GothamMedium).Size = UDim2.new(1, 0, 0, 22)
    makeButton(panel, "ЗАГРУЗИТЬ ФАЙЛ .GODOT", showImportInfo, true)
    makeButton(panel, "ИГРЫ", showGames, false)
end

showMain()
