# GodotBridge v0.1.4

## 2D scene and UI conversion

- Added a screen-space conversion path for root `Node2D` scenes. The converter creates a Roblox `ScreenGui` with a full-screen canvas and maps supported 2D elements into `GuiObject` instances.
- Added `CanvasLayer` to `ScreenGui` conversion. Godot layer number is mapped to Roblox `DisplayOrder` where possible.
- Added basic mappings: `Control`/`Panel` and common containers to `Frame`; `ColorRect` to `Frame`; `Label`/`RichTextLabel` to `TextLabel`; `Button`/`CheckBox`/`CheckButton` to `TextButton`; `LineEdit`/`TextEdit` to `TextBox`; `TextureRect`/`TextureButton` to image GUI objects; and `ProgressBar` to a static track/fill pair.
- Added `Sprite2D` to `ImageLabel` mapping inside 2D/CanvasLayer subtrees. PNG dimensions are read so the initial GUI size can be set from the source image. Texture references are preserved as `GodotBridge_TextureSource` metadata and source images are staged in `Textures/`.
- Added RBXMX serialization for `UDim2`, `Vector2` and integer properties needed by Roblox GUI objects.
- Added support for slash-separated Godot serialized property names, including `theme_override_font_sizes/font_size` and `theme_override_colors/font_color`.
- Import reports now include `ui_objects_generated` and `screen_guis_generated` counters and explicit warnings for the manual Roblox steps that remain.
- Added dedicated UI conversion tests for CanvasLayer controls, 2D root sprites, UI anchors/offsets, texture staging, and slash-separated Godot properties.
- Added `examples/Test2DUIProject.zip` and a converted demonstration output for practical UI conversion testing.
- Updated anchor detection so Control nodes with anchors but no explicit offset fields retain their scale anchors.
- Removed a duplicated generic 2D conversion warning from import reports.

## Preserved v0.1.3 reliability improvements

- Preserved the established Windows startup method documented in `ПОШАГОВАЯ УСТАНОВКА.txt`.
- Retained system diagnostics, rotating error logs, ZIP archive validation, staged conversion output, generated RBXMX XML validation, and defensive handling of damaged reports.
- No third-party Python runtime dependencies were added. Python 3.10+ and Tkinter remain required for the desktop app.

## Known boundaries

- This is a static visual approximation, not a complete 2D runtime port. Camera2D behavior, camera zoom, physics, signals, animations, shaders, Godot container auto-layout and gameplay scripts are not reproduced automatically.
- Texture references remain blank Roblox Image properties until the images are uploaded to Roblox and their asset IDs assigned manually. `GodotBridge_TextureSource` is an informational marker.
- After importing an RBXMX that contains a ScreenGui, move the ScreenGui into `StarterGui` so it is displayed to players.
- Godot BBCode, checkbox state/logic, and dynamic ProgressBar behavior need manual Roblox-side implementation.
- Windows GUI startup and Roblox Studio import must still be checked on a Windows PC; the automated suite was run in Linux.
