@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title GodotBridge Windows Build

echo.
echo ==================================================
echo            GODOTBRIDGE WINDOWS BUILD
echo ==================================================
echo.

where py >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python Launcher (py.exe) was not found.
    echo Install Python 3.10 or newer from https://www.python.org/downloads/windows/
    goto :failed
)

py -3 -c "import sys, tkinter; print('Python:', sys.version.split()[0]); print('Tkinter:', tkinter.TkVersion); assert sys.version_info >= (3, 10)"
if errorlevel 1 (
    echo [ERROR] Python 3.10+ with Tkinter is required.
    echo Make sure the installer includes "tcl/tk and IDLE".
    goto :failed
)

echo.
echo [INFO] Installing/updating PyInstaller in the selected Python environment...
py -3 -m pip install --upgrade pyinstaller
if errorlevel 1 goto :failed

echo.
echo [INFO] Building GodotBridge v0.1.4...
py -3 -m PyInstaller --noconfirm --clean --onefile --windowed --name GodotBridgeConverter "%~dp0run_converter.py"
if errorlevel 1 goto :failed

echo.
echo [SUCCESS] Build complete: %~dp0dist\GodotBridgeConverter.exe
echo.
pause
exit /b 0

:failed
echo.
echo [ERROR] Build failed. Read the message above and check the Python/Tkinter installation.
echo.
pause
exit /b 1
