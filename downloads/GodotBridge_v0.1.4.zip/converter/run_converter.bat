@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title GodotBridge Converter v0.1.4

echo.
echo ==================================================
echo              GODOTBRIDGE CONVERTER
echo ==================================================
echo.

if not exist "%~dp0run_converter.py" (
    echo [ERROR] run_converter.py was not found.
    echo Keep this BAT file next to run_converter.py inside the converter folder.
    goto :failed
)
if not exist "%~dp0godotbridge\gui.py" (
    echo [ERROR] The godotbridge folder is missing or the ZIP was not fully extracted.
    echo Extract the complete GodotBridge ZIP before starting the converter.
    goto :failed
)
if not exist "%~dp0godotbridge\diagnostics.py" (
    echo [ERROR] The diagnostics module is missing. The installation may be incomplete.
    echo Re-download and fully extract the GodotBridge v0.1.4 archive.
    goto :failed
)
if not exist "%~dp0godotbridge\convert.py" (
    echo [ERROR] The converter module is missing. The installation may be incomplete.
    echo Re-download and fully extract the GodotBridge v0.1.4 archive.
    goto :failed
)
if not exist "%~dp0godotbridge\archive.py" (
    echo [ERROR] The ZIP validation module is missing. The installation may be incomplete.
    echo Re-download and fully extract the GodotBridge v0.1.4 archive.
    goto :failed
)
if not exist "%~dp0godotbridge\parser.py" (
    echo [ERROR] The Godot scene parser is missing. The installation may be incomplete.
    echo Re-download and fully extract the GodotBridge v0.1.4 archive.
    goto :failed
)

set "PYTHON_CMD="
where py >nul 2>nul
if not errorlevel 1 (
    py -3 -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
    if not errorlevel 1 set "PYTHON_CMD=py -3"
)

if not defined PYTHON_CMD (
    where python >nul 2>nul
    if not errorlevel 1 (
        python -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
        if not errorlevel 1 set "PYTHON_CMD=python"
    )
)

if not defined PYTHON_CMD (
    echo [ERROR] A usable Python 3.10+ interpreter was not found.
    echo The "py -3" and "python" commands are missing or point to older versions.
echo.
    echo Install Python 3.10 or newer from https://www.python.org/downloads/windows/
    echo During installation, include "tcl/tk and IDLE".
    echo Then run this file again.
    goto :failed
)

echo [INFO] Checking Python and Tkinter...
%PYTHON_CMD% -c "import sys, tkinter; print('Python:', sys.version.split()[0]); print('Tkinter:', tkinter.TkVersion); assert sys.version_info >= (3, 10), 'Python 3.10 or newer is required'"
if errorlevel 1 (
echo.
    echo [ERROR] Python is too old, or Tkinter is missing.
    echo Install Python 3.10+ from https://www.python.org/downloads/windows/
    echo In the installer, make sure "tcl/tk and IDLE" is selected.
    goto :failed
)

echo.
echo [INFO] Starting GodotBridge Converter v0.1.4...
echo If an error appears below, take a screenshot of this window.
echo.
%PYTHON_CMD% "%~dp0run_converter.py"
set "APP_EXIT=%ERRORLEVEL%"
if not "%APP_EXIT%"=="0" (
echo.
    echo [ERROR] GodotBridge exited with code %APP_EXIT%.
    echo Copy or photograph the error message above and send it for troubleshooting.
    goto :failed
)

echo.
echo [INFO] GodotBridge has closed.
echo If you did not see the app window, send a screenshot of this console.
echo.
pause
exit /b 0

:failed
echo.
echo Press any key to close this window...
pause >nul
exit /b 1
