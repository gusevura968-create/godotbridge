from __future__ import annotations

import json
import math
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

from .parser import GodotNode, SceneDocument, parse_color, parse_vector, resolve_resource


UI_ROOT_TYPES = {
    "CanvasLayer", "Control", "Panel", "PanelContainer", "ColorRect", "Label",
    "RichTextLabel", "Button", "LineEdit", "TextEdit", "TextureRect",
    "TextureButton", "CheckBox", "CheckButton", "ProgressBar", "HSeparator",
    "VSeparator", "Node2D", "Sprite2D",
}

UI_CONTAINER_TYPES = {
    "Control", "Panel", "PanelContainer", "MarginContainer", "VBoxContainer",
    "HBoxContainer", "GridContainer", "CenterContainer", "AspectRatioContainer",
    "ScrollContainer", "SubViewportContainer", "Node2D", "CanvasItem",
}

UI_NODE_TYPES = UI_CONTAINER_TYPES | {
    "ColorRect", "Label", "RichTextLabel", "Button", "LineEdit", "TextEdit",
    "TextureRect", "TextureButton", "CheckBox", "CheckButton", "ProgressBar",
    "HSeparator", "VSeparator", "Sprite2D",
}


def _safe_name(value: str) -> str:
    import re
    value = re.sub(r"[^A-Za-z0-9 _.-]+", "_", value).strip(" .")
    return (value or "GodotNode")[:100]


def _raw_string(value: str | None, default: str = "") -> str:
    value = (value or "").strip()
    if not value:
        return default
    if len(value) >= 2 and value[0] == value[-1] == '"':
        try:
            parsed = json.loads(value)
            return parsed if isinstance(parsed, str) else str(parsed)
        except (json.JSONDecodeError, TypeError):
            return value[1:-1]
    if len(value) >= 2 and value[0] == value[-1] == "'":
        return value[1:-1]
    return value


def _number(node: GodotNode, key: str, default: float) -> float:
    try:
        result = float(node.properties.get(key, default))
        return result if math.isfinite(result) else default
    except (TypeError, ValueError):
        return default


def _bool(node: GodotNode, key: str, default: bool = True) -> bool:
    raw = node.properties.get(key)
    if raw is None:
        return default
    normalized = raw.strip().lower()
    if normalized in {"true", "1", "yes"}:
        return True
    if normalized in {"false", "0", "no", ""}:
        return False
    try:
        return float(normalized) != 0.0
    except ValueError:
        return default


def _anchors_and_offsets(node: GodotNode) -> tuple[tuple[float, float, float, float], tuple[float, float, float, float]]:
    """Return Position and Size values as Roblox (xScale, xOffset, yScale, yOffset)."""
    anchor_or_offset_keys = (
        "anchor_left", "anchor_top", "anchor_right", "anchor_bottom",
        "offset_left", "offset_top", "offset_right", "offset_bottom",
    )
    if any(key in node.properties for key in anchor_or_offset_keys):
        left_anchor = _number(node, "anchor_left", 0.0)
        top_anchor = _number(node, "anchor_top", 0.0)
        right_anchor = _number(node, "anchor_right", left_anchor)
        bottom_anchor = _number(node, "anchor_bottom", top_anchor)
        left = _number(node, "offset_left", 0.0)
        top = _number(node, "offset_top", 0.0)
        right = _number(node, "offset_right", left)
        bottom = _number(node, "offset_bottom", top)
        return (
            (left_anchor, left, top_anchor, top),
            (right_anchor - left_anchor, right - left, bottom_anchor - top_anchor, bottom - top),
        )

    position = parse_vector(node.properties.get("position", ""), 2, (0.0, 0.0))
    size = parse_vector(node.properties.get("size", ""), 2, (100.0, 36.0))
    return ((0.0, position[0], 0.0, position[1]), (0.0, size[0], 0.0, size[1]))


def _png_dimensions(path: Path) -> tuple[int, int] | None:
    try:
        with path.open("rb") as stream:
            header = stream.read(24)
        if header.startswith(b"\x89PNG\r\n\x1a\n") and len(header) >= 24:
            width = int.from_bytes(header[16:20], "big")
            height = int.from_bytes(header[20:24], "big")
            if width > 0 and height > 0:
                return width, height
    except OSError:
        pass
    return None


def _texture_path(node: GodotNode, doc: SceneDocument) -> str | None:
    resource = resolve_resource(node.properties.get("texture", ""), doc.ext_resources)
    return resource.get("path") if resource else None


def _base_props(node: GodotNode, background: tuple[float, float, float] = (0.0, 0.0, 0.0), background_alpha: float = 0.0) -> list[tuple[Any, ...]]:
    position, size = _anchors_and_offsets(node)
    props: list[tuple[Any, ...]] = [
        ("udim2", "Position", position),
        ("udim2", "Size", size),
        ("vector2", "AnchorPoint", (0.0, 0.0)),
        ("float", "Rotation", _number(node, "rotation_degrees", math.degrees(_number(node, "rotation", 0.0)))) ,
        ("bool", "Visible", _bool(node, "visible", True)),
        ("int", "ZIndex", int(max(1, min(10_000, _number(node, "z_index", 1))))),
        ("color3", "BackgroundColor3", background),
        ("float", "BackgroundTransparency", 1.0 - max(0.0, min(1.0, background_alpha))),
        ("int", "BorderSizePixel", 0),
    ]
    return props


def _add_texture_metadata(instance: ET.Element, node: GodotNode, doc: SceneDocument, writer: Any, warnings: list[str]) -> None:
    source = _texture_path(node, doc)
    if source:
        writer.instance(instance, "StringValue", "GodotBridge_TextureSource", [("string", "Value", source)])
        warnings.append(
            f"{node.name}: изображение {source} скопировано в Textures/, но его нужно загрузить в Roblox и вручную назначить Image asset ID."
        )
    else:
        warnings.append(f"{node.name}: текстура не найдена в ext_resource; создан пустой ImageLabel/ImageButton.")


def _build_gui_node(
    node: GodotNode,
    parent_xml: ET.Element,
    writer: Any,
    doc: SceneDocument,
    project_root: Path,
    counters: dict[str, int],
    warnings: list[str],
) -> None:
    name = _safe_name(node.name)
    typ = node.type

    if typ in UI_CONTAINER_TYPES:
        props = _base_props(node)
        props[-2] = ("float", "BackgroundTransparency", 1.0)
        if typ in {"Panel", "PanelContainer"}:
            props[-2] = ("float", "BackgroundTransparency", 0.05)
            props[-3] = ("color3", "BackgroundColor3", (0.10, 0.14, 0.21))
        frame = writer.instance(parent_xml, "Frame", name, props)
        counters["objects"] += 1
        counters["ui_objects"] += 1
        if typ in {"VBoxContainer", "HBoxContainer", "GridContainer", "MarginContainer", "CenterContainer", "ScrollContainer", "PanelContainer", "AspectRatioContainer"}:
            warnings.append(f"{node.name}: автоматическая компоновка {typ} пока не переносится; сохранены сериализованные позиции и размеры дочерних элементов.")
        for child in node.children:
            if child.type in UI_NODE_TYPES:
                _build_gui_node(child, frame, writer, doc, project_root, counters, warnings)
            else:
                warnings.append(f"{child.name}: узел {child.type} внутри GUI-контейнера пропущен.")
        return

    if typ == "ColorRect":
        color = parse_color(node.properties.get("color", "")) or (1.0, 1.0, 1.0, 1.0)
        props = _base_props(node, color[:3], color[3])
        instance = writer.instance(parent_xml, "Frame", name, props)
    elif typ in {"Label", "RichTextLabel"}:
        props = _base_props(node)
        props[-2] = ("float", "BackgroundTransparency", 1.0)
        color = parse_color(
            node.properties.get("theme_override_colors/font_color", node.properties.get("font_color", ""))
        ) or (0.93, 0.96, 1.0, 1.0)
        raw_text = _raw_string(node.properties.get("text", ""))
        props.extend([
            ("string", "Text", raw_text),
            ("color3", "TextColor3", color[:3]),
            ("int", "TextSize", int(max(1, min(100, _number(node, "theme_override_font_sizes/font_size", 16))))),
            ("token", "Font", 3),
            ("bool", "TextWrapped", _bool(node, "autowrap_mode", True)),
            ("bool", "RichText", typ == "RichTextLabel"),
            ("token", "TextXAlignment", int(max(0, min(2, _number(node, "horizontal_alignment", 0))))),
            ("token", "TextYAlignment", int(max(0, min(2, _number(node, "vertical_alignment", 1))))),
        ])
        instance = writer.instance(parent_xml, "TextLabel", name, props)
        if typ == "RichTextLabel" and any(tag in raw_text for tag in ("[b]", "[i]", "[color", "[url")):
            warnings.append(f"{node.name}: Godot BBCode форматирование не преобразуется автоматически в Roblox RichText.")
    elif typ in {"Button", "CheckBox", "CheckButton"}:
        props = _base_props(node, (0.16, 0.23, 0.35), 1.0)
        color = parse_color(node.properties.get("theme_override_colors/font_color", "")) or (0.93, 0.96, 1.0, 1.0)
        props.extend([
            ("string", "Text", _raw_string(node.properties.get("text", ""))),
            ("color3", "TextColor3", color[:3]),
            ("int", "TextSize", int(max(1, min(100, _number(node, "theme_override_font_sizes/font_size", 16))))),
            ("token", "Font", 3),
            ("bool", "TextWrapped", True),
            ("bool", "Active", not _bool(node, "disabled", False)),
            ("bool", "AutoButtonColor", True),
        ])
        instance = writer.instance(parent_xml, "TextButton", name, props)
        if typ in {"CheckBox", "CheckButton"}:
            warnings.append(f"{node.name}: {typ} визуально перенесён как TextButton; логика переключения/галочки требует Luau.")
    elif typ in {"LineEdit", "TextEdit"}:
        props = _base_props(node, (0.08, 0.11, 0.17), 0.95)
        props.extend([
            ("string", "Text", _raw_string(node.properties.get("text", ""))),
            ("string", "PlaceholderText", _raw_string(node.properties.get("placeholder_text", ""))),
            ("color3", "TextColor3", (0.93, 0.96, 1.0)),
            ("int", "TextSize", int(max(1, min(100, _number(node, "theme_override_font_sizes/font_size", 16))))),
            ("token", "Font", 3),
            ("bool", "ClearTextOnFocus", False),
            ("bool", "MultiLine", typ == "TextEdit"),
            ("bool", "TextWrapped", typ == "TextEdit"),
            ("bool", "TextEditable", _bool(node, "editable", True)),
        ])
        instance = writer.instance(parent_xml, "TextBox", name, props)
    elif typ in {"TextureRect", "TextureButton", "Sprite2D"}:
        if typ == "Sprite2D":
            source = _texture_path(node, doc)
            dimensions = None
            if source:
                source_path = project_root / source.replace("res://", "").replace("\\", "/")
                dimensions = _png_dimensions(source_path)
            width, height = dimensions or (128, 128)
            scale = parse_vector(node.properties.get("scale", ""), 2, (1.0, 1.0))
            offset = parse_vector(node.properties.get("offset", ""), 2, (0.0, 0.0))
            position = parse_vector(node.properties.get("position", ""), 2, (0.0, 0.0))
            x = position[0] + offset[0]
            y = position[1] + offset[1]
            centered = _bool(node, "centered", True)
            if centered:
                x -= width * abs(scale[0]) * 0.5
                y -= height * abs(scale[1]) * 0.5
            tint = parse_color(node.properties.get("modulate", "")) or (1.0, 1.0, 1.0, 1.0)
            props = [
                ("udim2", "Position", (0.0, x, 0.0, y)),
                ("udim2", "Size", (0.0, width * abs(scale[0]), 0.0, height * abs(scale[1]))),
                ("vector2", "AnchorPoint", (0.0, 0.0)),
                ("float", "Rotation", _number(node, "rotation_degrees", math.degrees(_number(node, "rotation", 0.0)))) ,
                ("bool", "Visible", _bool(node, "visible", True)),
                ("int", "ZIndex", int(max(1, min(10_000, _number(node, "z_index", 1))))),
                ("float", "BackgroundTransparency", 1.0),
                ("color3", "ImageColor3", tint[:3]),
                ("float", "ImageTransparency", 1.0 - tint[3]),
                ("string", "Image", ""),
            ]
            instance = writer.instance(parent_xml, "ImageLabel", name, props)
            _add_texture_metadata(instance, node, doc, writer, warnings)
            if not dimensions and source:
                warnings.append(f"{node.name}: размеры изображения не удалось прочитать; для Sprite2D использован резервный размер 128×128.")
        else:
            props = _base_props(node)
            props[-2] = ("float", "BackgroundTransparency", 1.0)
            image_class = "ImageButton" if typ == "TextureButton" else "ImageLabel"
            props.extend([
                ("string", "Image", ""),
                ("color3", "ImageColor3", (1.0, 1.0, 1.0)),
            ])
            instance = writer.instance(parent_xml, image_class, name, props)
            _add_texture_metadata(instance, node, doc, writer, warnings)
    elif typ == "ProgressBar":
        props = _base_props(node, (0.12, 0.17, 0.25), 1.0)
        track = writer.instance(parent_xml, "Frame", name, props)
        minimum = _number(node, "min_value", 0.0)
        maximum = _number(node, "max_value", 100.0)
        value = _number(node, "value", minimum)
        ratio = max(0.0, min(1.0, (value - minimum) / (maximum - minimum))) if maximum > minimum else 0.0
        writer.instance(track, "Frame", "GodotBridge_Fill", [
            ("udim2", "Position", (0.0, 0.0, 0.0, 0.0)),
            ("udim2", "Size", (ratio, 0.0, 1.0, 0.0)),
            ("color3", "BackgroundColor3", (0.18, 0.72, 0.52)),
            ("float", "BackgroundTransparency", 0.0),
            ("int", "BorderSizePixel", 0),
        ])
        counters["objects"] += 1
        counters["ui_objects"] += 2
        warnings.append(f"{node.name}: ProgressBar преобразован в статическое заполнение; динамическое обновление значения нужно реализовать в Luau.")
        for child in node.children:
            _build_gui_node(child, track, writer, doc, project_root, counters, warnings)
        return
    elif typ in {"HSeparator", "VSeparator"}:
        props = _base_props(node, (0.38, 0.46, 0.58), 1.0)
        instance = writer.instance(parent_xml, "Frame", name, props)
    else:
        props = _base_props(node)
        props[-2] = ("float", "BackgroundTransparency", 1.0)
        instance = writer.instance(parent_xml, "Frame", name, props)
        warnings.append(f"{node.name}: специального соответствия для {typ} нет; создан прозрачный Frame.")

    counters["objects"] += 1
    counters["ui_objects"] += 1
    for child in node.children:
        if child.type in UI_NODE_TYPES:
            _build_gui_node(child, instance, writer, doc, project_root, counters, warnings)
        else:
            warnings.append(f"{child.name}: узел {child.type} внутри GUI-контейнера пропущен.")


def build_ui_root(
    node: GodotNode,
    parent_xml: ET.Element,
    writer: Any,
    doc: SceneDocument,
    project_root: Path,
    counters: Any,
    warnings: list[str],
) -> None:
    display_order = int(max(-100, min(100, _number(node, "layer", 0)))) if node.type == "CanvasLayer" else 0
    screen_gui = writer.instance(parent_xml, "ScreenGui", _safe_name(node.name) + "_ScreenGui", [
        ("bool", "Enabled", True),
        ("bool", "ResetOnSpawn", False),
        ("bool", "IgnoreGuiInset", False),
        ("int", "DisplayOrder", display_order),
    ])
    counters["ui_screen_guis"] += 1
    if node.type == "CanvasLayer":
        for child in node.children:
            if child.type in UI_NODE_TYPES:
                _build_gui_node(child, screen_gui, writer, doc, project_root, counters, warnings)
            else:
                warnings.append(f"{child.name}: тип {child.type} внутри CanvasLayer не поддерживается и пропущен.")
    elif node.type == "Node2D":
        canvas = writer.instance(screen_gui, "Frame", "GodotBridge_2DCanvas", [
            ("udim2", "Position", (0.0, 0.0, 0.0, 0.0)),
            ("udim2", "Size", (1.0, 0.0, 1.0, 0.0)),
            ("vector2", "AnchorPoint", (0.0, 0.0)),
            ("float", "BackgroundTransparency", 1.0),
            ("bool", "Visible", True),
            ("int", "BorderSizePixel", 0),
        ])
        counters["ui_objects"] += 1
        counters["objects"] += 1
        for child in node.children:
            if child.type == "CanvasLayer":
                for layered_child in child.children:
                    if layered_child.type in UI_NODE_TYPES:
                        _build_gui_node(layered_child, canvas, writer, doc, project_root, counters, warnings)
                    else:
                        warnings.append(f"{layered_child.name}: тип {layered_child.type} внутри CanvasLayer не поддерживается и пропущен.")
                warnings.append(f"{child.name}: CanvasLayer вложен в 2D-корень; его элементы сведены к одному ScreenGui, порядок слоёв может потребовать ручной настройки.")
            elif child.type in UI_NODE_TYPES:
                _build_gui_node(child, canvas, writer, doc, project_root, counters, warnings)
            else:
                warnings.append(f"{child.name}: тип {child.type} внутри 2D-сцены не поддерживается и пропущен.")
        warnings.append(
            f"{node.name}: 2D-сцена преобразована в экранные GuiObject. Камера, физика, анимации и мировое масштабирование Godot не переносятся автоматически."
        )
    else:
        _build_gui_node(node, screen_gui, writer, doc, project_root, counters, warnings)
    warnings.append(
        f"{node.name}: ScreenGui создан внутри RBXMX-модели. После импорта переместите его в StarterGui, чтобы интерфейс отображался игрокам."
    )
