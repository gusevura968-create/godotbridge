from __future__ import annotations

import logging
import os
import platform
import shutil
import sys
import tempfile
from logging.handlers import RotatingFileHandler
from pathlib import Path


APP_VERSION = "0.1.4"
LOGGER_NAME = "godotbridge"


def get_app_data_dir() -> Path:
    """Return a per-user writable location for logs and diagnostics."""
    if os.name == "nt":
        base = os.environ.get("LOCALAPPDATA")
        return (Path(base) if base else Path.home() / "AppData" / "Local") / "GodotBridge"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Logs" / "GodotBridge"
    base = os.environ.get("XDG_STATE_HOME")
    return (Path(base) if base else Path.home() / ".local" / "state") / "godotbridge"


def get_log_path() -> Path:
    return get_app_data_dir() / "logs" / "godotbridge.log"


def configure_logging() -> logging.Logger:
    logger = logging.getLogger(LOGGER_NAME)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    if logger.handlers:
        return logger

    try:
        log_path = get_log_path()
        log_path.parent.mkdir(parents=True, exist_ok=True)
        handler = RotatingFileHandler(
            log_path,
            maxBytes=2 * 1024 * 1024,
            backupCount=4,
            encoding="utf-8",
        )
        handler.setFormatter(logging.Formatter(
            "%(asctime)s | %(levelname)s | %(threadName)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        ))
        logger.addHandler(handler)
        logger.info("GodotBridge %s started", APP_VERSION)
    except OSError:
        # Logging must never prevent the app itself from starting.
        logger.addHandler(logging.NullHandler())
    return logger


def log_exception(context: str, exc: BaseException) -> Path | None:
    logger = configure_logging()
    logger.error("%s: %s", context, exc, exc_info=(type(exc), exc, exc.__traceback__))
    path = get_log_path()
    return path if path.is_file() else None


def _check_writable(directory: Path) -> tuple[bool, str]:
    try:
        directory.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(prefix=".godotbridge_check_", dir=directory, delete=True):
            pass
        return True, "доступна для записи"
    except OSError as exc:
        return False, f"нет доступа на запись: {exc}"


def build_diagnostic_report(output_dir: Path) -> str:
    """Build a user-readable system report without changing project files."""
    output_dir = Path(output_dir).expanduser()
    lines = [
        f"GodotBridge: v{APP_VERSION}",
        f"Python: {platform.python_version()} ({'OK' if sys.version_info >= (3, 10) else 'ТРЕБУЕТСЯ 3.10+'}) ({sys.executable})",
        f"ОС: {platform.platform()}",
        f"Архитектура: {platform.machine() or 'не определена'}",
        f"Рабочая папка: {Path.cwd()}",
    ]

    try:
        import tkinter
        lines.append(f"Tkinter: доступен (Tcl/Tk {tkinter.TkVersion})")
    except Exception as exc:  # pragma: no cover - platform-specific installation state
        lines.append(f"Tkinter: ошибка импорта ({exc})")

    package_root = Path(__file__).resolve().parent
    required_files = [
        package_root / "__init__.py",
        package_root / "diagnostics.py",
        package_root / "gui.py",
        package_root / "convert.py",
        package_root / "archive.py",
        package_root / "parser.py",
        package_root / "scripts.py",
    ]
    missing = [path.name for path in required_files if not path.is_file()]
    lines.append("Файлы программы: " + ("все основные файлы найдены" if not missing else "не найдены: " + ", ".join(missing)))

    writable, message = _check_writable(output_dir)
    lines.append(f"Папка результатов ({output_dir}): {message}")
    try:
        free_bytes = shutil.disk_usage(output_dir).free
        lines.append(f"Свободное место на диске: {free_bytes / (1024 ** 3):.2f} ГБ")
    except OSError as exc:
        lines.append(f"Свободное место: не удалось проверить ({exc})")
    lines.append(f"Журнал ошибок: {get_log_path()}")
    if not writable:
        lines.append("Совет: выберите папку результатов, в которую у вашей учётной записи есть право записи.")
    lines.append("Сторонние Python-библиотеки для базовой версии не требуются.")
    return "\n".join(lines)


def format_user_error(error: BaseException) -> str:
    """Keep actionable validation messages while pointing to full diagnostics."""
    message = str(error).strip() or error.__class__.__name__
    log_path = get_log_path()
    return f"{message}\n\nПодробности записаны в журнал: {log_path}"
