"""GodotBridge: conservative Godot-to-Roblox project converter."""

__version__ = "0.1.4"


def run_gui() -> None:
    """Import the desktop UI only when it is explicitly requested.

    Keeping this import lazy allows the command-line converter and its tests
    to work even on Python installations that do not include Tkinter.
    """
    from .gui import run_gui as _run_gui

    _run_gui()
