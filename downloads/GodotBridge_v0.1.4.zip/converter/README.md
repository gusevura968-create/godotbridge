# GodotBridge Converter

GodotBridge v0.1.4 — Windows desktop converter, Python 3.10+; runtime dependencies: Python standard library only. Tkinter must be available for the desktop interface.

## Run on Windows

1. Extract the complete GodotBridge ZIP (do not run it from inside the ZIP preview).
2. Install Python 3.10+ from python.org and include the `tcl/tk and IDLE` option.
3. Open the `converter` folder. Use the established right-click context-menu launch option with the file icon for `run_converter.bat` (or the same verified context-menu method for `run_converter.py`). On the tested PC, ordinary left double-click caused the known startup error; keep using the working method described in `ПОШАГОВАЯ УСТАНОВКА.txt`.
4. Use **ПРОВЕРКА СИСТЕМЫ** in the main menu to inspect Python/Tkinter, required files, output-folder access and free disk space. Full error details are saved in the per-user log file shown there.
5. Choose a ZIP containing one complete Godot project. The ZIP must include `project.godot`, `.tscn` scenes and any required resources.

For CLI use:

```powershell
cd converter
py -3 -m godotbridge.cli path\to\godot-project.zip --output path\to\ConvertedGames
```

## Build a Windows executable

Run `build_windows.bat` on a Windows machine with Python installed. It installs PyInstaller and creates `dist\GodotBridgeConverter.exe`. A prebuilt Windows EXE is not included in this Linux-built release.

## v0.1.4 — 2D/UI conversion

- Root `Node2D` scenes become a screen-space `ScreenGui` approximation.
- `CanvasLayer` becomes a `ScreenGui`.
- Basic Godot controls are represented by Roblox `Frame`, `TextLabel`, `TextButton`, `TextBox`, `ImageLabel`/`ImageButton`, and static `ProgressBar` track/fill objects.
- `Sprite2D` under a 2D scene/CanvasLayer becomes an `ImageLabel`; PNG dimensions are read for an initial size.
- Slash-separated serialized Godot properties are now retained by the `.tscn` parser.

Try the bundled `examples/Test2DUIProject.zip` fixture to inspect the generated hierarchy. After import, move the generated ScreenGui into `StarterGui`. Upload staged images to Roblox and set their `Image` properties manually. Camera2D, world camera/zoom, 2D physics, animation, signals, runtime layout containers, BBCode, toggle state and gameplay logic are not automatically ported. Generated Luau remains a draft and requires manual review.

## Security and operation

The converter treats project files as data and does not execute Godot/GDScript, binaries, shell scripts, or generated Luau. ZIP extraction validates paths and archive structure before staged extraction. The generated RBXMX files are XML-validated by the converter, but they must still be inspected in Roblox Studio.
