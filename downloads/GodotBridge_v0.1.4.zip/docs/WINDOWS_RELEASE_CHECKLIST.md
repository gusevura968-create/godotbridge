# GodotBridge v0.1.4 — Windows and Roblox Studio smoke-test checklist

Automated tests and CLI checks passed in a Linux development environment. Perform these checks on a Windows PC before calling the release fully Windows-verified.

## Startup and installation

- [ ] Extract the complete ZIP to a normal folder (not the ZIP preview).
- [ ] Confirm Python 3.10+ and `tcl/tk and IDLE` are installed.
- [ ] Start `converter/run_converter.bat` using the established right-click context-menu option with the file icon, as documented in `ПОШАГОВАЯ УСТАНОВКА.txt`.
- [ ] Confirm the app opens without changing the user's established startup method.
- [ ] Open **ПРОВЕРКА СИСТЕМЫ** and verify Python, Tkinter, program files, output write access, disk space and log path.

## Existing 3D conversion and reliability

- [ ] Import `examples/TestGodotProject` packed as ZIP.
- [ ] Confirm `Reports/import_report.md`, `Reports/import_report.json` and `RobloxProject/ConvertedScene.rbxmx` are generated.
- [ ] Import the same ZIP again and confirm the first result is not overwritten.
- [ ] Confirm both results appear in **МОИ ИГРЫ**.
- [ ] Try an invalid ZIP; confirm a readable error appears and no completed game is listed.
- [ ] Confirm a failed conversion does not leave a partial result folder.

## New v0.1.4 2D/UI conversion

- [ ] Make a small Godot 4 test project containing a root `CanvasLayer`, `Panel`, `Label`, `Button`, `TextureRect` and `ProgressBar`; export the complete project to ZIP.
- [ ] Import it and check `ui_objects_generated` and `screen_guis_generated` in `Reports/import_report.json`.
- [ ] Open the generated `.rbxmx` in Roblox Studio and verify that the ScreenGui and its descendants are present.
- [ ] Move the ScreenGui to `StarterGui` and run a play test.
- [ ] Confirm texture paths are listed in metadata/report; upload the image in Roblox and assign its asset ID manually.
- [ ] Compare anchors, offsets, ZIndex, text and colors with the original Godot scene; adjust differences manually.
- [ ] Confirm the report clearly warns about static ProgressBar fill, missing signal logic, checkbox behavior and unsupported layout/camera/animation features.

## Error log

- [ ] Trigger a known import error and confirm the message shows the per-user log path.
- [ ] Open the log and confirm it contains a timestamp and exception details.
- [ ] Confirm logs are stored outside the Godot project and downloaded program folder.

## Release decision

- [ ] Attach the Windows test notes and any screenshots to the release record.
- [ ] Do not treat XML validation or generated GUI hierarchy as proof that the original Godot project is playable or equivalent in Roblox.
