# Supported feature matrix — GodotBridge v0.1.4

This matrix describes actual converter behavior. “Converted” means an approximate Roblox representation was emitted; it does not mean the original runtime behavior is reproduced.

| Godot input | Current handling | Result / caveat |
|---|---|---|
| `project.godot` | Reads application name and main-scene metadata | Does not launch the Godot engine |
| Text `.tscn` | Parses `[node]`, `[ext_resource]`, `[sub_resource]`, parent paths and slash-separated property names | Binary `.scn` and Godot import cache internals are not parsed |
| `Node`, `Node3D`, 3D physics bodies and areas | Creates Roblox `Model` containers and approximate descendants | Physics, signals and gameplay behavior are not translated |
| `MeshInstance3D` | Creates a Part approximation and stages external model files | Arbitrary GLB/GLTF/OBJ/FBX geometry is not embedded in RBXMX |
| `CollisionShape3D` | Creates an invisible Part with basic primitive dimensions | Approximation only; complex collision resources are not rebuilt |
| `Camera3D` | Writes a Roblox Camera-like object and transform | A Roblox-side `Workspace.CurrentCamera` controller is still needed |
| 3D lights | Maps point/spot lights approximately; directional light is reported | Lighting appearance must be checked and adjusted in Studio |
| Root `CanvasLayer` | Creates a `ScreenGui` and converts supported GUI descendants | After import, move the `ScreenGui` to `StarterGui` |
| Root `Control`, `Panel`, `ColorRect`, labels, buttons, text inputs and image controls | Creates a `ScreenGui` with corresponding Roblox `GuiObject` instances | Static appearance only; GUI behaviors and themes are incomplete |
| Root `Node2D` | Creates a `ScreenGui` with a full-screen transparent canvas; supported descendants are mapped | 2D world/camera scaling is not preserved |
| `Panel`, `PanelContainer`, basic containers and other supported Control nodes | Maps to `Frame` | Godot container auto-layout/margins are not recreated; serialized child positions are retained approximately |
| `Label`, `RichTextLabel` | Maps to `TextLabel` with basic text/color/size/alignment values | Godot BBCode markup and advanced theme styling are not translated |
| `Button`, `CheckBox`, `CheckButton` | Maps to `TextButton` | Click signals and checkbox toggle state/logic need Luau |
| `LineEdit`, `TextEdit` | Maps to `TextBox` with basic text/placeholder/editable settings | Input validation, focus behavior and theme are not fully translated |
| `TextureRect`, `TextureButton`, `Sprite2D` under supported UI/2D roots | Maps to `ImageLabel`/`ImageButton`; source path stored as `GodotBridge_TextureSource` | Upload image and assign Roblox `Image` asset ID manually; PNG dimensions are read for `Sprite2D` |
| `ProgressBar` | Creates a static track and fill based on the serialized value | No runtime update logic is generated |
| `HSeparator`, `VSeparator` | Creates a simple `Frame` approximation | Appearance may need manual adjustment |
| PNG/JPG/JPEG/WebP/BMP/TGA and other supported project resources | Copies files to `Textures/` | Copying is not a Roblox asset upload |
| WAV/OGG/MP3/FLAC | Copies files to `Audio/` | Upload and set `SoundId` manually |
| GLB/GLTF/OBJ/FBX/DAE/BLEND | Copies files to `Models/` | Use Studio's model import workflow separately |
| GDScript declarations, functions, if/else, simple loops, arithmetic and selected built-ins | Emits a Luau draft | Manual API adaptation and review are required |
| Unsupported GDScript APIs, annotations, signals and engine-specific behavior | Preserves TODO/comments and warnings where recognized | No fabricated equivalent is generated |
| ZIP archives | Validates paths, symlinks, duplicates, file count and uncompressed size | One unambiguous project per archive; nested ZIPs are not recursively imported |

## Report semantics

- **Found** counts discovered source files.
- **Staged** counts resources copied into the output tree; it does not mean they were uploaded to Roblox.
- **Converted** counts generated RBXMX scene files, approximate Instances, translated Luau statements and related output files.
- **UI objects** counts generated GUI Instances. **ScreenGuis** counts generated top-level GUI roots.
- **PARTIAL** means warnings were emitted. For a project with unsupported runtime systems this is expected.
