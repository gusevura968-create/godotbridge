# Known limitations — GodotBridge v0.1.4

GodotBridge performs static parsing and approximation. It does not run the Godot engine and cannot automatically reproduce an arbitrary game in Roblox.

1. **Scene/resource parsing:** only readable text `.tscn` files are parsed. Binary `.scn`, internal `.godot` import cache data, complex resource graphs and every PackedScene inheritance pattern are not reconstructed.
2. **2D/UI is static:** root `CanvasLayer` and `Node2D` scenes, plus selected Control descendants, can be emitted as Roblox `ScreenGui`/`GuiObject` instances. Camera2D, world projection, zoom, pixel scaling, canvas transforms and runtime layout are not preserved.
3. **Containers:** VBox/HBox/Grid/Margin/Center/Scroll and related Godot layout rules are not recreated as Roblox UIListLayout/UIGridLayout constraints. Serialized position/size values are only an approximation.
4. **Input and interaction:** Button signals, checkbox state/logic, LineEdit validation, focus behavior, keyboard/gamepad input mapping and UI event connections require manual Luau implementation.
5. **Text and themes:** Godot BBCode, custom fonts, theme inheritance, advanced styleboxes, theme overrides beyond simple properties, localization and rich layout are not fully converted.
6. **Textures:** image files are staged locally and source paths are stored as metadata. They are not uploaded to Roblox and generated Image properties remain blank until asset IDs are assigned manually. Sprite2D dimension probing currently reads PNG headers; unsupported formats use a fallback size.
7. **ProgressBar:** the current value is represented by a static fill. Dynamic updates need Luau.
8. **2D/3D mixing:** nested CanvasLayer handling is simplified. Layer order and relationships between world-space and screen-space nodes can require manual arrangement.
9. **3D geometry:** external GLB/GLTF/OBJ/FBX/DAE/BLEND files are staged rather than embedded into RBXMX. Meshes may be represented by primitive approximations.
10. **Physics and gameplay:** character controllers, rigid-body behavior, collision response, navigation, signals, animation trees, shaders, particles, multiplayer, persistence, Autoload/singletons and engine services are not ported automatically.
11. **GDScript:** the translator handles a conservative syntactic subset. Generated Luau is a draft, may need API and semantic changes, and is not automatically executed.
12. **Assets and publishing:** Roblox asset upload, moderation, ownership, permissions, place publishing, account synchronization and DataStore configuration remain manual.
13. **RBXMX validation:** XML validity does not guarantee that Roblox Studio accepts every property/class combination or that the result behaves as expected. Open and inspect the output in Studio.
14. **Windows verification:** automated tests were run in Linux. The documented Windows right-click launch flow, Tkinter behavior on the user's PC and import into Roblox Studio still require manual validation on Windows.

These limitations are intentionally reported. A successful conversion means that output files were produced and basic XML validation passed; it is not a guarantee that the game is playable or equivalent.
