# GODOTBRIDGE IMPORT REPORT

**Converter version:** 0.1.4
**Project:** GodotBridge 2D UI Sample
**Status:** PARTIAL
**Imported (UTC):** 2026-11-15T08:57:08+00:00

## Found

- scenes: 1
- scripts: 0
- textures: 1
- audio: 0
- model_files: 0

## Staged for Roblox Studio

- textures: 1
- audio: 0
- model_files: 0
- other_assets: 0

## Converted into RBXMX/Luau output

- scenes_to_rbxmx: 1
- scene_nodes_to_roblox_instances: 8
- ui_objects_generated: 9
- screen_guis_generated: 1
- luau_files_generated: 0
- gdscript_statements_translated: 0
- gdscript_statements_flagged: 0

## Warnings

- Сцена Scenes/Main.tscn: Mascot: изображение res://Textures/godotbridge-icon.png скопировано в Textures/, но его нужно загрузить в Roblox и вручную назначить Image asset ID.
- Сцена Scenes/Main.tscn: Progress: ProgressBar преобразован в статическое заполнение; динамическое обновление значения нужно реализовать в Luau.
- Сцена Scenes/Main.tscn: MainUI: ScreenGui создан внутри RBXMX-модели. После импорта переместите его в StarterGui, чтобы интерфейс отображался игрокам.
- 2D-интерфейс преобразован в ScreenGui/GuiObject. После импорта переместите ScreenGui в StarterGui; изображения нужно загрузить в Roblox и назначить Image asset ID вручную.
- Ресурсы скопированы в выходную папку, но не загружены в Roblox Asset Manager; назначение asset ID выполняется вручную.

## Errors

- Нет.

> RBXMX проверен как XML в рамках автоматических тестов. Файл не открывался в Roblox Studio в этой среде.
