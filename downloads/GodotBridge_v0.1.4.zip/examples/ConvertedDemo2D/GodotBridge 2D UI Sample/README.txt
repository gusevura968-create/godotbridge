GODOTBRIDGE v0.1.4 — GodotBridge 2D UI Sample
========================================

БЫСТРЫЙ СТАРТ
1. Откройте Roblox Studio и создайте/откройте свой place.
2. В Explorer выберите Workspace, затем используйте File > Insert from File…
   (или импортируйте ConvertedScene.rbxmx через доступный в вашей версии Studio способ).
3. Выберите RobloxProject/ConvertedScene.rbxmx.
4. Проверьте масштаб, ориентацию, коллизии и иерархию.
5. Загрузите файлы из Textures/, Audio/ и Models/ в Roblox Studio/Creator Dashboard.
6. Замените пометки GodotBridge_* на реальные asset ID.
7. Luau находится в Scripts/Luau/. Это черновой перевод: проверьте API и подключите
   ModuleScript/Script вручную. Исходные .gd сохранены в Scripts/GodotSource/.

ЧТО РЕАЛЬНО СДЕЛАНО
- Текстовые .tscn разобраны без запуска Godot и без исполнения пользовательского кода.
- Поддерживаемые узлы сцены сериализованы в RBXMX как Model/Part/Camera/Light/Sound.
- Простые размеры Box/Sphere/Capsule и базовые трансформации сохранены приближённо.
- Внешние ресурсы скопированы в соответствующие папки.
- Для .gd создан Luau-файл с TODO и предупреждениями для неподдерживаемых строк.

ОГРАНИЧЕНИЯ
- Произвольный GDScript не может быть автоматически и безопасно преобразован в эквивалентную игру Roblox.
- GLB/GLTF/OBJ/FBX сохраняются отдельно; их геометрия не встраивается в RBXMX.
- Текстуры/аудио надо загрузить в Roblox и указать выданные asset ID.
- Физика, навигация, анимации, UI, сигналы, шейдеры и игровые механики требуют ручной адаптации.
- Этот результат не проверен запуском в Roblox Studio в текущей среде.

Смотрите Reports/import_report.md и Reports/import_report.json.
