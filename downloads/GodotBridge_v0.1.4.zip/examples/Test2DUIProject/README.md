# GodotBridge 2D/UI sample

A tiny Godot 4 text-scene project for trying the v0.1.4 screen-space UI converter.

## Included nodes

- Root `CanvasLayer`
- Full-screen `Control` and `ColorRect`
- `Panel`, `TextureRect`, `Label`, `Button`, `ProgressBar`
- Slash-separated `theme_override_font_sizes/font_size` and `theme_override_colors/font_color` properties

## Test

1. Zip the contents of this folder (the ZIP must contain `project.godot`).
2. Import the ZIP with GodotBridge.
3. Open `Reports/import_report.md` and `RobloxProject/ConvertedScene.rbxmx`.
4. In Roblox Studio, move the generated `ScreenGui` into `StarterGui`.
5. Upload `Textures/godotbridge-icon.png` to Roblox, then set the corresponding `Image` property manually.

The button has no click behavior and the progress bar is static. This is an asset/layout conversion test, not a playable game.
