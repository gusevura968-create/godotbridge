# GODOTBRIDGE 0.1.4

**Godot → Roblox conversion starter project.** This repository contains a Windows desktop converter, Roblox Experience source and seed place file, a small Godot fixture, automated tests, and a sample conversion.

> Compatibility note: Godot and Roblox have different engines and runtime APIs. GodotBridge performs static scene/resource conversion and translates only a conservative GDScript subset. It does not claim to turn an arbitrary Godot game into a fully playable Roblox game automatically.

## Пошаговая установка

Подробная русская инструкция находится в `ПОШАГОВАЯ УСТАНОВКА.txt` в корне архива и рядом с `run_converter.bat` в `converter/`. Она учитывает проверенный способ запуска через контекстное меню Windows, установку Python/Tkinter, подготовку ZIP, поиск результатов, диагностику и импорт в Roblox Studio.

## Windows desktop app

1. Распакуйте полный ZIP в обычную папку.
2. Установите Python 3.10+ с компонентом `tcl/tk and IDLE`.
3. Откройте папку `converter` и запускайте `run_converter.bat` тем же способом через контекстное меню ПКМ с иконкой файла, который описан в инструкции. Не меняйте работающий способ запуска на обычный двойной щелчок ЛКМ.
4. При первом запуске используйте кнопку **ПРОВЕРКА СИСТЕМЫ**.
5. Выберите ZIP одного полного Godot-проекта, внутри которого есть `project.godot` и текстовые `.tscn` сцены.
6. После импорта изучите `Reports/import_report.md` и результат `RobloxProject/ConvertedScene.rbxmx`.

В базовой версии используются только стандартная библиотека Python и Tkinter. Для создания самостоятельного EXE запустите `converter/build_windows.bat` на Windows. Готовый EXE в этом релизе не поставляется.

## Новое в v0.1.4 — 2D/UI

В дополнение к возможностям v0.1.3 добавлен базовый перенос экранных 2D-элементов:

- Корневой `Node2D` преобразуется в `ScreenGui` с полноэкранным контейнером.
- `CanvasLayer` преобразуется в `ScreenGui`.
- `Control`, `Panel`, `ColorRect`, `Label`, `RichTextLabel`, `Button`, `LineEdit`, `TextEdit`, `TextureRect`, `TextureButton`, `CheckBox`, `CheckButton` и `ProgressBar` получают базовые Roblox GUI-представления.
- `Sprite2D` внутри 2D-сцены/CanvasLayer преобразуется в `ImageLabel`. Для PNG читаются исходные размеры.
- Отчёт показывает количество созданных GUI-объектов и ScreenGui.

**После импорта ScreenGui нужно переместить в StarterGui.** Текстуры нужно отдельно загрузить в Roblox и назначить полученные asset ID. Это статическая визуальная заготовка: камера, физика, анимация, сигналы, игровая логика и автоматическая компоновка контейнеров не переносятся.

## Архитектура

```text
GodotBridge/
├── converter/                 # Python desktop app + CLI
│   └── godotbridge/
│       ├── archive.py         # ZIP validation and safe extraction
│       ├── parser.py          # project.godot + .tscn parser
│       ├── scripts.py         # conservative GDScript → Luau subset
│       ├── ui.py              # Godot 2D/UI → Roblox GUI approximation
│       ├── convert.py         # scenes/resources/RBXMX/reports
│       ├── diagnostics.py     # system checks and rotating logs
│       └── gui.py             # Tkinter interface
├── roblox/                    # Roblox Experience scripts + seed .rbxlx
├── examples/                  # Godot fixture and sample conversion
├── tests/                     # automated tests
└── docs/                      # support matrix, limitations and workflow
```

## Automated tests

From the repository root:

```powershell
py -3 -m unittest discover -s tests -v
```

The current development run contains 30 passing tests, including ZIP security checks, scene parsing, GDScript subset translation, RBXMX XML validation, conversion rollback, 2D GUI generation and texture-reference staging. See `docs/TEST_RESULTS.txt`.

## Included examples

- `examples/TestGodotProject/` — small 3D-oriented Godot project used by baseline conversion tests.
- `examples/Test2DUIProject/` and `examples/Test2DUIProject.zip` — ready-to-import CanvasLayer/UI fixture for v0.1.4. Use the ZIP to test ScreenGui, Frame, TextLabel, TextButton, ImageLabel and static ProgressBar output.
- `examples/ConvertedDemo2D/` — sample output generated from the included 2D/UI fixture by v0.1.4. The report is `Reports/import_report.md`.

The 2D sample is deliberately small. After importing the generated RBXMX into Studio, move ScreenGui to StarterGui and manually assign the uploaded image asset ID.

## Roblox Experience

- `roblox/GodotBridgeExperience.rbxlx` is a generated seed place file. Open and inspect it in Roblox Studio before publishing.
- Editable scripts are in `roblox/StarterPlayerScripts/` and `roblox/ServerScriptService/`.
- Manual setup instructions are in `roblox/README.md`.

## Output and limitations

Every converted project includes source scenes/scripts, staged assets, Luau drafts, an import report, and RBXMX files. A successful conversion means that files were generated and validated as XML; it does not mean the full Godot game is playable in Roblox. Read `docs/SUPPORTED_FEATURES.md` and `docs/LIMITATIONS.md` before using the output.

## Release checks

Automated tests were run in Linux. The Windows right-click launch workflow and actual RBXMX import into Roblox Studio have not been verified in this environment. Use `docs/WINDOWS_RELEASE_CHECKLIST.md` for those manual checks.
