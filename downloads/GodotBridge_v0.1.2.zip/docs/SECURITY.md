# Security model

- User ZIP content is treated as data. The converter never launches Godot, evaluates GDScript, invokes shell commands from a project, loads native libraries from the archive, or runs generated Luau.
- ZIP paths are normalized and checked before extraction. Absolute paths, `..` traversal, drive-letter paths, symlinks, duplicate paths, excessive file counts, oversized members, large total expanded size and extreme compression ratios are rejected.
- `.tscn` and `.gd` are parsed as text only.
- The Roblox server accepts only string identifiers that exist in its server-owned `PUBLISHED_GAMES` allowlist (the default entry is `demo`). It does not accept uploaded code, asset IDs or arbitrary place IDs from clients; place IDs are read only from the server-side table.
- `loadstring` is not used. Imported source is not dynamically executed.

The converter is not a malware scanner. Do not execute scripts or binaries from untrusted Godot projects after conversion. Keep Roblox asset upload and publication permissions under the project owner's control.
