# GodotBridge Converter

Windows desktop converter, Python 3.10+; runtime dependencies: Python standard library only (Tkinter is included with the standard Windows Python installer when the Tcl/Tk option is selected).

## Run on Windows

1. Extract the complete GodotBridge ZIP (do not run it from inside the ZIP preview).
2. Open the `converter` folder.
3. Double-click `run_converter.bat`. The launcher checks Python and Tkinter and keeps the console open if an error occurs.

You can also run it from PowerShell:

```powershell
cd converter
py -3 run_converter.py
```

Choose a ZIP containing one Godot project (`project.godot`, `.tscn`, `.gd`, and resources). For CLI use:

```powershell
py -3 -m godotbridge.cli path\to\godot-project.zip --output path\to\ConvertedGames
```

## Build a Windows executable

Run `build_windows.bat` from a Windows machine with Python installed. It installs PyInstaller and creates `dist\GodotBridgeConverter.exe`. This repository includes the build recipe; a Windows executable is not prebuilt in this Linux environment.

## Security

The converter does not run Godot, GDScript, shell scripts, imported binaries or generated Luau. ZIP extraction rejects traversal paths, symlinks, duplicate paths and excessive archive sizes. The parser treats project files as data.


## Troubleshooting startup

- If the launcher says Python was not found, install Python 3.10 or newer from https://www.python.org/downloads/windows/.
- In the installer, include **tcl/tk and IDLE** so the Tkinter desktop interface is available.
- Extract the whole ZIP before launching; `run_converter.py` and the `godotbridge` folder must remain beside `run_converter.bat`.
- If the window still fails, run `run_converter.bat` again and send a screenshot of the full console error.
