@echo off
setlocal
cd /d %~dp0
py -3 -m pip install --upgrade pip pyinstaller
py -3 -m PyInstaller --noconfirm --clean --onefile --windowed --name GodotBridgeConverter run_converter.py
if errorlevel 1 (
  echo Build failed. Check the Python/PyInstaller error above.
  exit /b 1
)
echo Build complete: dist\GodotBridgeConverter.exe
endlocal
