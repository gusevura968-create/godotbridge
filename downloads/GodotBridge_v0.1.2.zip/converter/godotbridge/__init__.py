"""GodotBridge: conservative Godot-to-Roblox project converter."""
__version__ = "0.1.0"
