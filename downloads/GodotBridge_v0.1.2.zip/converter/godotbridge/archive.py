from __future__ import annotations

import os
import stat
import zipfile
from pathlib import Path, PurePosixPath


class ArchiveValidationError(ValueError):
    pass


MAX_FILES = 50_000
MAX_TOTAL_UNCOMPRESSED = 1_000_000_000  # 1 GB
MAX_SINGLE_FILE = 250_000_000           # 250 MB
MAX_COMPRESSION_RATIO = 1_000


def safe_extract_zip(archive_path: Path, destination: Path) -> Path:
    """Safely extract a Godot ZIP, rejecting traversal, links and ZIP bombs.

    Returns the directory containing the single discovered project.godot.
    No extracted file is executed.
    """
    archive_path = Path(archive_path)
    destination = Path(destination).resolve()
    destination.mkdir(parents=True, exist_ok=True)

    if not zipfile.is_zipfile(archive_path):
        raise ArchiveValidationError("Файл не является корректным ZIP-архивом.")

    seen: set[str] = set()
    total_size = 0
    extracted_count = 0

    try:
        with zipfile.ZipFile(archive_path, "r") as zf:
            infos = zf.infolist()
            if len(infos) > MAX_FILES:
                raise ArchiveValidationError(f"В архиве слишком много файлов (лимит: {MAX_FILES}).")

            for info in infos:
                raw_name = info.filename.replace("\\", "/")
                pure = PurePosixPath(raw_name)
                if not raw_name or pure.is_absolute() or any(part in ("..", "") for part in pure.parts):
                    raise ArchiveValidationError(f"Небезопасный путь внутри ZIP: {info.filename!r}")
                if pure.parts and ":" in pure.parts[0]:
                    raise ArchiveValidationError(f"Путь с буквой диска запрещён: {info.filename!r}")

                mode = (info.external_attr >> 16) & 0xFFFF
                if stat.S_ISLNK(mode):
                    raise ArchiveValidationError(f"Символические ссылки в ZIP запрещены: {info.filename!r}")

                normalized = "/".join(pure.parts).casefold()
                if normalized in seen:
                    raise ArchiveValidationError(f"Повторяющийся путь в архиве: {info.filename!r}")
                seen.add(normalized)

                if info.is_dir():
                    continue
                if info.file_size > MAX_SINGLE_FILE:
                    raise ArchiveValidationError(f"Файл слишком большой: {info.filename!r}")
                total_size += info.file_size
                if total_size > MAX_TOTAL_UNCOMPRESSED:
                    raise ArchiveValidationError("Распакованный архив превышает лимит 1 ГБ.")
                if info.file_size > 1_000_000:
                    compressed = max(info.compress_size, 1)
                    if info.file_size / compressed > MAX_COMPRESSION_RATIO:
                        raise ArchiveValidationError(f"Подозрительная степень сжатия: {info.filename!r}")

            for info in infos:
                if info.is_dir():
                    continue
                relative = PurePosixPath(info.filename.replace("\\", "/"))
                target = (destination / Path(*relative.parts)).resolve()
                if target != destination and destination not in target.parents:
                    raise ArchiveValidationError(f"Попытка выхода за пределы папки проекта: {info.filename!r}")
                target.parent.mkdir(parents=True, exist_ok=True)
                written = 0
                with zf.open(info, "r") as source, target.open("wb") as output:
                    while True:
                        chunk = source.read(1024 * 1024)
                        if not chunk:
                            break
                        written += len(chunk)
                        if written > MAX_SINGLE_FILE:
                            raise ArchiveValidationError(f"Файл превышает лимит при распаковке: {info.filename!r}")
                        output.write(chunk)
                extracted_count += 1
    except (zipfile.BadZipFile, OSError, RuntimeError) as exc:
        if isinstance(exc, ArchiveValidationError):
            raise
        raise ArchiveValidationError(f"Не удалось безопасно прочитать ZIP: {exc}") from exc

    projects = list(destination.rglob("project.godot"))
    if not projects:
        raise ArchiveValidationError("В ZIP не найден project.godot. Нужен полный Godot-проект.")
    projects.sort(key=lambda p: (len(p.relative_to(destination).parts), str(p).casefold()))
    if len(projects) > 1 and len(projects[0].relative_to(destination).parts) == len(projects[1].relative_to(destination).parts):
        raise ArchiveValidationError("В архиве найдено несколько равнозначных project.godot; упакуйте один проект в ZIP.")
    return projects[0].parent
