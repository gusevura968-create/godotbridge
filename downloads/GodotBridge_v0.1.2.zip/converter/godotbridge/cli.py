from __future__ import annotations

import argparse
from pathlib import Path

from .convert import GodotBridgeConverter


def main() -> int:
    parser = argparse.ArgumentParser(description="GodotBridge — conservative Godot .zip to Roblox model converter")
    parser.add_argument("archive", type=Path, help="ZIP-архив полного Godot-проекта")
    parser.add_argument("--output", type=Path, default=Path.home() / "GodotBridge" / "ConvertedGames", help="Папка результатов")
    args = parser.parse_args()

    def progress(value: float, message: str):
        print(f"[{value * 100:5.1f}%] {message}")

    try:
        result = GodotBridgeConverter(args.output).convert_archive(args.archive, progress)
    except Exception as exc:
        print(f"ОШИБКА: {exc}")
        return 2
    print(f"\nГотово: {result}")
    print(f"Отчёт: {result / 'Reports' / 'import_report.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
