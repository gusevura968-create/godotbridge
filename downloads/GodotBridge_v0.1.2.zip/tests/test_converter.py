from __future__ import annotations

import sys
import tempfile
import unittest
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONVERTER = ROOT / "converter"
sys.path.insert(0, str(CONVERTER))

from godotbridge.archive import ArchiveValidationError, safe_extract_zip
from godotbridge.convert import GodotBridgeConverter
from godotbridge.parser import parse_tscn
from godotbridge.scripts import translate_gdscript

FIXTURE = ROOT / "examples" / "TestGodotProject"


class ArchiveTests(unittest.TestCase):
    def test_extract_valid_project_zip(self):
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            archive = temp_path / "project.zip"
            with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as zf:
                for source in FIXTURE.rglob("*"):
                    if source.is_file():
                        zf.write(source, source.relative_to(FIXTURE).as_posix())
            project_root = safe_extract_zip(archive, temp_path / "unpacked")
            self.assertTrue((project_root / "project.godot").is_file())

    def test_reject_path_traversal(self):
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            archive = temp_path / "bad.zip"
            with zipfile.ZipFile(archive, "w") as zf:
                zf.writestr("../escape.txt", "no")
            with self.assertRaises(ArchiveValidationError):
                safe_extract_zip(archive, temp_path / "out")

    def test_reject_non_zip(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "not.zip"
            path.write_text("no", encoding="utf-8")
            with self.assertRaises(ArchiveValidationError):
                safe_extract_zip(path, Path(temp) / "out")

    def test_reject_zip_without_project_file(self):
        with tempfile.TemporaryDirectory() as temp:
            temp_path = Path(temp)
            archive = temp_path / "incomplete.zip"
            with zipfile.ZipFile(archive, "w") as zf:
                zf.writestr("README.txt", "not a Godot project")
            with self.assertRaisesRegex(ArchiveValidationError, "project.godot"):
                safe_extract_zip(archive, temp_path / "out")


class ParserTests(unittest.TestCase):
    def test_tscn_hierarchy_and_subresources(self):
        doc = parse_tscn(FIXTURE / "Scenes" / "Main.tscn")
        self.assertEqual(doc.root.name, "Main")
        self.assertEqual(len(doc.nodes), 11)
        self.assertEqual(doc.warnings, [])
        self.assertIn("BoxMesh_floor", doc.sub_resources)
        floor = next(node for node in doc.nodes if node.name == "Floor")
        self.assertEqual([child.name for child in floor.children], ["FloorMesh", "FloorCollision"])

    def test_packed_scene_instance_is_retained(self):
        import tempfile
        source = (
            '[gd_scene load_steps=2 format=3]\n'
            '[ext_resource type="PackedScene" path="res://Scenes/Child.tscn" id="1_child"]\n'
            '[node name="Root" type="Node3D"]\n'
            '[node name="Child" parent="." instance=ExtResource("1_child")]\n'
        )
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "root.tscn"
            path.write_text(source, encoding="utf-8")
            doc = parse_tscn(path)
            self.assertEqual(doc.root.children[0].type, "PackedSceneInstance")
            self.assertIn("instance", doc.root.children[0].properties)


class ScriptTests(unittest.TestCase):
    def test_supported_subset_and_unsupported_api_warning(self):
        result = translate_gdscript(FIXTURE / "Scripts" / "player.gd")
        self.assertIn("function script:_ready()", result.output_text)
        self.assertIn("script.speed = 5.0", result.output_text)
        self.assertTrue(any("move_and_slide" in warning for warning in result.unsupported))
        self.assertIn("TODO", result.output_text)

    def test_if_and_range_translation(self):
        source = "func sample(n: int):\n    if n > 0:\n        for i in range(n):\n            print(i)\n    else:\n        print(0)\n"
        result = translate_gdscript(Path("sample.gd"), source)
        self.assertIn("if n > 0 then", result.output_text)
        self.assertIn("for i = 0, (n) - 1 do", result.output_text)
        self.assertGreaterEqual(result.output_text.count("end"), 3)

    def test_unsupported_condition_does_not_emit_live_branch_body(self):
        source = (
            "func sample():\n"
            "    if Input.is_action_pressed(\"jump\"):\n"
            "        print(\"would be unsafe to guess\")\n"
            "    else:\n"
            "        print(\"also guarded by unsupported condition\")\n"
            "    print(\"after branch\")\n"
        )
        result = translate_gdscript(Path("sample.gd"), source)
        self.assertTrue(any("Input." in warning for warning in result.unsupported))
        self.assertIn("print(\"after branch\")", result.output_text)
        live_lines = [line.strip() for line in result.output_text.splitlines() if not line.lstrip().startswith("--")]
        self.assertNotIn("print(\"would be unsafe to guess\")", live_lines)
        self.assertNotIn("print(\"also guarded by unsupported condition\")", live_lines)


class ConversionTests(unittest.TestCase):
    def test_reject_project_without_scenes(self):
        with tempfile.TemporaryDirectory() as temp:
            project = Path(temp) / "project"
            project.mkdir()
            (project / "project.godot").write_text('[application]\nconfig/name="No Scene"\n', encoding="utf-8")
            with self.assertRaisesRegex(ValueError, r"\.tscn"):
                GodotBridgeConverter(Path(temp) / "out").convert_project(project)

    def test_end_to_end_generates_rbxmx_and_report(self):
        with tempfile.TemporaryDirectory() as temp:
            output = GodotBridgeConverter(Path(temp) / "out").convert_project(FIXTURE)
            rbxmx = output / "Scenes" / "Roblox" / "Scenes" / "Main.rbxmx"
            self.assertTrue(rbxmx.is_file())
            root = ET.parse(rbxmx).getroot()
            self.assertEqual(root.tag, "roblox")
            classes = [item.attrib.get("class") for item in root.iter("Item")]
            self.assertIn("Part", classes)
            self.assertIn("Camera", classes)
            report = (output / "Reports" / "import_report.json").read_text(encoding="utf-8")
            self.assertIn('"status": "PARTIAL"', report)
            self.assertIn('"textures": 2', report)
            self.assertIn('"audio": 1', report)
            self.assertIn('"model_files": 1', report)
            luau = output / "Scripts" / "Luau" / "Scripts" / "player.luau"
            self.assertTrue(luau.is_file())
            self.assertIn("move_and_slide", luau.read_text(encoding="utf-8"))
            place = ROOT / "roblox" / "GodotBridgeExperience.rbxlx"
            place_xml = ET.parse(place).getroot()
            self.assertEqual(place_xml.tag, "roblox")


if __name__ == "__main__":
    unittest.main(verbosity=2)
