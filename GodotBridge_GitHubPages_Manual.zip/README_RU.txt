# GodotBridge — публикация сайта через GitHub Pages (без BAT/PowerShell)

Этот пакет не содержит исполняемых скриптов. Для публикации используется только интерфейс GitHub в браузере.

## 1. Создай репозиторий

1. Открой https://github.com/new и войди в свой GitHub-аккаунт.
2. В Repository name введи `godotbridge-site`.
3. Выбери **Public**.
4. Не ставь галочки добавления README, .gitignore или лицензии — нужен пустой репозиторий.
5. Нажми **Create repository**.

## 2. Загрузи файлы сайта

1. Открой созданный репозиторий.
2. Нажми **Add file → Upload files**.
3. Из распакованной папки GodotBridge_GitHubPages_Manual перетащи в окно загрузки сами файлы и папки: `index.html`, `styles.css`, `script.js`, `favicon.png`, `assets` и `downloads`.
   - Важно: загружай содержимое папки в корень репозитория, а не внешнюю папку `GodotBridge_GitHubPages_Manual` целиком.
4. Внизу нажми **Commit changes**.

## 3. Включи GitHub Pages

1. В репозитории открой **Settings → Pages**.
2. В блоке **Build and deployment** выбери **Deploy from a branch**.
3. В Branch выбери `main`, папку `/ (root)`, затем нажми **Save**.
4. Подожди завершения публикации. Состояние можно увидеть в разделе **Actions** или **Settings → Pages**.

## 4. Адрес сайта

Для репозитория `godotbridge-site` адрес будет таким:

`https://ТВОЙ-GITHUB-ЛОГИН.github.io/godotbridge-site/`

Подставь свой точный логин GitHub. Адрес начнёт открываться после успешной публикации; HTTPS предоставляется GitHub Pages.

## 5. Проверка скачивания

На опубликованном сайте нажми кнопку скачивания GodotBridge. Она должна открыть файл:

`downloads/GodotBridge_v0.1.0.zip`

## Безопасность

Не запускай `PUBLISH_TO_GITHUB.bat` из предыдущего пакета и не отключай Smart App Control. В этом пакете скриптов `.bat` и `.ps1` нет: публикация выполняется вручную через браузер GitHub.

## О версии

ZIP `GodotBridge_v0.1.0.zip` содержит исходники базового конвертера и отчёт о проверках. Это не готовый подписанный Windows `.exe`; ограничения и инструкция сборки находятся внутри самого архива релиза.
